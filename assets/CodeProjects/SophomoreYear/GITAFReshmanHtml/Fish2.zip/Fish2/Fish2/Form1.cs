﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Madeline Tjoa
//Period 0
//Fish 2

namespace Fish2
{
    public partial class FrmMain : Form
    {

        //DEclare global variables
        //declare an array to organize our pictureboxes
        PictureBox[,] theTank = new PictureBox[3, 8];

        //declare a 2D array

        int fishcol = 0;
        int fishrow = 0;

        int sharkcol = 0;
        int sharkrow = 0;

        System.Random r = new System.Random((int)System.DateTime.Now.Ticks);

        int Rightside = 0;
        int Leftside = 0;
        int Topside = 0;
        int Downside = 0;

        

        //create a boolian switch
        Boolean onOff = false;

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            // this code runs one time at startup
            //row 1
            theTank[0, 0] = picBox1;
            theTank[0, 1] = picBox2;
            theTank[0, 2] = picBox3;
            theTank[0, 3] = picBox4;
            theTank[0, 4] = picBox5;
            theTank[0, 5] = picBox6;
            theTank[0, 6] = picBox7;
            theTank[0, 7] = picBox8;

            //row 2
            theTank[1, 0] = picBox9;
            theTank[1, 1] = picBox10;
            theTank[1, 2] = picBox11;
            theTank[1, 3] = picBox12;
            theTank[1, 4] = picBox13;
            theTank[1, 5] = picBox14;
            theTank[1, 6] = picBox15;
            theTank[1, 7] = picBox16;

            //row 3
            theTank[2, 0] = picBox17;
            theTank[2, 1] = picBox18;
            theTank[2, 2] = picBox19;
            theTank[2, 3] = picBox20;
            theTank[2, 4] = picBox21;
            theTank[2, 5] = picBox22;
            theTank[2, 6] = picBox23;
            theTank[2, 7] = picBox24;

            int randomIntergercol = r.Next(0, 8);
            int randomIntergerrow = r.Next(0, 3);
            theTank[randomIntergerrow, randomIntergercol].Image = picFishLeft.Image;
            fishrow = randomIntergerrow;
            fishcol = randomIntergercol;

            int randomintergerSharkcol = r.Next(0, 8);
            int randomintergerSharkrow = r.Next(0, 3);
            theTank[randomintergerSharkrow, randomintergerSharkcol].Image = picSharkRight.Image;
            sharkrow = randomintergerSharkrow;
            sharkcol = randomintergerSharkcol;





        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            try
            {
                //this will randomly move the fish to a picture box
               
                //take out the current shark image
                
                //Variables for new fish location
                int newlocationcol = 0;
                
                //new shark location
                int newsharklocation = 0;

                //Make a random up down

                newlocationcol = r.Next(0, 4);
                if (newlocationcol == 0)
                {
                    
                     theTank[fishrow, fishcol].Image = null;
                    fishcol--;
                    theTank[fishrow, fishcol].Image = picFishLeft.Image;
                }
                else if (newlocationcol == 1)
                {
                    theTank[fishrow, fishcol].Image = null;
                    fishcol++;
                    theTank[fishrow, fishcol].Image = picFishRight.Image;
                }
                else if (newlocationcol == 2)
                {
                    theTank[fishrow, fishcol].Image = null;
                    fishrow--;
                    theTank[fishrow, fishcol].Image = picFishLeft.Image;
                }
                else if (newlocationcol == 3)
                {
                    theTank[fishrow, fishcol].Image = null;
                    fishrow++;
                    theTank[fishrow, fishcol].Image = picFishRight.Image;

                }

                newsharklocation = r.Next(0, 4);
                if (newsharklocation == 0)
                {
                    theTank[sharkrow, sharkcol].Image = null;
                    sharkcol--;
                    theTank[sharkrow, sharkcol].Image = picSHarkLeft.Image;
                }
                if (newsharklocation == 1)
                {
                    theTank[sharkrow, sharkcol].Image = null;
                    sharkcol++;
                    theTank[sharkrow, sharkcol].Image = picSharkRight.Image;
                }
                if (newsharklocation == 2)
                {
                    theTank[sharkrow, sharkcol].Image = null;
                    sharkrow--;
                    theTank[sharkrow, sharkcol].Image = picSHarkLeft.Image;
                }
                if (newsharklocation == 3)
                {
                    theTank[sharkrow, sharkcol].Image = null;
                    sharkrow++;
                    theTank[sharkrow, sharkcol].Image = picSharkRight.Image;
                }


                
                
                if (sharkcol==fishcol && fishrow==sharkrow)
                {
                    theTank[sharkrow, sharkcol].Image = null;
                    timer1.Enabled = false;
                    MessageBox.Show("the shark ate the fish!(tank restarting)");
                    FrmMain_Load(sender, e);

                    lblBottom.Text = "";
                    lblLeft.Text = "";
                    lblRight.Text = "";
                    lblTop.Text = "";

                       
                   
                }


            }

            catch
            {
                //fish
                if (fishcol > 7)
                {
                    
                    fishcol = 7;
                    Rightside += 1;
                    theTank[fishrow,fishcol].Image = picFishLeft.Image;
                }

                if (fishrow < 0)
                {
                   
                    fishrow = 0;
                    Downside += 1;
                    theTank[fishrow,fishcol].Image = picFishLeft.Image;
                }
                if (fishrow > 2)
                {
                    
                    fishrow = 2;
                    Topside += 1;
                    theTank[fishrow, fishcol].Image = picFishLeft.Image;
                }
                if (fishcol < 0)
                {
                    
                    fishcol = 0;
                    Leftside += 1;
                    theTank[fishrow, fishcol].Image = picFishLeft.Image;
                }
                //SHark
                if (sharkcol > 7)
                {

                    sharkcol = 7;
                    
                    theTank[sharkrow, sharkcol].Image = picSharkRight.Image;
                }

                if (sharkrow < 0)
                {

                    sharkrow = 0;
                    
                    theTank[sharkrow, sharkcol].Image = picSharkRight.Image;
                }
                if (sharkrow > 2)
                {

                    sharkrow = 2;
                 
                    theTank[sharkrow, sharkcol].Image = picSharkRight.Image;
                }
                if (sharkcol < 0)
                {

                    sharkcol = 0;
                 
                    theTank[sharkrow, sharkcol].Image = picSharkRight.Image;
                }

                if (sharkcol == fishcol && fishrow == sharkrow)
                {
                    theTank[sharkrow, sharkcol].Image = null;
                    timer1.Enabled = false;
                    MessageBox.Show("the shark ate the fish!(tank restarting)");
                    FrmMain_Load(sender, e);

                    lblBottom.Text = "";
                    lblLeft.Text = "";
                    lblRight.Text = "";
                    lblTop.Text = "";
                }

            }

                 lblLeft.Text = Leftside.ToString();
                 lblRight.Text = Rightside.ToString();
                 lblBottom.Text = Downside.ToString();
                 lblTop.Text = Topside.ToString();
            
            
            
        }

        private void pictureBox24_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox22_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            

            
            

            //move fish auto
            if (onOff == false)
            {
                timer1.Enabled = true;
                onOff = true;
            }
            else if (onOff == true)
            {
                timer1.Enabled = false;
                onOff = false;
            }
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //this calls the move code
            btnMove_Click(sender, e);
        }
    }
}
