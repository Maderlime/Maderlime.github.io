﻿namespace Fish2
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.picBox1 = new System.Windows.Forms.PictureBox();
            this.picBox19 = new System.Windows.Forms.PictureBox();
            this.picBox10 = new System.Windows.Forms.PictureBox();
            this.picBox2 = new System.Windows.Forms.PictureBox();
            this.picBox12 = new System.Windows.Forms.PictureBox();
            this.picBox20 = new System.Windows.Forms.PictureBox();
            this.picBox22 = new System.Windows.Forms.PictureBox();
            this.picBox14 = new System.Windows.Forms.PictureBox();
            this.picBox4 = new System.Windows.Forms.PictureBox();
            this.picBox13 = new System.Windows.Forms.PictureBox();
            this.picBox21 = new System.Windows.Forms.PictureBox();
            this.picBox3 = new System.Windows.Forms.PictureBox();
            this.picBox24 = new System.Windows.Forms.PictureBox();
            this.picBox16 = new System.Windows.Forms.PictureBox();
            this.picBox6 = new System.Windows.Forms.PictureBox();
            this.picBox15 = new System.Windows.Forms.PictureBox();
            this.picBox23 = new System.Windows.Forms.PictureBox();
            this.picBox5 = new System.Windows.Forms.PictureBox();
            this.picBox18 = new System.Windows.Forms.PictureBox();
            this.picBox9 = new System.Windows.Forms.PictureBox();
            this.picBox17 = new System.Windows.Forms.PictureBox();
            this.picBox7 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTop = new System.Windows.Forms.Label();
            this.lblLeft = new System.Windows.Forms.Label();
            this.lblRight = new System.Windows.Forms.Label();
            this.lblBottom = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSpeed = new System.Windows.Forms.TextBox();
            this.btnMove = new System.Windows.Forms.Button();
            this.btnAutoMove = new System.Windows.Forms.Button();
            this.picBox8 = new System.Windows.Forms.PictureBox();
            this.picBox11 = new System.Windows.Forms.PictureBox();
            this.picFishLeft = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.picSharkRight = new System.Windows.Forms.PictureBox();
            this.picFishRight = new System.Windows.Forms.PictureBox();
            this.picSHarkLeft = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFishLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSharkRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFishRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSHarkLeft)).BeginInit();
            this.SuspendLayout();
            // 
            // picBox1
            // 
            this.picBox1.Location = new System.Drawing.Point(13, 124);
            this.picBox1.Name = "picBox1";
            this.picBox1.Size = new System.Drawing.Size(85, 70);
            this.picBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox1.TabIndex = 0;
            this.picBox1.TabStop = false;
            // 
            // picBox19
            // 
            this.picBox19.Location = new System.Drawing.Point(194, 276);
            this.picBox19.Name = "picBox19";
            this.picBox19.Size = new System.Drawing.Size(85, 70);
            this.picBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox19.TabIndex = 1;
            this.picBox19.TabStop = false;
            // 
            // picBox10
            // 
            this.picBox10.Location = new System.Drawing.Point(103, 200);
            this.picBox10.Name = "picBox10";
            this.picBox10.Size = new System.Drawing.Size(85, 70);
            this.picBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox10.TabIndex = 2;
            this.picBox10.TabStop = false;
            // 
            // picBox2
            // 
            this.picBox2.Location = new System.Drawing.Point(104, 124);
            this.picBox2.Name = "picBox2";
            this.picBox2.Size = new System.Drawing.Size(85, 70);
            this.picBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox2.TabIndex = 3;
            this.picBox2.TabStop = false;
            // 
            // picBox12
            // 
            this.picBox12.Location = new System.Drawing.Point(285, 200);
            this.picBox12.Name = "picBox12";
            this.picBox12.Size = new System.Drawing.Size(85, 70);
            this.picBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox12.TabIndex = 4;
            this.picBox12.TabStop = false;
            // 
            // picBox20
            // 
            this.picBox20.Location = new System.Drawing.Point(285, 276);
            this.picBox20.Name = "picBox20";
            this.picBox20.Size = new System.Drawing.Size(85, 70);
            this.picBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox20.TabIndex = 5;
            this.picBox20.TabStop = false;
            // 
            // picBox22
            // 
            this.picBox22.Location = new System.Drawing.Point(467, 276);
            this.picBox22.Name = "picBox22";
            this.picBox22.Size = new System.Drawing.Size(85, 70);
            this.picBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox22.TabIndex = 11;
            this.picBox22.TabStop = false;
            // 
            // picBox14
            // 
            this.picBox14.Location = new System.Drawing.Point(467, 200);
            this.picBox14.Name = "picBox14";
            this.picBox14.Size = new System.Drawing.Size(85, 70);
            this.picBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox14.TabIndex = 10;
            this.picBox14.TabStop = false;
            // 
            // picBox4
            // 
            this.picBox4.Location = new System.Drawing.Point(285, 124);
            this.picBox4.Name = "picBox4";
            this.picBox4.Size = new System.Drawing.Size(85, 70);
            this.picBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox4.TabIndex = 9;
            this.picBox4.TabStop = false;
            // 
            // picBox13
            // 
            this.picBox13.Location = new System.Drawing.Point(374, 200);
            this.picBox13.Name = "picBox13";
            this.picBox13.Size = new System.Drawing.Size(85, 70);
            this.picBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox13.TabIndex = 8;
            this.picBox13.TabStop = false;
            // 
            // picBox21
            // 
            this.picBox21.Location = new System.Drawing.Point(374, 276);
            this.picBox21.Name = "picBox21";
            this.picBox21.Size = new System.Drawing.Size(85, 70);
            this.picBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox21.TabIndex = 7;
            this.picBox21.TabStop = false;
            // 
            // picBox3
            // 
            this.picBox3.Location = new System.Drawing.Point(194, 124);
            this.picBox3.Name = "picBox3";
            this.picBox3.Size = new System.Drawing.Size(85, 70);
            this.picBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox3.TabIndex = 6;
            this.picBox3.TabStop = false;
            // 
            // picBox24
            // 
            this.picBox24.Location = new System.Drawing.Point(649, 276);
            this.picBox24.Name = "picBox24";
            this.picBox24.Size = new System.Drawing.Size(85, 70);
            this.picBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox24.TabIndex = 17;
            this.picBox24.TabStop = false;
            // 
            // picBox16
            // 
            this.picBox16.Location = new System.Drawing.Point(649, 200);
            this.picBox16.Name = "picBox16";
            this.picBox16.Size = new System.Drawing.Size(85, 70);
            this.picBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox16.TabIndex = 16;
            this.picBox16.TabStop = false;
            this.picBox16.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // picBox6
            // 
            this.picBox6.Location = new System.Drawing.Point(465, 124);
            this.picBox6.Name = "picBox6";
            this.picBox6.Size = new System.Drawing.Size(85, 70);
            this.picBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox6.TabIndex = 15;
            this.picBox6.TabStop = false;
            // 
            // picBox15
            // 
            this.picBox15.Location = new System.Drawing.Point(558, 200);
            this.picBox15.Name = "picBox15";
            this.picBox15.Size = new System.Drawing.Size(85, 70);
            this.picBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox15.TabIndex = 14;
            this.picBox15.TabStop = false;
            // 
            // picBox23
            // 
            this.picBox23.Location = new System.Drawing.Point(558, 276);
            this.picBox23.Name = "picBox23";
            this.picBox23.Size = new System.Drawing.Size(85, 70);
            this.picBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox23.TabIndex = 13;
            this.picBox23.TabStop = false;
            // 
            // picBox5
            // 
            this.picBox5.Location = new System.Drawing.Point(374, 124);
            this.picBox5.Name = "picBox5";
            this.picBox5.Size = new System.Drawing.Size(85, 70);
            this.picBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox5.TabIndex = 12;
            this.picBox5.TabStop = false;
            // 
            // picBox18
            // 
            this.picBox18.Location = new System.Drawing.Point(103, 276);
            this.picBox18.Name = "picBox18";
            this.picBox18.Size = new System.Drawing.Size(85, 70);
            this.picBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox18.TabIndex = 22;
            this.picBox18.TabStop = false;
            // 
            // picBox9
            // 
            this.picBox9.Location = new System.Drawing.Point(12, 200);
            this.picBox9.Name = "picBox9";
            this.picBox9.Size = new System.Drawing.Size(85, 70);
            this.picBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox9.TabIndex = 21;
            this.picBox9.TabStop = false;
            // 
            // picBox17
            // 
            this.picBox17.Location = new System.Drawing.Point(12, 276);
            this.picBox17.Name = "picBox17";
            this.picBox17.Size = new System.Drawing.Size(85, 70);
            this.picBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox17.TabIndex = 20;
            this.picBox17.TabStop = false;
            this.picBox17.Click += new System.EventHandler(this.pictureBox22_Click);
            // 
            // picBox7
            // 
            this.picBox7.Location = new System.Drawing.Point(557, 124);
            this.picBox7.Name = "picBox7";
            this.picBox7.Size = new System.Drawing.Size(85, 70);
            this.picBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox7.TabIndex = 18;
            this.picBox7.TabStop = false;
            this.picBox7.Click += new System.EventHandler(this.pictureBox24_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 24);
            this.label1.TabIndex = 24;
            this.label1.Text = "Top";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(553, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 24);
            this.label2.TabIndex = 25;
            this.label2.Text = "right";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(351, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 24);
            this.label3.TabIndex = 26;
            this.label3.Text = "bottom";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(160, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 24);
            this.label4.TabIndex = 27;
            this.label4.Text = "left";
            // 
            // lblTop
            // 
            this.lblTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTop.Location = new System.Drawing.Point(54, 65);
            this.lblTop.Name = "lblTop";
            this.lblTop.Size = new System.Drawing.Size(100, 23);
            this.lblTop.TabIndex = 28;
            // 
            // lblLeft
            // 
            this.lblLeft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLeft.Location = new System.Drawing.Point(214, 65);
            this.lblLeft.Name = "lblLeft";
            this.lblLeft.Size = new System.Drawing.Size(100, 23);
            this.lblLeft.TabIndex = 29;
            // 
            // lblRight
            // 
            this.lblRight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRight.Location = new System.Drawing.Point(605, 63);
            this.lblRight.Name = "lblRight";
            this.lblRight.Size = new System.Drawing.Size(100, 23);
            this.lblRight.TabIndex = 30;
            // 
            // lblBottom
            // 
            this.lblBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBottom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBottom.Location = new System.Drawing.Point(424, 65);
            this.lblBottom.Name = "lblBottom";
            this.lblBottom.Size = new System.Drawing.Size(100, 23);
            this.lblBottom.TabIndex = 31;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 376);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 24);
            this.label5.TabIndex = 32;
            this.label5.Text = "Fish Speed";
            // 
            // txtSpeed
            // 
            this.txtSpeed.Location = new System.Drawing.Point(136, 380);
            this.txtSpeed.Name = "txtSpeed";
            this.txtSpeed.Size = new System.Drawing.Size(100, 20);
            this.txtSpeed.TabIndex = 33;
            // 
            // btnMove
            // 
            this.btnMove.Location = new System.Drawing.Point(268, 376);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(102, 50);
            this.btnMove.TabIndex = 34;
            this.btnMove.Text = "Move Fish";
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Click += new System.EventHandler(this.btnMove_Click);
            // 
            // btnAutoMove
            // 
            this.btnAutoMove.Location = new System.Drawing.Point(391, 376);
            this.btnAutoMove.Name = "btnAutoMove";
            this.btnAutoMove.Size = new System.Drawing.Size(102, 50);
            this.btnAutoMove.TabIndex = 35;
            this.btnAutoMove.Text = "Auto Move Fish";
            this.btnAutoMove.UseVisualStyleBackColor = true;
            this.btnAutoMove.Click += new System.EventHandler(this.button1_Click);
            // 
            // picBox8
            // 
            this.picBox8.Location = new System.Drawing.Point(649, 124);
            this.picBox8.Name = "picBox8";
            this.picBox8.Size = new System.Drawing.Size(85, 70);
            this.picBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox8.TabIndex = 36;
            this.picBox8.TabStop = false;
            // 
            // picBox11
            // 
            this.picBox11.Location = new System.Drawing.Point(194, 200);
            this.picBox11.Name = "picBox11";
            this.picBox11.Size = new System.Drawing.Size(85, 70);
            this.picBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox11.TabIndex = 37;
            this.picBox11.TabStop = false;
            // 
            // picFishLeft
            // 
            this.picFishLeft.Image = ((System.Drawing.Image)(resources.GetObject("picFishLeft.Image")));
            this.picFishLeft.Location = new System.Drawing.Point(504, 395);
            this.picFishLeft.Name = "picFishLeft";
            this.picFishLeft.Size = new System.Drawing.Size(20, 15);
            this.picFishLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFishLeft.TabIndex = 38;
            this.picFishLeft.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // picSharkRight
            // 
            this.picSharkRight.BackColor = System.Drawing.Color.Transparent;
            this.picSharkRight.Image = ((System.Drawing.Image)(resources.GetObject("picSharkRight.Image")));
            this.picSharkRight.Location = new System.Drawing.Point(530, 376);
            this.picSharkRight.Name = "picSharkRight";
            this.picSharkRight.Size = new System.Drawing.Size(69, 58);
            this.picSharkRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSharkRight.TabIndex = 39;
            this.picSharkRight.TabStop = false;
            // 
            // picFishRight
            // 
            this.picFishRight.Image = ((System.Drawing.Image)(resources.GetObject("picFishRight.Image")));
            this.picFishRight.Location = new System.Drawing.Point(620, 394);
            this.picFishRight.Name = "picFishRight";
            this.picFishRight.Size = new System.Drawing.Size(22, 16);
            this.picFishRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFishRight.TabIndex = 40;
            this.picFishRight.TabStop = false;
            // 
            // picSHarkLeft
            // 
            this.picSHarkLeft.Image = ((System.Drawing.Image)(resources.GetObject("picSHarkLeft.Image")));
            this.picSHarkLeft.Location = new System.Drawing.Point(668, 387);
            this.picSHarkLeft.Name = "picSHarkLeft";
            this.picSHarkLeft.Size = new System.Drawing.Size(37, 39);
            this.picSHarkLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSHarkLeft.TabIndex = 41;
            this.picSHarkLeft.TabStop = false;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 446);
            this.Controls.Add(this.picSharkRight);
            this.Controls.Add(this.picSHarkLeft);
            this.Controls.Add(this.picFishLeft);
            this.Controls.Add(this.picBox11);
            this.Controls.Add(this.picBox8);
            this.Controls.Add(this.btnAutoMove);
            this.Controls.Add(this.btnMove);
            this.Controls.Add(this.txtSpeed);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblBottom);
            this.Controls.Add(this.lblRight);
            this.Controls.Add(this.lblLeft);
            this.Controls.Add(this.lblTop);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picBox18);
            this.Controls.Add(this.picBox9);
            this.Controls.Add(this.picBox17);
            this.Controls.Add(this.picBox7);
            this.Controls.Add(this.picBox24);
            this.Controls.Add(this.picBox16);
            this.Controls.Add(this.picBox6);
            this.Controls.Add(this.picBox15);
            this.Controls.Add(this.picBox23);
            this.Controls.Add(this.picBox5);
            this.Controls.Add(this.picBox22);
            this.Controls.Add(this.picBox14);
            this.Controls.Add(this.picBox4);
            this.Controls.Add(this.picBox13);
            this.Controls.Add(this.picBox21);
            this.Controls.Add(this.picBox3);
            this.Controls.Add(this.picBox20);
            this.Controls.Add(this.picBox12);
            this.Controls.Add(this.picBox2);
            this.Controls.Add(this.picBox10);
            this.Controls.Add(this.picBox19);
            this.Controls.Add(this.picBox1);
            this.Controls.Add(this.picFishRight);
            this.Name = "FrmMain";
            this.Text = "Fish1";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFishLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSharkRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFishRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSHarkLeft)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBox1;
        private System.Windows.Forms.PictureBox picBox19;
        private System.Windows.Forms.PictureBox picBox10;
        private System.Windows.Forms.PictureBox picBox2;
        private System.Windows.Forms.PictureBox picBox12;
        private System.Windows.Forms.PictureBox picBox20;
        private System.Windows.Forms.PictureBox picBox22;
        private System.Windows.Forms.PictureBox picBox14;
        private System.Windows.Forms.PictureBox picBox4;
        private System.Windows.Forms.PictureBox picBox13;
        private System.Windows.Forms.PictureBox picBox21;
        private System.Windows.Forms.PictureBox picBox3;
        private System.Windows.Forms.PictureBox picBox24;
        private System.Windows.Forms.PictureBox picBox16;
        private System.Windows.Forms.PictureBox picBox6;
        private System.Windows.Forms.PictureBox picBox15;
        private System.Windows.Forms.PictureBox picBox23;
        private System.Windows.Forms.PictureBox picBox5;
        private System.Windows.Forms.PictureBox picBox18;
        private System.Windows.Forms.PictureBox picBox9;
        private System.Windows.Forms.PictureBox picBox17;
        private System.Windows.Forms.PictureBox picBox7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTop;
        private System.Windows.Forms.Label lblLeft;
        private System.Windows.Forms.Label lblRight;
        private System.Windows.Forms.Label lblBottom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSpeed;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.Button btnAutoMove;
        private System.Windows.Forms.PictureBox picBox8;
        private System.Windows.Forms.PictureBox picBox11;
        private System.Windows.Forms.PictureBox picFishLeft;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox picSharkRight;
        private System.Windows.Forms.PictureBox picFishRight;
        private System.Windows.Forms.PictureBox picSHarkLeft;
    }
}

