﻿namespace Tank
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.picBarrierLeft = new System.Windows.Forms.PictureBox();
            this.picBullet = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.picBarrierRight = new System.Windows.Forms.PictureBox();
            this.pictankleft = new System.Windows.Forms.PictureBox();
            this.pictankright = new System.Windows.Forms.PictureBox();
            this.picTank = new System.Windows.Forms.PictureBox();
            this.picEnemyleft = new System.Windows.Forms.PictureBox();
            this.EnemyTimer = new System.Windows.Forms.Timer(this.components);
            this.picEnemyRight = new System.Windows.Forms.PictureBox();
            this.picEnemy = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBarrierLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBullet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBarrierRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictankleft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictankright)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEnemyleft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEnemyRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEnemy)).BeginInit();
            this.SuspendLayout();
            // 
            // picBarrierLeft
            // 
            this.picBarrierLeft.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.picBarrierLeft.Location = new System.Drawing.Point(12, 12);
            this.picBarrierLeft.Name = "picBarrierLeft";
            this.picBarrierLeft.Size = new System.Drawing.Size(12, 419);
            this.picBarrierLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBarrierLeft.TabIndex = 0;
            this.picBarrierLeft.TabStop = false;
            // 
            // picBullet
            // 
            this.picBullet.BackColor = System.Drawing.Color.Maroon;
            this.picBullet.Location = new System.Drawing.Point(70, 52);
            this.picBullet.Name = "picBullet";
            this.picBullet.Size = new System.Drawing.Size(65, 52);
            this.picBullet.TabIndex = 1;
            this.picBullet.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // picBarrierRight
            // 
            this.picBarrierRight.BackColor = System.Drawing.SystemColors.HotTrack;
            this.picBarrierRight.Location = new System.Drawing.Point(712, 14);
            this.picBarrierRight.Name = "picBarrierRight";
            this.picBarrierRight.Size = new System.Drawing.Size(10, 417);
            this.picBarrierRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBarrierRight.TabIndex = 2;
            this.picBarrierRight.TabStop = false;
            // 
            // pictankleft
            // 
            this.pictankleft.BackColor = System.Drawing.Color.Transparent;
            this.pictankleft.Image = ((System.Drawing.Image)(resources.GetObject("pictankleft.Image")));
            this.pictankleft.Location = new System.Drawing.Point(42, 391);
            this.pictankleft.Name = "pictankleft";
            this.pictankleft.Size = new System.Drawing.Size(52, 45);
            this.pictankleft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictankleft.TabIndex = 3;
            this.pictankleft.TabStop = false;
            this.pictankleft.Visible = false;
            this.pictankleft.Click += new System.EventHandler(this.pictankleft_Click);
            // 
            // pictankright
            // 
            this.pictankright.BackColor = System.Drawing.Color.Transparent;
            this.pictankright.Image = ((System.Drawing.Image)(resources.GetObject("pictankright.Image")));
            this.pictankright.Location = new System.Drawing.Point(42, 395);
            this.pictankright.Name = "pictankright";
            this.pictankright.Size = new System.Drawing.Size(43, 47);
            this.pictankright.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictankright.TabIndex = 4;
            this.pictankright.TabStop = false;
            this.pictankright.Visible = false;
            // 
            // picTank
            // 
            this.picTank.BackColor = System.Drawing.Color.Transparent;
            this.picTank.Image = ((System.Drawing.Image)(resources.GetObject("picTank.Image")));
            this.picTank.Location = new System.Drawing.Point(50, 23);
            this.picTank.Name = "picTank";
            this.picTank.Size = new System.Drawing.Size(109, 96);
            this.picTank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTank.TabIndex = 5;
            this.picTank.TabStop = false;
            // 
            // picEnemyleft
            // 
            this.picEnemyleft.BackColor = System.Drawing.Color.Transparent;
            this.picEnemyleft.Image = ((System.Drawing.Image)(resources.GetObject("picEnemyleft.Image")));
            this.picEnemyleft.Location = new System.Drawing.Point(50, 395);
            this.picEnemyleft.Name = "picEnemyleft";
            this.picEnemyleft.Size = new System.Drawing.Size(35, 36);
            this.picEnemyleft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEnemyleft.TabIndex = 6;
            this.picEnemyleft.TabStop = false;
            // 
            // EnemyTimer
            // 
            this.EnemyTimer.Enabled = true;
            this.EnemyTimer.Interval = 150;
            this.EnemyTimer.Tick += new System.EventHandler(this.EnemyTimer_Tick);
            // 
            // picEnemyRight
            // 
            this.picEnemyRight.BackColor = System.Drawing.Color.Transparent;
            this.picEnemyRight.Image = ((System.Drawing.Image)(resources.GetObject("picEnemyRight.Image")));
            this.picEnemyRight.Location = new System.Drawing.Point(59, 397);
            this.picEnemyRight.Name = "picEnemyRight";
            this.picEnemyRight.Size = new System.Drawing.Size(26, 34);
            this.picEnemyRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEnemyRight.TabIndex = 7;
            this.picEnemyRight.TabStop = false;
            // 
            // picEnemy
            // 
            this.picEnemy.Location = new System.Drawing.Point(544, 301);
            this.picEnemy.Name = "picEnemy";
            this.picEnemy.Size = new System.Drawing.Size(162, 130);
            this.picEnemy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEnemy.TabIndex = 8;
            this.picEnemy.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 443);
            this.Controls.Add(this.picEnemy);
            this.Controls.Add(this.picEnemyRight);
            this.Controls.Add(this.picEnemyleft);
            this.Controls.Add(this.picTank);
            this.Controls.Add(this.pictankright);
            this.Controls.Add(this.pictankleft);
            this.Controls.Add(this.picBarrierRight);
            this.Controls.Add(this.picBullet);
            this.Controls.Add(this.picBarrierLeft);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.picBarrierLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBullet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBarrierRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictankleft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictankright)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEnemyleft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEnemyRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEnemy)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picBarrierLeft;
        private System.Windows.Forms.PictureBox picBullet;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox picBarrierRight;
        private System.Windows.Forms.PictureBox pictankleft;
        private System.Windows.Forms.PictureBox pictankright;
        private System.Windows.Forms.PictureBox picTank;
        private System.Windows.Forms.PictureBox picEnemyleft;
        private System.Windows.Forms.Timer EnemyTimer;
        private System.Windows.Forms.PictureBox picEnemyRight;
        private System.Windows.Forms.PictureBox picEnemy;
    }
}

