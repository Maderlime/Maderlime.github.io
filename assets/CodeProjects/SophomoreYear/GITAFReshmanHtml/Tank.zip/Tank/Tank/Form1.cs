﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Madeline Tjoa
//Period 0
//Tank game


namespace Tank
{
    public partial class Form1 : Form
    {

        int xspeed = 10;
        int yspeed = 10;

        int Hits = 0;
        int theDirection = 0;

        bool GameOver = false;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int Keypressed = e.KeyValue;
            int Bulletpressed = e.KeyValue;

            int xcord = picTank.Left;
            int ycord = picTank.Top;

            //determine whichKey key is pressed
            if (Keypressed == 37)
            {
                //move ship to the left
                xcord -= 10;
                picTank.Image = pictankleft.Image;
            }
            else if (Keypressed == 39)
            {
                //SHip goes right
                xcord += 10;
                picTank.Image = pictankright.Image;
            }
             if (Keypressed == 38)
            {
                ycord -= 10;
               
            }
            else if (Keypressed == 40)
            {
                ycord += 10;
                
            }

             if (picTank.Left < picBarrierLeft.Right - 10 && picTank.Top > picBarrierLeft.Top)
             {
                 xcord += 50;
             }
             if (picTank.Right > picBarrierRight.Left - 10)
             {
                 xcord -= 50;
             }

            picTank.Left = xcord;
            picTank.Top = ycord;

            if (Bulletpressed == 32)
            {
                picBullet.Visible = true;
                timer1.Enabled = true;
            }

            if (timer1.Enabled == false)
            {
                picBullet.Left = picTank.Left;
                picBullet.Top = picTank.Top;
            }

            ///////////////////////////////////////////////////////////////////////

            if (timer1.Enabled == false)
            {

                if ( Keypressed == 38)
                {
                    theDirection = 1;
                }

                else if (Keypressed == 40)
                {
                    theDirection = 2;
                }

                else if (Keypressed == 37)
                {
                    theDirection = 3;
                }

                else if (Keypressed == 39)
                {
                    theDirection = 4;
                }

            }


           


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int bulletY = picBullet.Top;
            int bulletX = picBullet.Left;

            if (theDirection == 1)
            {
                bulletY -= 10;
            }

            else if (theDirection == 2)
            {
                bulletY += 10;
            }
            else if (theDirection == 3)
            {
                bulletX -= 10;
            }
            else if (theDirection == 4)
            {
                bulletX += 10;
            }
            picBullet.Top = bulletY;
            picBullet.Left = bulletX;


            

            //When the bullet gets to the top a new bullet spawns for the Player
            if (picBullet.Top < -20)
            {
                timer1.Enabled = false;
                picBullet.Visible = false;
                picBullet.Left = picTank.Left;
                picBullet.Top = picTank.Top;
            }

            if (picBullet.Top > this.Height - 10)
            {
                timer1.Enabled = false;
                picBullet.Visible = false;
                picBullet.Left = picTank.Left;
                picBullet.Top = picTank.Top;
            }
            if (picBullet.Left < -20)
            {
                timer1.Enabled = false;
                picBullet.Visible = false;
                picBullet.Left = picTank.Left;
                picBullet.Top = picTank.Top;
            }
            if (picBullet.Left > this.Width)
            {
                timer1.Enabled = false;
                picBullet.Visible = false;
                picBullet.Left = picTank.Left;
                picBullet.Top = picTank.Top;
            }

            if (picBullet.Left > picEnemy.Left && picBullet.Right < picEnemy.Right &&
               picBullet.Top < picEnemy.Top)
            {

               
                picEnemy.Width -= 25;
                picEnemy.Height -= 25;
                picEnemy.Enabled = false;
                Hits += 1;

                timer1.Enabled = false;
                picBullet.Visible = false;
                picBullet.Left = picTank.Left;
                picBullet.Top = picTank.Top;
            }
            if (Hits == 3)
            {
                MessageBox.Show("Congratz you won!");
                picEnemy.Visible = false;         

            }

        }

        private void EnemyTimer_Tick(object sender, EventArgs e)
        {
            int enemyX = picEnemy.Left;
            int enemyY = picEnemy.Top;

            if (picEnemy.Left > picTank.Left)
            {
                picEnemy.Left -= 10;
                enemyX -= 10;
                picEnemy.Image = picEnemyleft.Image;
            }
            if(picEnemy.Left<picTank.Left)
            {
                picEnemy.Left += 10;
                enemyX += 10;
                picEnemy.Image = picEnemyRight.Image;
            }
            if (picEnemy.Top > picTank.Top)
            {
                picEnemy.Top -= 10;
                enemyY -= 10;
            }
            if (picEnemy.Top < picTank.Top)
            {
                picEnemy.Top += 10;
                enemyY += 10;
                
            }

            picEnemy.Left = enemyX;
            picEnemy.Top = enemyY;
            if (GameOver!=true)
            {
                if((picEnemy.Top>=picTank.Top&&picEnemy.Top<=picTank.Bottom)||(picEnemy.Bottom<=picTank.Bottom&&picEnemy.Bottom>=picTank.Top))
                {
                    if ((picEnemy.Left >= picTank.Left && picEnemy.Left <= picTank.Right) || (picEnemy.Right <= picTank.Right && picEnemy.Right >= picTank.Left))
                    {
                        GameOver = true;
                        MessageBox.Show("boo");
                    }
                }
            }

        }

        private void pictankleft_Click(object sender, EventArgs e)
        {

        }
    }
}
