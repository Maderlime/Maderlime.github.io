﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Madeline Tjoa
//period 0
//Fish 1

namespace GITAFish1
{
    public partial class Form1 : Form
    {      
        //declare an array to organize our pictureboxes
        PictureBox[] theTank = new PictureBox[8];
        //INTERGERS
        int Rightside = 0;
        int Leftside = 0;
        int fishpos = 0;
        //random generator
        System.Random r = new System.Random((int)System.DateTime.Now.Ticks);
        //BOOL
        Boolean onOff = false;       

        public Form1()
        {
            InitializeComponent();
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            try
            {
            //RANDOMLY MOVE FISH TO A PICBOX
            theTank[fishpos].Image = null;
            //create an interger for the new location or fishpos
            int NewLocation = 0;
                //the new location will be random either 0 or 2
            NewLocation = r.Next(0, 2);
           //if 0 is selected then the position is moved up by 1
                if (NewLocation == 0)
                {
                    fishpos++;
                   
                }
                //if 1 is selected then the position is moved down by 1
                if (NewLocation == 1)
                {
                    fishpos--;
                    picFish.Image.RotateFlip(RotateFlipType.RotateNoneFlipX);
                }
                //the fish pos will show the picFish
                theTank[fishpos].Image = picFish.Image;
            }
            catch
            {
                if (fishpos > 7)
                {
                    fishpos = 7;
                    Rightside += 1;
                    theTank[fishpos].Image = picFish.Image;
                }

                if (fishpos < 0)
                {
                    fishpos = 0;
                    Leftside += 1;
                    theTank[fishpos].Image = picFish.Image;
                }

            }

            lblLeft.Text = Leftside.ToString();
            lblRight.Text = Rightside.ToString();




        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // this code runs one time at startup

            theTank[0] = picBox1;
            theTank[1] = picBox2;
            theTank[2] = picBox3;
            theTank[3] = picBox4;
            theTank[4] = picBox5;
            theTank[5] = picBox6;
            theTank[6] = picBox7;
            theTank[7] = picBox8;
            int randomInterger = r.Next(0, 8);
            theTank[randomInterger].Image = picFish.Image;
            fishpos = randomInterger;
        }

        private void btnAutoMove_Click(object sender, EventArgs e)
        {
            //fish moves automatically
            if (onOff == false)
            {
                timer1.Enabled = true;
                onOff = true;
            }
            else if (onOff == true)
            {
                timer1.Enabled = false;
                onOff = false;
            }
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //this calls the move code
            btnMove_Click(sender, e);
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //Exit the program
            this.Close();
        }

        private void whatIsThisProgramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THis is an app that demonstrates the use of arrays and []");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Exit the program
            this.Close();
        }
    }
}
