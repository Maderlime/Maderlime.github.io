﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarField
{
    public partial class Form1 : Form
    {
        //Declare our array to hold the stars
        Label[] stars = new Label[8];

        System.Random r = new System.Random((int)System.DateTime.Now.Ticks);




        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Assign each star a position
            stars[0] = LblStar0;
            stars[1] = lblStar1;
            stars[2] = lblStar2;
            stars[3] = lblStar3;
            stars[4] = lblStar4;
            stars[5] = lblStar5;
            stars[6] = lblStar6;
            stars[7] = lblStar7;
            

            //For Loop
            for (int n = 0; n < 8; n++)
            {

                int randomx = r.Next(0, this.Width);
                int randomy = r.Next(0,this.Height);

                stars[n].Left = randomx;
                stars[n].Top = randomy;

                //Make stars different
                int theWidth = r.Next(1, 10);
                stars[n].Width = theWidth;
                stars[n].Height = theWidth;



            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Change the Size of the Stars
            for(int i=0;i<stars.Length; i++)
            {
            stars[i].Width +=1;
                stars[i].Height+=1;

                if(stars[i].Width >=10)
                {
                    int randomX = r.Next(0, this.Width);
                    int randomY = r.Next(0, this.Height);
                    stars[i].Left = randomX;
                    stars[i].Top = randomY;
                    stars[i].Width = 1;
                    stars[i].Height = 1;
                }
            }

            //make the stars move to right, left, up& down.
            for (int q = 0; q < 8; q++)
            {
               
                //top left quad
                if (stars[q].Left < this.Width / 2 && stars[q].Top < this.Height/2) 
                { 
                stars[q].Left -= 10;
                stars[q].Top -= 10;                
                }
                //
                if (stars[q].Left < this.Width / 2 && stars[q].Top > this.Height/2)
                {
                    stars[q].Left -= 10;
                    stars[q].Top += 10;
                }
                if (stars[q].Left > this.Width / 2 && stars[q].Top < this.Height/2)
                {
                    stars[q].Left += 10;
                    stars[q].Top -= 10;
                }
                if (stars[q].Left > this.Width / 2 && stars[q].Top > this.Height/2)
                {
                    stars[q].Left += 10;
                    stars[q].Top += 10;
                }

            }




        }
    }
}
