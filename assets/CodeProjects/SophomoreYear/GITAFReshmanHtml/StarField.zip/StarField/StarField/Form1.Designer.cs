﻿namespace StarField
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LblStar0 = new System.Windows.Forms.Label();
            this.lblStar1 = new System.Windows.Forms.Label();
            this.lblStar4 = new System.Windows.Forms.Label();
            this.lblStar3 = new System.Windows.Forms.Label();
            this.lblStar2 = new System.Windows.Forms.Label();
            this.lblStar7 = new System.Windows.Forms.Label();
            this.lblStar6 = new System.Windows.Forms.Label();
            this.lblStar5 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // LblStar0
            // 
            this.LblStar0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LblStar0.Location = new System.Drawing.Point(45, 73);
            this.LblStar0.Name = "LblStar0";
            this.LblStar0.Size = new System.Drawing.Size(22, 22);
            this.LblStar0.TabIndex = 2;
            // 
            // lblStar1
            // 
            this.lblStar1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblStar1.Location = new System.Drawing.Point(129, 73);
            this.lblStar1.Name = "lblStar1";
            this.lblStar1.Size = new System.Drawing.Size(22, 22);
            this.lblStar1.TabIndex = 3;
            // 
            // lblStar4
            // 
            this.lblStar4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblStar4.Location = new System.Drawing.Point(379, 73);
            this.lblStar4.Name = "lblStar4";
            this.lblStar4.Size = new System.Drawing.Size(22, 22);
            this.lblStar4.TabIndex = 4;
            // 
            // lblStar3
            // 
            this.lblStar3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblStar3.Location = new System.Drawing.Point(368, 209);
            this.lblStar3.Name = "lblStar3";
            this.lblStar3.Size = new System.Drawing.Size(22, 22);
            this.lblStar3.TabIndex = 5;
            // 
            // lblStar2
            // 
            this.lblStar2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblStar2.Location = new System.Drawing.Point(208, 73);
            this.lblStar2.Name = "lblStar2";
            this.lblStar2.Size = new System.Drawing.Size(22, 22);
            this.lblStar2.TabIndex = 7;
            // 
            // lblStar7
            // 
            this.lblStar7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblStar7.Location = new System.Drawing.Point(692, 73);
            this.lblStar7.Name = "lblStar7";
            this.lblStar7.Size = new System.Drawing.Size(22, 22);
            this.lblStar7.TabIndex = 8;
            // 
            // lblStar6
            // 
            this.lblStar6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblStar6.Location = new System.Drawing.Point(592, 73);
            this.lblStar6.Name = "lblStar6";
            this.lblStar6.Size = new System.Drawing.Size(22, 22);
            this.lblStar6.TabIndex = 9;
            // 
            // lblStar5
            // 
            this.lblStar5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblStar5.Location = new System.Drawing.Point(476, 73);
            this.lblStar5.Name = "lblStar5";
            this.lblStar5.Size = new System.Drawing.Size(22, 22);
            this.lblStar5.TabIndex = 10;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(751, 399);
            this.Controls.Add(this.lblStar5);
            this.Controls.Add(this.lblStar6);
            this.Controls.Add(this.lblStar7);
            this.Controls.Add(this.lblStar2);
            this.Controls.Add(this.lblStar3);
            this.Controls.Add(this.lblStar4);
            this.Controls.Add(this.lblStar1);
            this.Controls.Add(this.LblStar0);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LblStar0;
        private System.Windows.Forms.Label lblStar1;
        private System.Windows.Forms.Label lblStar4;
        private System.Windows.Forms.Label lblStar3;
        private System.Windows.Forms.Label lblStar2;
        private System.Windows.Forms.Label lblStar7;
        private System.Windows.Forms.Label lblStar6;
        private System.Windows.Forms.Label lblStar5;
        private System.Windows.Forms.Timer timer1;
    }
}

