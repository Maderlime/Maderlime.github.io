import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.BufferStrategy;

//public class BufferStrat extends Canvas{
//	
//	
//	Image[] questionArray = new Image[42];
//	Image[] bgArray = new Image[4];
//	Image[] bossArray = new Image[8];
//	Image[] playerArray = new Image[3];
//	Image[] arrowArray = new Image[4];
//	Image[] endArray = new Image[3];
//	Image[] transArray = new Image[3];
//	
//	int playerPositionX = 150,
//		playerPositionY = 320;
//	
//	int bossX = 600,
//		bossY = 217;
//	
//	int arrowX = 180,
//		arrowY = 350;
//	
//	int bgTrack = 2;
//	int endTrack = 0;
//	int healthTrack = 0;
//	int transTrack = 0;
//	int randomNum = (int)(Math.random() * 42);;
//	int randomBoss = 0;
//	int playerAni = 0;
//	int randomArrow = (int)(Math.random() * 3) + 1;
//	
//	BufferStrat(Image[] questionArray1, Image[] bgArray1, Image[] bossArray1, Image[] playerArray1, Image[] arrowArray1, Image[] endArray1, Image[] transArray1){
//		questionArray = questionArray1;
//		bgArray = bgArray1;
//		bossArray = bossArray1;
//		playerArray = playerArray1;
//		arrowArray = arrowArray1;
//		endArray = endArray1;
//		transArray = transArray1;
//		run();
//	}
//	public void run() {
//		while(true) {
//			update();
//			render();	
//		}
//	}
//	public void update() {
//		
//	}
//	public void render() {
//		BufferStrategy bs = getBufferStrategy();
//		if(bs == null) {
//			createBufferStrategy(3);
//			return;
//		}
//		
//		Graphics gr = bs.getDrawGraphics();
//		
////		gr.drawImage(bgArray[bgTrack], 0, 0, 1000, 675, this);
////		gr.drawImage(endArray[endTrack], 220, 250, 500, 200, this);
////		gr.drawImage(playerArray[playerAni], playerPositionX, playerPositionY, 125, 200, this);
////		gr.drawImage(bossArray[randomBoss], bossX, bossY, 300, 300, this);
////		gr.drawImage(arrowArray[randomArrow], arrowX, arrowY, 150, 75, this);	
////		gr.drawImage(transArray[transTrack], 0, 0, 1000, 675, this);
////		gr.drawImage(questionArray[randomNum], 1000, 0, 500, 250, this);//questions
//		gr.setColor(Color.black);
//		gr.fillRect(0, 0, 1000, 675);
//		gr.dispose();
//		bs.show();
//	}
//}

public class BufferStrat extends Canvas{
	public void update(Graphics g) {
		Graphics offgc;
		Image offscreen = null;
		
		offscreen = createImage(1000, 675);
		offgc = offscreen.getGraphics();
		offgc.setColor(getBackground());
		offgc.fillRect(0, 0, 1000, 675);
		offgc.setColor(getForeground());
		paint(offgc);
		g.drawImage(offscreen, 0, 0, this);
	}
}