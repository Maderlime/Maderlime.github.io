
public class DefineDimensions {
	int IStringLength;
	//String IStringText;
	public void setDimensions(int x) {
		//set the domestic variables equal to the foreign variables	
		IStringLength = x;
		//IStringText = SText;		
	}
}
