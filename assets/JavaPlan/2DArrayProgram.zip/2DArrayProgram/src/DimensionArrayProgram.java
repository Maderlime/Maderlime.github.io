import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class DimensionArrayProgram extends JApplet implements ActionListener{

	//Applet Designs
		//create text boxes
		JTextField txtInputRowString = new JTextField(20);
		JTextField txtInputColumnString = new JTextField(20);
		JTextField txtScore1 = new JTextField(20);
		//create text areas
		JTextArea txaresult = new JTextArea("\n", 30,30);
		JTextArea txaHarpoon = new JTextArea("", 10	,10);
		
		JScrollPane scrolly = new JScrollPane(txaresult, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
	   

		
		//create text buttons
		JButton btnSetRow = new JButton("Set Row Array");
		JButton btnAddColumn = new JButton("Set The Stuff");
		//create panels
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
		
		
	//end of applet designs
		
		
	
	DefineDimensions Strings[][]; // Create an array for DefineDimensions

	
	int arrayRowNumber, arrayColumnNumber; //Variables for setNumberOfArrays
	
	int arrayCount;
	
	int randomInput;
	
	int highestNumber, lowestNumber=100, averageNumber;
	
	String InputtedStrings;

//Create the init method(initialize method)
public void init() {

		//Applet Design Initialization: 
				//place components on the applet panel(Declaring method/functions that will be called)
					DesignInputPanel();
					DesignOutputPanel();
				//put the panels and buttons and stuff on the applet
					pnlMain.add(pnlInput);
					pnlMain.add(btnAddColumn);
					pnlMain.add(pnlOutput);
				
					
					
				//resize the applet
					resize(500,400);
				txtInputRowString.requestFocus();
				//set the content to the panel (or else it wont show up)
					setContentPane(pnlMain);
		//Actionlisteners
				btnAddColumn.addActionListener(this);
				btnSetRow.addActionListener(this);
				txtInputRowString.addActionListener(this);
				txtInputColumnString.addActionListener(this);
				

}		
//when you put the button it comes to this function
public void actionPerformed(ActionEvent event) {
	
		//2. information	
		try {
		
		//Code so that the buttons will work: 
			Object objSource = event.getSource();		/*Find the source of the action trigger*/
			
			if(objSource == btnAddColumn) {
				
				txaresult.setText("");
				
				arrayRowNumber = Integer.parseInt(txtInputRowString.getText());		/*Grab the string the user inputted and place into arrayNumber*/
				
				btnSetRow.setEnabled(false); /*disable btnSetRow so user cannot reset the array size*/
				
				arrayColumnNumber = Integer.parseInt(txtInputColumnString.getText());		/*set the Column Number*/
				
				Strings = new DefineDimensions[arrayRowNumber][arrayColumnNumber]; 	/*Set arrayNumber as the amt of slots for String Array*/
				
				
				/*
				DimensionCalculations theStringClass = new DimensionCalculations(InputtedStrings);
				//Transfer above variable into calculations class
				
				 * String LongestString = theStringClass.ReturnLongestString();
				String ShortestString = theStringClass.ReturnShortestString();
				String LowerCaseString = theStringClass.ReturnLowerCaseString();
				String UpperCaseString = theStringClass.ReturnUpperCaseString();
				   int LengthOfString = theStringClass.ReturnStringLength();
				*/
				   
				int totalAmountOfBoxes = 0;
				int totalAmountAdded = 0; 
				
				
				//fill up one slot
				for (int i = 0; i < arrayRowNumber; i++) {
					
						//arrayCount ++;
					
					
					for(int j = 0; j<arrayColumnNumber;j++) {
						
						randomInput = (int) ((Math.random() * 100) + 1); /*Generate the random number that will be placed*/
						
						Strings[i][j] = new DefineDimensions();
						Strings[i][j].setDimensions(randomInput);
						
						txaresult.append(" " + randomInput + " ");
						
						totalAmountOfBoxes = arrayColumnNumber * arrayRowNumber;
						totalAmountAdded += randomInput;
						
						
						
						//Calculating and Sorting code
							if(randomInput > highestNumber) {
								highestNumber = randomInput;
							}
							if(randomInput <= lowestNumber) {
								lowestNumber = randomInput;
							}
							
							int tempcounter = 0;
							for(int q = 1; q<101; q++) {
								if(randomInput == q) {
									tempcounter ++;
								}
							}
							if(tempcounter > 1) {
							//	txaresult.append("amount of " + q + ": " + tempcounter + "\n");
								}
								
						/*End of Sorting Code*/
						
					}	
						txaresult.append("\n");
				}	
				
				
				int numbers[] = new int[101];
				int record = 2;
				int recordNumber = 0;
				
				for(int i = 0; i <arrayRowNumber; i++) {
					for(int j=0; j< arrayColumnNumber; j++) {
						int temptotal = 0;
						numbers[Strings[i][j].IStringLength] += 1;
						temptotal = numbers[Strings[i][j].IStringLength];
						
						//System.out.println(numbers[Strings[i][j].IStringLength] + ":" + Strings[i][j].IStringLength);
						
						if(temptotal >= record) {
							//System.out.println(Strings[i][j].IStringLength + " Amount: " + numbers[Strings[i][j].IStringLength]);
							record = temptotal;	
							recordNumber =  Strings[i][j].IStringLength;
						}
						
						
					}	
				}
				
				
				
				
				averageNumber = totalAmountAdded/totalAmountOfBoxes;
				
				txaresult.append("Highest Number: " + highestNumber + "\n"
									+ "Lowest Number: " + lowestNumber + "\n"
									+ "Average Number: " + averageNumber + 
									"\n Most Common Number: " + recordNumber + " was shown " + record + " times.");
				
				//output in the text Area
				//txaresult.setText("");
				
				for(int i=0; i<1; i++) {
					
					}
				
				
			}//end of btnAddColumn
			
			
		
		
		
		}
		catch(NumberFormatException err){			
		showStatus("please make sure you've entered everything!");
		}

}				

//Create DesignnputPanel()
public void DesignInputPanel() {
pnlInput.setLayout(new GridLayout(0,2));
pnlInput.add(new JLabel("Row : "));
pnlInput.add(txtInputRowString);
pnlInput.add(new JLabel("Column : "));
pnlInput.add(txtInputColumnString);

}		
public void DesignOutputPanel() {
pnlOutput.setLayout(new GridLayout(0,1));
pnlOutput.add(scrolly);
//pnlOutput.add(txaHarpoon);
}
	
}

