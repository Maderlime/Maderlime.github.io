import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class BinarySearch extends JApplet implements ActionListener {

	JTextArea txaresult = new JTextArea("\n", 30,30);
	JButton btnSet = new JButton("Place my Knight");
	JPanel pnlMain = new JPanel();
	JPanel pnlInput = new JPanel();
	JPanel pnlOutput = new JPanel();
	
	
	JScrollPane scrolly = new JScrollPane(txaresult, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	
	//variables
	//int[][] placementArray = new int[5000];
	
	int ColumnLocation, RowLocation;
	String ColumnLetter;
	int nada = 1;
	
	public void init() { 
		
		DesignInputPanel();
		DesignOutputPanel();

		pnlMain.add(pnlInput);	
		pnlMain.add(btnSet);
		pnlMain.add(pnlOutput);	
		btnSet.requestFocus();
		resize(500,400);
	
		setContentPane(pnlMain);
		btnSet.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		
			try {
					Object objSource = e.getSource();		/*Find the source of the action trigger*/
					
					if(objSource == btnSet) {
						
						StringBuilder drool = new StringBuilder();
						StringBuilder sb = new StringBuilder();
						StringBuilder sbStats = new StringBuilder();
						
						
						BinarySearchCalculations TheKnightClass = new BinarySearchCalculations();
						sb = TheKnightClass.ReturnedArrayList();
						drool = TheKnightClass.Booperpoop();
						sbStats = TheKnightClass.ReturnedStatistics();
						String boop = TheKnightClass.ReturnedStringList();
						
						
						txaresult.setText("hello freend: \n" + sbStats + "\n The produced array: " + sb + " \n Amount of time it took to find each array" + drool);
						
					}	
						
					
					
			}
			catch(NumberFormatException err){			
				showStatus("please make sure you've entered everything!");
			}
		
	}
	
	public void DesignInputPanel() {
		pnlInput.setLayout(new GridLayout(0,2));

		}		
		public void DesignOutputPanel() {
		pnlOutput.setLayout(new GridLayout(0,1));

		//pnlOutput.add(txaresult);
		pnlOutput.add(scrolly);
		}
	
}
