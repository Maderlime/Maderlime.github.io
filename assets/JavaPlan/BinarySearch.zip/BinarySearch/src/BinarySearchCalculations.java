import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Random;

public class BinarySearchCalculations {

	int numberArray[] = new int[5000];
	
	int searchArray[] = new int [5000];
	
	
	Random rn = new Random();
	
	String lineSeparator = System.lineSeparator();
	StringBuilder sb = new StringBuilder();
	
	StringBuilder randomlist = new StringBuilder();
	
	
	StringBuilder sbStats = new StringBuilder();
	
	int foxynoswiping;
	double foxyisilluminati = 0;
	
	String yes;
	
	BinarySearchCalculations(){
		
		Calculations();
		
	}
	
		private void Calculations(){

			
			//placing numbers into array
			for (int Row = 0  ; Row < 5000; Row++) { 
				int Randomizer;
				Randomizer = rn.nextInt(4999);		
				numberArray[Row] = Randomizer;
				
				//System.out.println(Randomizer + " : " );		
					//System.out.print(numberArray[Row] + "curse bananas \n");
					
			}
			
			Arrays.sort(numberArray); // sort
				for(int hi = 0; hi < 5000; hi++) {
					sb.append(numberArray[hi] + ", ");	
				}
			//checking and looking for random number
			
			double collectedturntimes = 0;
			double average = 0;
			
			int mysteriouspenguin = 0;
			
			for(int i=0; i < 5000; i++) {	//run it 5000 times
					
					yes = "yes";
						
					foxynoswiping = rn.nextInt(4999); //grab a random number to find in the array
			
					int themaxnumber = 5000;
					
					int theminnumber = 0;
					
					int themiddlenumber = (themaxnumber + theminnumber) /2;
										
					foxyisilluminati = 0; 
					
					for(int j = 0; j < 20;j++) {
						
						foxyisilluminati ++;	
						
							themiddlenumber = (themaxnumber + theminnumber) /2;
						
							if(numberArray[themiddlenumber] > foxynoswiping	) { //then make the search parameter the bottom of the divadoop number.
								
								themaxnumber = themiddlenumber;
							
							}
							else if(numberArray[themiddlenumber] < foxynoswiping) { //then make the search parameter the top of the divadoop number.
								
								theminnumber = themiddlenumber; 
								
							}			
							else if(numberArray[themiddlenumber] == (foxynoswiping)) {		
							
								System.out.println("RELEASE THE KRACKEN");
								
								break;
							 
							}
							
							if(theminnumber>= themaxnumber || j>14) {
							
								System.out.println("cunnot feind");
								yes = "no";
								foxyisilluminati = 0;
								mysteriouspenguin ++;
								break;
							}
																			
					}//end of inner for loop
							
					collectedturntimes += foxyisilluminati;					
					randomlist.append(foxyisilluminati + ", ");
					//sbStats.append("Average of the random number existed?  " + yes + " ; \n \t Number Locating: " + foxynoswiping +"\n \t found at try : " + foxyisilluminati + "\n");
					
			}//End of for loop
			
			average = collectedturntimes / (5000 - mysteriouspenguin);
			
			sbStats.append("Average tries it took to find random numbers: " + average);
			
			
		}
	
		
		
		public StringBuilder ReturnedArrayList() {
			return sb;
			
		}
		
		public StringBuilder Booperpoop() {
			return randomlist;
			
		}
	
		public String ReturnedStringList() {
			
			String stringVar = java.util.Arrays.toString( numberArray );
			return stringVar;
		}
	
		public StringBuilder ReturnedStatistics() {
			
			return sbStats;
		}
	
	
	
}
