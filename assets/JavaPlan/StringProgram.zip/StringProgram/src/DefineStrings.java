
public class DefineStrings {
	int IStringLength;
	String IStringText;
	public void setStrings(/*foreign variables: */int x, String SText) {
		//set the domestic variables equal to the foreign variables	
		IStringLength = x;
		IStringText = SText;		
	}
}
