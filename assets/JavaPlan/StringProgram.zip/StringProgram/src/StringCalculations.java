
public class StringCalculations {
	
	private String InputtedString; //General need
	
	static private String uppercaseString, lowercaseString, equalString, longestString, shortestString;
	
	static private int lengthOfLongestString = 0, LengthOfShortestString = 0, LengthOfEqualString;
	
	private int amountOfNumbersInString;
	
	StringCalculations(String Inputted){
		
		InputtedString = Inputted; /*Set number given to class equal to InputtedString*/
		
		amountOfNumbersInString = InputtedString.length( ); //grab string length
		
		CalculateString(); /*Go into the Calculate Function*/
	
	}
	
	private void CalculateString() {
		
		/*Calculate the longest string*/
		if(amountOfNumbersInString > lengthOfLongestString) {
			
			lengthOfLongestString = amountOfNumbersInString; // Change int value record
			
			longestString = InputtedString; 
			
		}
		
		/*Calculate the shortest string*/
		if(amountOfNumbersInString < LengthOfShortestString || LengthOfShortestString == 0) {
			
			LengthOfShortestString = amountOfNumbersInString; //change int value record
			
			shortestString = InputtedString;
			
		}
		
		/*Calculate whether there are any even Strings*/
		/*
		 * 
		 * To be continued
		 * 
		 * */
		
		/*Make String All upper case*/
		uppercaseString = InputtedString.toUpperCase();
		
		/*Make String all lower case*/
		lowercaseString = InputtedString.toLowerCase();
		
		
	}
	
	public String ReturnLongestString() {
		return longestString;
	}
	
	public String ReturnShortestString() {
		return shortestString;
	}
	
	public String ReturnUpperCaseString() {
		return uppercaseString;
	}
	
	public String ReturnLowerCaseString() {
		return lowercaseString;
	}
	
	public int ReturnStringLength() {
		return amountOfNumbersInString;
	}
	
	
}



