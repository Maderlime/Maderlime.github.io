import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class StringProgram extends JApplet implements ActionListener{

	//Applet Designs
		//create text boxes
		JTextField txtInputString = new JTextField(20);
		JTextField txtScore1 = new JTextField(20);
		//create text areas
		JTextArea txaresult = new JTextArea(
				"Score" + "\n", 10,15);
		JTextArea txaHarpoon = new JTextArea(" word history: ", 10,33);
		//create text buttons
		JButton btnSet = new JButton("Set String Array");
		JButton btnAdd = new JButton("Convert String");
		//create panels
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	//end of applet designs
		
		
	
	DefineStrings Strings[]; // Create an array for DefineStrings

	
	int arrayNumber; //Variables for setNumberOfArrays
	
	int arrayCount;
	
	String InputtedStrings;

//Create the init method(initialize method)
public void init() {

		//Applet Design Initialization: 
				//place components on the applet panel(Declaring method/functions that will be called)
					DesignInputPanel();
					DesignOutputPanel();
				//put the panels and buttons and stuff on the applet
					pnlMain.add(pnlInput);
					pnlMain.add(btnAdd);
					pnlMain.add(btnSet);
					pnlMain.add(pnlOutput);
				
				//resize the applet
					resize(500,400);
				txtInputString.requestFocus();
				//set the content to the panel (or else it wont show up)
					setContentPane(pnlMain);
		//Actionlisteners
				btnAdd.addActionListener(this);
				btnSet.addActionListener(this);
				txtInputString.addActionListener(this);
				
				

}		
//when you put the button it comes to this function
public void actionPerformed(ActionEvent event) {
	
		//2. information	
		try {
		
		//Code so that the buttons will work: 
			Object objSource = event.getSource();		/*Find the source of the action trigger*/
			if(objSource == btnSet) {
				
				arrayNumber = Integer.parseInt(txtInputString.getText());/*Grab the string the user inputted and place into arrayNumber*/

				Strings = new DefineStrings[arrayNumber]; /*Set arrayNumber as the amt of slots for String Array*/
			
				btnSet.setEnabled(false); /*disable btnSet so user cannot reset the array size*/
				
			}
			if(objSource == btnAdd) {
				
				InputtedStrings = txtInputString.getText(); /*Set userInput into a use able variable*/
				
				StringCalculations theStringClass = new StringCalculations(InputtedStrings); //Transfer above variable into calculations class*/
				String LongestString = theStringClass.ReturnLongestString();
				String ShortestString = theStringClass.ReturnShortestString();
				String LowerCaseString = theStringClass.ReturnLowerCaseString();
				String UpperCaseString = theStringClass.ReturnUpperCaseString();
				   int LengthOfString = theStringClass.ReturnStringLength();
				   
				//fill up one slot
				for (int i = 0; i <1; i++) {
					arrayCount ++;
					Strings[i] = new DefineStrings();
					Strings[i].setStrings(LengthOfString, InputtedStrings);
				}	
				
				//output in the text Area
				txaresult.setText("Longest String: "    + LongestString + "\n"
							    + "Shortest String: "   + ShortestString + "\n"
								+ "lowercase String: "  + LowerCaseString + "\n"
								+ "uppercase String: "  + UpperCaseString);
				
				for(int i=0; i<1; i++) {
					
					txaHarpoon.setText(txaHarpoon.getText() + "\n \t "  + Strings[i].IStringText + "| number of letters:" + Strings[i].IStringLength);
				
				}
				
				if(arrayCount >5) {
					arrayCount =0;
					btnAdd.setEnabled(false);
				}
				
			}//end of btnAdd
			
			
		
		
		
		}
		catch(NumberFormatException err){			
		showStatus("please make sure you've entered everything!");
		}

}				

//Create DesignnputPanel()
public void DesignInputPanel() {
pnlInput.setLayout(new GridLayout(0,2));
pnlInput.add(new JLabel("String : "));
pnlInput.add(txtInputString);

}		
public void DesignOutputPanel() {
pnlOutput.setLayout(new GridLayout(0,1));
pnlOutput.add(txaresult);
pnlOutput.add(txaHarpoon);
}
	
}
