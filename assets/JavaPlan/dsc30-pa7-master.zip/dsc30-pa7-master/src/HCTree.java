
import java.io.*;
import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Stack;

/**
 * Madeline Tjoa
 * A15394053
 *
 * The Huffman Coding Tree
 */
public class HCTree {

    private static final int NUM_CHARS = 256; // alphabet size of extended ASCII

    private HCNode root; // the root of HCTree
    // the leaves of HCTree that contain all the symbols
    private HCNode [] leaves = new HCNode[NUM_CHARS];


    /**
     * The Huffman Coding Node
     */
    protected class HCNode implements Comparable<HCNode> {

        byte symbol; // the symbol contained in this HCNode
        int freq; // the frequency of this symbol
        HCNode c0, c1, parent; // c0 is the '0' child, c1 is the '1' child
        
        /**
         * Initialize a HCNode with given parameters
         * @param symbol the symbol contained in this HCNode
         * @param freq the frequency of this symbol
         */
        HCNode(byte symbol, int freq) {
            this.symbol = symbol;
            this.freq = freq;
        }

        /**
         * Getter for symbol
         * @return the symbol contained in this HCNode
         */
        byte getSymbol() {
            return this.symbol;
        }

        /**
         * Setter for symbol
         * @param symbol the given symbol
         */
        void setSymbol(byte symbol) {
            this.symbol = symbol;
        }

        /**
         * Getter for freq
         * @return the frequency of this symbol
         */
        int getFreq() {
            return this.freq;
        }

        /**
         * Setter for freq
         * @param freq the given frequency
         */
        void setFreq(int freq) {
            this.freq = freq;
        }

        /**
         * Getter for '0' child of this HCNode
         * @return '0' child of this HCNode
         */
        HCNode getC0() {
            return c0;
        }

        /**
         * Setter for '0' child of this HCNode
         * @param c0 the given '0' child HCNode
         */
        void setC0(HCNode c0) {
            this.c0 = c0;
        }

        /**
         * Getter for '1' child of this HCNode
         * @return '1' child of this HCNode
         */
        HCNode getC1() {
            return c1;
        }

        /**
         * Setter for '1' child of this HCNode
         * @param c1 the given '1' child HCNode
         */
        void setC1(HCNode c1) {
            this.c1 = c1;
        }

        /**
         * Getter for parent of this HCNode
         * @return parent of this HCNode
         */
        HCNode getParent() {
            return parent;
        }

        /**
         * Setter for parent of this HCNode
         * @param parent the given parent HCNode
         */
        void setParent(HCNode parent) {
            this.parent = parent;
        }

        /**
         * Check if the HCNode is leaf
         * @return if it's leaf, return 1. Otherwise, return 0.
         */
        boolean isLeaf() {
            return (c0 == null) && (c1 == null);
        }
        
        public String toString() {
            return "Symbol: " +
                    this.symbol + "; Freq: " + this.freq;
        }

        /**
         * First, recall that the default behavior of compareTo method is:
         * return positive number if “this” is considered “larger”
         * than the given object.
         *
         * @param o the node that is going to be compared
         * @return int of the result of the comparison
         * */
        public int compareTo(HCNode o) {
            // TODO
            if(this.getFreq() > o.getFreq()){
                return 1;
            }
            else if(this.getFreq()< o.getFreq()){
                return -1;
            }
            else{
                if(this.getSymbol() > o.getSymbol()){
                    return 1;
                }
                else if(this.getSymbol() < o.getSymbol()){
                    return -1;
                }
                else{
                    return 0;
                }
            }
        }
    }

    public HCNode getRoot() {
        return root;
    }
    
    public void setRoot(HCNode root) {
        this.root = root;
    }

    /**
     * This method takes in an int array of size 256, which is the size of extended ASCII.
     * (Since each byte is 8 bits, then the number of all the possible bytes is
     * simply 2^8 = 256). The given array was used to keep track of the frequency
     * of each byte from the input file. For example, if ‘a’ appears in the input file
     * 7 times, then the element at index 97 (which is the ASCII value of ‘a’) of freq
     * would be 7. Note that to get the symbol ‘a’ back from its ASCII value 97, you can
     * simply cast the int to char by doing : char a = (char)97
     *
     * @param freq the frequency array of the values in ascii
     * */
    public void buildTree(int[] freq) {

        // initialize a priority queue of HCNode
        PriorityQueue<HCNode> pq = new PriorityQueue<>();

        //populate the frequency, and add to the priority queue
        for(int i = 0; i < freq.length; i++){
            if(freq[i] > 0){
                HCNode myNewLeaf =  new HCNode((byte)i, freq[i]);
                leaves[(byte)i] = myNewLeaf;
                pq.add(myNewLeaf);
            }
        }

        if(pq.size() == 1){
            HCNode mum = new HCNode((byte)0,0);
            HCNode kid = pq.poll();
            mum.setC0(kid);
            kid.setParent(mum);
            this.root = mum;
            return;
        }

        while(pq.size()>1){

            HCNode myc0 = pq.poll();
            HCNode myc1 = pq.poll();
            HCNode myMommy = new HCNode(myc0.getSymbol(),myc0.getFreq() + myc1.getFreq());

            myMommy.setC0(myc0);
            myMommy.setC1(myc1);
            myc0.setParent(myMommy);
            myc1.setParent(myMommy);

            pq.add(myMommy);
        }

        this.root = pq.poll();

    }

    /**
     * For a given symbol, use the HCTree built before to find
     * its encoding bits and write those bits to the given BitOutputStream.
     *
     * In this method, to avoid inefficiently searching the whole tree
     * to find the encoding bits of the given symbol, you must take
     * advantage of the leaf array that we created before:
     * it's much faster to start from the leaf node containing
     * the given symbol, and then traverse back to the root.
     * You will then simply collect all the bits on that path
     * and reverse those bits at the end to get the encoding.
     *
     * IMPORTANT: The following code will convert a byte c to its
     * corresponding ascii value: int ascii = c & 0xff;
     *
     * Once you get the encoding bits, you should use
     * out.writeBit(int i) that takes in either 0 or 1
     * as a bit to write the encoding bits one by one to
     * BitOutputStream.
     *
     * @param symbol The symbol that is passed in
     * @param out where the resultant 1 or 0 will be spit out
     * */
    public void encode(byte symbol, BitOutputStream out) throws IOException{

        // TODO
        int ascii = symbol & 0xff;

        Stack<Integer> myBits = new Stack<>();

        HCNode theMother = leaves[ascii];

        // keep running until we get to the root
        while(theMother != root) {
            if (theMother.getParent().getC0() == theMother) {
                myBits.push(0);
            } else {
                myBits.push(1);
            }
            theMother = theMother.getParent();
        }
        //out write the encoded files
        while(!myBits.empty()){
            out.writeBit(myBits.pop());
        }
    }

    //make a helper method that takes in a byte symbol returns
    // a string of the encoding in a string(out as a string)

    /**
     * Decodes the bits from BitInputStream and returns a byte
     * that represents the symbol that is encoded by a sequence of
     * bits from BitInputStream.
     *
     * @param in the bit that will be decoded
     * @return a byte that is the result of the decode operation
     * */
    public byte decode(BitInputStream in) throws IOException{

        HCNode rootIterator = this.getRoot();
        // keep running until the rootIterator is a leaf
        while(!rootIterator.isLeaf()) {

            if(in.readBit() == 0){
                rootIterator = rootIterator.getC0();
            }
            else{
                rootIterator = rootIterator.getC1();
            }
        }
        //found leaf node and return symbol
        return rootIterator.getSymbol();

    }

    /**
     * Since there are two kinds of node in our HCTree:
     * leaf node storing the actual symbol,
     * and non-leaf node as the “branch” to build the tree,
     * we surely need to distinguish those two cases.
     * Therefore, we can use bit “1” to represent a leaf node,
     * with the following 8 bits (1 byte) being the symbol in that leaf node.
     * And use bit “0” to represent a non-leaf node.
     *
     * By applying the rule above,
     * you can use a recursive pre-order traversing to “print out”
     * the structure of the HCTree in bits.
     *
     * Hint: Two methods writeBit() and writeByte() in BitInputStream
     * might be handy in this method
     *
     * @param node the starting node of the tree that will be encoded
     * @param out the output stream that is going to be written
     * */
    public void encodeHCTree(HCNode node, BitOutputStream out) throws IOException{
        //if the node is a leaf write 1
        if(node.isLeaf()){
            out.writeBit(1);
            out.writeByte(node.getSymbol());
        }
        //if the node is not a leaf write 0
        else {
            out.writeBit(0);

            encodeHCTree(node.getC0(), out);

            encodeHCTree(node.getC1(), out);
        }

    }

    /**
     * In this method, we will be building the original HCTree from the
     * header that we “printed” in bits when encoding the HCTree.
     *
     * The process of building the original HCTree from the header is similar to
     * how we build HCTree before: starting from the leaf,
     * build the branch all the way to the root.
     * But instead of keep removing from priority queue,
     * we will use recursion to keep getting new c0 and c1 and
     * connect them using a new parent node.
     *
     * During encoding HCTree, we used bit “1” to represen
     * t a leaf node followed by its 1 byte symbol.
     * Therefore, to rebuild the HCTree back in decoding,
     * whenever the next bit is “1”,
     * we will take the following 8 bits (1 byte) as the
     * symbol of a new leaf node.
     * You must remember to update the leave array to
     * make the your encoding possible.
     * Then you should return the new leaf node to make
     * it accessible to its parent in
     * the previous recursion.
     *
     * Otherwise, the next bit must be “0”, and then we will just
     * keep using recursion to read
     * the bitstream until we can find two leaf nodes from the recursion.
     * We will then simply connect them using a new parent and
     * return the new parent to make it accessible to its parent
     * in the previous recursion.
     *
     * IMPORTANT:
     * byte c to its corresponding ascii value: int ascii = c & 0xff;
     *
     * Hint: Two methods readBit() and readByte()
     * in BitOutputStream might be handy in this method
     *
     * @param in the input stream that will be put in
     * @return the node of the decoded tree
     * */
    public HCNode decodeHCTree(BitInputStream in) throws IOException {

        int myBitSym = in.readBit();

        //if the bit is -1 then return
        if(myBitSym == -1){
            return null;
        }

        if(myBitSym == 1){
            //we know its a leaf

            HCNode newNodeTemp = new HCNode(in.readByte(), 0);
            //byte nextByte = in.readByte();
            setRoot(newNodeTemp);

            int ascii = newNodeTemp.getSymbol() & 0xff;
            //create a new node and insert it into our leaves and return the node
            leaves[ascii] = newNodeTemp;
            //this is the base case
            return leaves[ascii];

        }
        else{
            // its a branch ( non leaf)
            //we want to build the tree up,
            //look for two children
            HCNode child0 = decodeHCTree(in);
            HCNode child1 = decodeHCTree(in);

            HCNode papa = new HCNode(child0.getSymbol(),0);

            //have c0 and c1 done using recusion on the way down
            //also create a parent
            papa.setC0(child0);
            papa.setC1(child1);
            child0.setParent(papa);
            child1.setParent(papa);

            return papa; //it also will have a parent

        }

    }

    /**
     * in-order traversal method to recursively traverse your HCTree,
     * and in-orderly print all the nodes in your HCTree out.
     * (Note that toString() method for HCNode was defined for you,
     * so you can directly use it to print the node out)
     *
     * @param root the beginning root of what is going to be printed
     * */
    public void inorder(HCNode root){
        // print in order
        if (root == null) {
            return;
        } else {
            inorder(root.getC0());
            System.out.println(root);
            inorder(root.getC1());
        }

    }
}
