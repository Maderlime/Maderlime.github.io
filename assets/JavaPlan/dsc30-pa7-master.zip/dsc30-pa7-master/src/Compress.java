import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
/**
 *  * Madeline Tjoa
 *  * A15394053
 *
 *  Compress the data bits
 *
 * */
public class Compress {
    private static final int NUM_CHARS = 256;

    private static final int EXP_ARG = 2; // number of expected arguments

    public static void main(String[] args) throws IOException {

        // Check if the number of arguments is correct
        if (args.length != EXP_ARG) {
            System.out.println("Invalid number of arguments.\n" +
                                "Usage: ./compress <infile outfile>.\n");
            return;
        }

        // read all the bytes from the given file and make it to a byte array
        byte[] input = Files.readAllBytes(Paths.get(args[0])); // array of characters in my file

        FileOutputStream file = new FileOutputStream(args[1]); // what we will be appending to
        DataOutputStream out  = new DataOutputStream(file);
        BitOutputStream bitOut = new BitOutputStream(out);


        // make sure that the input is not empty
        if(input.length == 0){
            out.close();
            file.close();;
            return;
        }

        int[] frequencyArray = new int[NUM_CHARS];

        int numberOfBytesInFile = input.length;

        //an array of frequency
        for (int i = 0; i < numberOfBytesInFile; i++) {
            int ascii = input[i] & 0xff;
            frequencyArray[ascii]++;
        }

        int counter = 0;

        // count how many symbols have frequencies
        for(int i = 0; i< frequencyArray.length; i++){
            if(frequencyArray[i] >= 1){
                counter ++;
            }
        }
        // there is only one character
        if (counter == 1) {
            // System.out.println("single character");
            out.writeInt(input.length);
            //its a single character
            // for(int i = 0; i < input.length; i++) {
                bitOut.writeBit(0);
                bitOut.writeByte(input[0]);

            // }
            // System.out.println(input.length);
            bitOut.flush();
            out.close();
            file.close();
        }
        // for what have multiple characters
        else {
            out.writeInt(input.length);
            // System.out.println(input.length);
            // HCTree goods
            HCTree myTree = new HCTree();
            myTree.buildTree(frequencyArray);

            myTree.inorder(myTree.getRoot());

            bitOut.writeBit(1);

            myTree.encodeHCTree(myTree.getRoot(), bitOut);

            //encode each bit
            for (int i = 0; i < numberOfBytesInFile; i++) {
                myTree.encode(input[i], bitOut);
            }

            bitOut.flush();
            out.close();
            file.close();

        }
    }
}
