

import static org.junit.Assert.*;

public class HCTreeTester {

    int[] myFreqArray = new int[256];

    HCTree myTree = new HCTree();

    @org.junit.Before
    public void setUp() throws Exception {
        // a: 17   b: 8   c: 7   d: 14   e: 9   f: 1   \n (newline char): 1
        myFreqArray[97] = 17;
        myFreqArray[98] = 8;
        myFreqArray[99] = 7;
        myFreqArray[100] = 14;
        myFreqArray[101] = 9;
        myFreqArray[102] = 1;
        myFreqArray[10] = 1;
    }
    @org.junit.Test
    public void buildTree() {
        myTree.buildTree(myFreqArray);
        //System.out.println(myTree.getRoot());
        myTree.inorder(myTree.getRoot());
    }
}