import java.io.*;

/**
 * Madeline Tjoa
 * A15394053
 *
 * Decompress the first given file to the second given file using Huffman coding
 */
public class Decompress {
    private static final int EXP_ARG = 2; // number of expected arguments

    public static void main(String[] args) throws IOException {

        // Check if the number of arguments is correct
        if (args.length != EXP_ARG) {
            System.out.println("Invalid number of arguments.\n" +
                    "Usage: ./uncompress <infile outfile>.\n");
            return;
        }

        FileInputStream inFile = new FileInputStream(args[0]);
        DataInputStream in = new DataInputStream(inFile);
        BitInputStream bitIn = new BitInputStream(in);

        FileOutputStream outFile = new FileOutputStream(args[1]);
        DataOutputStream out = new DataOutputStream(outFile);

        // TODO

        //check if it is an empty file
        File newFile = new File(args[0]);
        if(newFile.length() <= 1){
            // System.out.println("found no file or empty file dood");
        }
        else {
            // System.out.println("found a file good");
            //int inbit = bitIn.readBit();
            int byteCount = in.readInt();

            // check the first bit to see what kind of tree it is
            int typeOfTree = bitIn.readBit();

            //if it is a single char tree
            if(typeOfTree == 0){
                byte myChar = bitIn.readByte();
                //write the one char for the amount of bytes there are
                for(int i = 0; i < byteCount; i++){
                    out.writeByte(myChar);
                }
            }
            else {
                // for normal trees
                HCTree myTree = new HCTree();
                HCTree.HCNode myRoot = myTree.decodeHCTree(bitIn);

                myTree.setRoot(myRoot);
                myTree.inorder(myRoot);

                //write out the bit
                for (int i = 0; i < byteCount; i++) {
                    // byte symbol, BitOutputStream out
                    byte b = myTree.decode(bitIn);
                    out.writeByte(b);
                }
            }
        }

        inFile.close();
        in.close();
        outFile.close();
        out.close();
        return;
    }
}
