/**
 * Name: Madeline Tjoa
 * PID: A15394053
 * */
import java.util.ArrayList;

/**
 * Contains a method for Insertion, Merge, and Quick sorting.
 *
 */
public class Sorts<T extends Comparable<? super T>> {

    private static final int MIDPOINT_DIVIDER = 2;

    /**
     *  iterates through and adds one iteration at a time,
     *  to sort. At each iteration removes one element from the input data,
     *  finds the location it belongs within the collected list
     *  places it where it is less than right element but greater than or equal left element
     *
     * @param list Arraylist of the items that we want to sort
     * @param start the start index of the section we want to sort
     * @param end the end index of the section we want to sort
     *
     * */
    public void InsertionSort(ArrayList<T> list, int start, int end) {

        // make sure that we actually need to perform the sorting algorithm
        if(list.size() > 1) {

            int traveller = 0;
            int positionHolder = start + 1;
            int lengthOfTravel = end - start;

            for (int i = 0; i < lengthOfTravel; i++) {

                //reset the traveler to be equal to where our positionHolder is
                traveller = positionHolder;

                // while the value in the traveller is less than the previous elements
                while (list.get(traveller).compareTo(list.get(traveller - 1)) < 0) {

                    T temp = list.get(traveller);
                    list.set(traveller, list.get(traveller - 1));
                    list.set((traveller - 1), temp);

                    traveller--;

                    if (traveller == start) {
                        break;
                    }
                }

                positionHolder++;

            }
        }
    }

    /**
     * Recursive function that sorts the list that is given
     *
     * @param list Arraylist of the items that we want to sort
     * @param start the start index of the section we want to sort
     * @param end the end index of the section we want to sort
     * */
    public void MergeSort(ArrayList<T> list, int start, int end) {
        // make sure we need to actually implement a sorting algorithm
        if(end - start > 0){
            int mid = start + (end - start)/MIDPOINT_DIVIDER;
            MergeSort(list, start, mid);
            MergeSort(list, mid +1, end);
            merge(list, start, end, mid);
        }

    }

    /**
     * helper method for MergeSort
     *
     * @param list the whole list from the method merge helps
     * @param start start index of the portion of the list to be merged
     * @param mid middle of the index of the portion that will be merged
     *
     * */
    public void merge(ArrayList<T> list, int start, int end, int mid){
        int leftIter = start;
        int rightIter = mid + 1;
        int mergeSize = end - start + 1;
        ArrayList<T> sortedList = new ArrayList<>();

        while(leftIter <= mid && rightIter <= end) {
            if (list.get(leftIter).compareTo(list.get(rightIter)) <= 0) {
                sortedList.add(list.get(leftIter));
                leftIter++;
            } else {
                sortedList.add(list.get(rightIter));
                rightIter++;
            }
        }
        while(leftIter <= mid){
            sortedList.add(list.get(leftIter));
            leftIter++;
        }
        while(rightIter <= end){
            sortedList.add(list.get(rightIter));
            rightIter++;
        }
        for(int i = 0; i < mergeSize; i++){
            list.set(i + start, sortedList.get(i));
        }
    }
    /**
     * Quickly sorts list through partitioning through the list
     *
     * @param list Arraylist of the not sorted elements
     * @param start beginning of the index that is going to be sorted
     * @param end end of the index of the part of the list that will be sorted
     *
     * */
    public void QuickSort(ArrayList<T> list, int start, int end) {

        int partitionResult = 0;

        // base case that stops when the start exceeds the end
        if(start < end){
            partitionResult = Partition(list, start, end);

            //partition the two elements
            QuickSort(list, start, partitionResult);
            QuickSort(list, partitionResult + 1, end);

        }
    }

    /**
     * Helper method for Quick Sort to split the arraylist
     *
     * @param list the list that we are partitioning
     * @param start the start index that we will partition
     * @param end the end index of the list that we will partition
     *
     * @return the index of the element that will be partitioned
     *
     * */
    public int Partition(ArrayList<T> list, int start, int end){
        int left = 0;
        int right = 0;
        int mid = 0;
        T pivot;
        T temp;
        // grabs the middle index between start and end
        mid = (start + end) / MIDPOINT_DIVIDER;
        pivot = list.get(mid);
        left = start;
        right = end;
        boolean isFinished = false;
        // run until left is greater or equal to right
        while(isFinished == false){
            // iterate until the object is greater than the left
            while(list.get(left).compareTo(pivot) < 0){
                left ++;
            }

            // iterate until the pivot is greater than the right element value
            while(pivot.compareTo(list.get(right)) < 0){
                right --;
            }
            //if the left is less than right switch them
            if(left >=right){
                isFinished = true;
            }
            else{

                temp = list.get(left);

                list.set(left, list.get(right));
                list.set(right, temp);

                left ++;
                right --;
            }
        }
        return right;
    }
}
