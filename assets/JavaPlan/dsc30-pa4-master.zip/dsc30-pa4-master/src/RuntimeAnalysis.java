
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Name: Madeline Tjoa
 * PID: A15394053
 */

/**
 * Checks the runtime analysis of:
 * insertion, merge, and quick sort,
 * binary search and linear search
 * */
public class RuntimeAnalysis {

    HashMap<Long, Integer> a = new HashMap<>();

    private static final int NUM_DATA = 100000;
    private static final int NUM_SEARCH = 50000;
    private static final int NUM_RUN = 10;
    private static final int NUM_TEST = 5;
    private static final int MIN = 0;
    private static final int MAX = 100000;

    /**
     * Returns an ArrayList of random numbers
     *
     * @param size the number of random numbers wanted
     * @param min the min value for random number
     * @param max the max value for random number
     * @return an ArrayList of random numbers
     */
    public static ArrayList<Integer> randomNumbers(int size, int min, int max) {

        ArrayList<Integer> randNums = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            randNums.add((int) (Math.random() * ((max - min) + 1)) + min);
        }
        return randNums;
    }

    /**
     * calculates the runtime of InsertionSort
     *
     * @param data the ArrayList of the list that we will need to sort
     * @param numRun the number of runs that we will test
     * */
    public static void timeInsertionSort(ArrayList<Integer> data, int numRun) {
        long startTime = 0, endTime = 0, totalTime = 0;
        Sorts<Integer> mySorters = new Sorts<Integer>();



        for(int i = 0; i < numRun; i++){
            ArrayList<Integer> copyData = deepCopy(data);
            startTime = System.currentTimeMillis();
            mySorters.InsertionSort(copyData, 0, data.size()-1);
            endTime = System.currentTimeMillis();
            totalTime += endTime - startTime;
        }

        System.out.println();
        System.out.println("Benchmarking insertion sort: ");
        System.out.println("Number of data to sort: " + data.size());
        System.out.println("Average time taken to sort: " + totalTime / numRun + " ms");
        System.out.println();
    }

    /**
     * calculates the runtime of MergeSort
     *
     * @param data the ArrayList of the list that we will need to sort
     * @param numRun the number of runs that we will test
     * */
    public static void timeMergeSort(ArrayList<Integer> data, int numRun) {
        long startTime = 0, endTime = 0, totalTime = 0;

        Sorts<Integer> mySorters = new Sorts<Integer>();


        for(int i = 0; i < numRun; i++){
            ArrayList<Integer> copyData = deepCopy(data);
            startTime = System.currentTimeMillis();
            mySorters.MergeSort(copyData, 0, data.size() - 1);
            endTime = System.currentTimeMillis();
            totalTime += endTime - startTime;
        }
        
        System.out.println();
        System.out.println("Benchmarking merge sort: ");
        System.out.println("Number of data to sort: " + data.size());
        System.out.println("Average time taken to sort: " + totalTime / numRun + " ms");
        System.out.println();
    }

    /**
     * calculates the runtime of QuickSort
     *
     * @param data the ArrayList of the list that we will need to sort
     * @param numRun the number of runs that we will test
     * */
    public static void timeQuickSort(ArrayList<Integer> data, int numRun) {
        long startTime = 0, endTime = 0, totalTime = 0;

        Sorts<Integer> mySorters = new Sorts<Integer>();

        for(int i = 0; i < numRun; i++){
            ArrayList<Integer> copyData = deepCopy(data);
            startTime = System.currentTimeMillis();
            mySorters.QuickSort(copyData, 0, data.size() - 1);
            endTime = System.currentTimeMillis();
            totalTime += endTime - startTime;
        }
        
        System.out.println();
        System.out.println("Benchmarking quick sort: ");
        System.out.println("Number of data to sort: " + data.size());
        System.out.println("Average time taken to sort: " + totalTime / numRun + " ms");
        System.out.println();
    }

    /**
     * calculates the runtime of BinarySearch
     *
     * @param sortedData a sorted ArrayList of the list that we will need to search through
     * @param toSearch the ArrayList of all the values that we are going to search for
     * @param numRun the number of runs that we will test
     * */
    public static void timeBinarySearch(ArrayList<Integer> sortedData, ArrayList<Integer> toSearch, int numRun) {
        long startTime = 0, endTime = 0, totalTime = 0;

        BinarySearch<Integer> mySorters = new BinarySearch<>();

        for(int j = 0; j< numRun; j++) {
            startTime = System.currentTimeMillis();
            for (int i = 0; i < toSearch.size(); i++) {
                mySorters.binarySearch(sortedData, 0, sortedData.size() - 1, toSearch.get(i));
            }
            endTime = System.currentTimeMillis();
            totalTime += endTime - startTime;
        }
        
        System.out.println();
        System.out.println("Benchmarking Binary Search on sorted array: ");
        System.out.println("Number of data in sorted array: " + sortedData.size());
        System.out.println("Number of data to search: " + toSearch.size());
        System.out.println("Average time taken to search: " + totalTime / numRun + " ms");
        System.out.println();
    }

    /**
     * calculates the runtime of BinarySearch
     *
     * @param sortedData a sorted ArrayList of the list that we will need to search through
     * @param toSearch the ArrayList of all the values that we are going to search for
     * @param numRun the number of runs that we will test
     * */
    public static void timeLinearSearch(ArrayList<Integer> sortedData, ArrayList<Integer> toSearch, int numRun) {
        long startTime = 0, endTime = 0, totalTime = 0;

        Sorts<Integer> mySorters = new Sorts<Integer>();

        for(int j = 0; j< numRun; j++){
            startTime = System.currentTimeMillis();
            for(int i = 0; i < toSearch.size(); i++){
                LinearSearch(sortedData, toSearch.get(i), 0, toSearch.get(i));
            }
            endTime = System.currentTimeMillis();
            totalTime += endTime - startTime;
        }

        System.out.println();
        System.out.println("Benchmarking Linear Search on sorted array: ");
        System.out.println("Number of data in sorted array: " + sortedData.size());
        System.out.println("Number of data to search: " + toSearch.size());
        System.out.println("Average time taken to search: " + totalTime / numRun + " ms");
        System.out.println();
    }

    /**
     * calculates the runtime of BinarySearch
     *
     * @param sortedList a sorted ArrayList of the list that we will need to search through
     * @param toSearch the ArrayList of all the values that we are going to search for
     * @param start the start index of the ArrayList we are going to sort
     * @param end the end index of the ArrayList that we are going to sort
     * */
    public static Integer LinearSearch(ArrayList<Integer> sortedList, Integer toSearch, int start, int end){

        for(int i = start; i< end; i++){
            if(sortedList.get(i).compareTo(toSearch) == 0){
                return i;
            }
        }
        return null;
    }

    /**
     * Main method that runs the methods implemented
     * */
    public static void main(String[] args) {
        ArrayList<Integer> toSearch = randomNumbers(NUM_SEARCH, MIN, MAX);
        int numData = NUM_DATA;
        for (int i = 0; i < NUM_TEST; i++) {
            ArrayList<Integer> data = randomNumbers(numData, MIN, MAX);
            Sorts<Integer> sorts = new Sorts<>();
            sorts.QuickSort(data, 0, data.size() - 1);
            timeBinarySearch(data, toSearch, NUM_RUN);
            numData += numData;
        }

        numData = NUM_DATA;
        for (int i = 0; i < NUM_TEST; i++) {
            ArrayList<Integer> data = randomNumbers(numData, MIN, MAX);
            Sorts<Integer> sorts = new Sorts<>();
            sorts.QuickSort(data, 0, data.size() - 1);
            timeLinearSearch(data, toSearch, 1);
            numData += numData;
        }

        numData = NUM_DATA;
        for (int i = 0; i < NUM_TEST; i++) {
            ArrayList<Integer> data = randomNumbers(numData, MIN, MAX);
            timeQuickSort(data, NUM_RUN);
            numData += numData;
        }

        numData = NUM_DATA;
        for (int i = 0; i < NUM_TEST; i++) {
            ArrayList<Integer> data = randomNumbers(numData, MIN, MAX);
            timeMergeSort(data, NUM_RUN);
            numData += numData;
        }

        numData = NUM_DATA;
        for (int i = 0; i < NUM_TEST; i++) {
            ArrayList<Integer> data = randomNumbers(numData, MIN, MAX);
            timeInsertionSort(data, 1);
            numData += numData;
        }
    }

    private static ArrayList<Integer> deepCopy(ArrayList<Integer> theData){
        ArrayList<Integer> newData = new ArrayList<Integer>();
        for(int i = 0; i< theData.size(); i++){
            newData.add(theData.get(i));
        }
        return newData;
    }


}
