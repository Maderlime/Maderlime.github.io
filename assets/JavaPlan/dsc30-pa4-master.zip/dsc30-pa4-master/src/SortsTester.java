import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.LinkedList;

import static org.junit.Assert.*;
/**
 * @author Madeline Tjoa
 * @PID A15394053
 *
 *
 * Test the sorting algorithms QuickSort, MergeSort, and InsertionSort
 * */
public class SortsTester {

    Sorts<Integer> al;

    ArrayList<Integer> linkedListarray;

    ArrayList<Integer> sortedArray;
    ArrayList<Integer> reverselySortedArray;
    ArrayList<Integer> mostlySortedArray;
    ArrayList<Integer> completelyRandomArray;

    ArrayList<Integer> checkArraySorted;
    ArrayList<Integer> checkArrayRSorted;
    ArrayList<Integer> checkArrayMSorted;
    ArrayList<Integer> checkArrayRandom;

    @Before
    public void setUp() throws Exception {
        // Sorted array
        // Reversely sorted array
        // Mostly sorted array
        // Completely random array
        al = new Sorts<Integer>();

        linkedListarray = new ArrayList<Integer>();
        linkedListarray.add(2);
        linkedListarray.add(4);
        linkedListarray.add(5);
        linkedListarray.add(3);
        linkedListarray.add(6);
        linkedListarray.add(1);
        linkedListarray.add(2);

        // 1 2 2 3 4 5 6

        //sorted array
        sortedArray = new ArrayList<Integer>();
        for(int i = 0; i < 15; i++){
            sortedArray.add(i);
        }

        //reversely sorted array
        reverselySortedArray = new ArrayList<Integer>();
        for(int i = 12; i > 0; i--){
            reverselySortedArray.add(i);
        }
        // 0 1 2 3 4 5 6 7 8 9 ... 12

        mostlySortedArray = new ArrayList<Integer>();
        mostlySortedArray.add(1);
        mostlySortedArray.add(2);
        mostlySortedArray.add(3);
        mostlySortedArray.add(4);
        mostlySortedArray.add(5);
        mostlySortedArray.add(6);
        mostlySortedArray.add(7);
        mostlySortedArray.add(9);
        mostlySortedArray.add(18);
        mostlySortedArray.add(0);
        mostlySortedArray.add(1);
        mostlySortedArray.add(2);
        mostlySortedArray.add(3);
        mostlySortedArray.add(4);
        mostlySortedArray.add(5);
        mostlySortedArray.add(19);
        // 1 2 3 4 5 6 7 8 9 18 0 1 2 3 4 5 19
        // 0 1 1 2 2 3 3 4 4 5 5 6 7 8 9 18 19

        completelyRandomArray = new ArrayList<Integer>();
        completelyRandomArray.add(6);
        completelyRandomArray.add(3);
        completelyRandomArray.add(45);
        completelyRandomArray.add(2);
        completelyRandomArray.add(9);
        completelyRandomArray.add(18);
        completelyRandomArray.add(9);
        completelyRandomArray.add(18);
        completelyRandomArray.add(90);
        completelyRandomArray.add(4);
        // 6 3 45 2 9 18 9 18 90 4

        // 2 3 4 6 9 9 18 18 45 90

        checkArraySorted  = new ArrayList<Integer>();
        // 1 2 2 3 4 5 6
        checkArraySorted.add(1);
        checkArraySorted.add(2);
        checkArraySorted.add(2);
        checkArraySorted.add(3);
        checkArraySorted.add(4);
        checkArraySorted.add(5);
        checkArraySorted.add(6);

        checkArrayRSorted = new ArrayList<Integer>();
        // 0 1 2 3 4 5 6 7 8 9 ... 12
        for(int i = 1; i<13; i++){
            checkArrayRSorted.add(i);
        }
        checkArrayMSorted = new ArrayList<Integer>();
        // 0 1 1 2 2 3 3 4 4 5 5 6 7 8 9 18 19
            checkArrayMSorted.add(0);
            checkArrayMSorted.add(1);
            checkArrayMSorted.add(1);
            checkArrayMSorted.add(2);
            checkArrayMSorted.add(2);
            checkArrayMSorted.add(3);
            checkArrayMSorted.add(3);
            checkArrayMSorted.add(4);
            checkArrayMSorted.add(4);
            checkArrayMSorted.add(5);
            checkArrayMSorted.add(5);
            checkArrayMSorted.add(6);
            checkArrayMSorted.add(7);
            checkArrayMSorted.add(8);
            checkArrayMSorted.add(9);
            checkArrayMSorted.add(18);
            checkArrayMSorted.add(19);


        checkArrayRandom = new ArrayList<Integer>();
        // 2 3 4 6 9 9 18 18 45 90
            checkArrayRandom.add(2);
            checkArrayRandom.add(3);
            checkArrayRandom.add(4);
            checkArrayRandom.add(6);
            checkArrayRandom.add(9);
            checkArrayRandom.add(9);
            checkArrayRandom.add(18);
            checkArrayRandom.add(18);
            checkArrayRandom.add(45);
            checkArrayRandom.add(90);

    }

    @Test
    public void insertionSort() {
        for(int i = 0; i < linkedListarray.size(); i ++){
            System.out.println(linkedListarray.get(i));
        }
        al.InsertionSort(linkedListarray, 0,linkedListarray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < linkedListarray.size(); i ++){
            System.out.println(linkedListarray.get(i));
        }
        assertEquals(checkArraySorted, linkedListarray);
    }

    @Test
    public void insertionSort2() {
        for(int i = 0; i < sortedArray.size(); i ++){
            System.out.println(sortedArray.get(i));
        }
        al.InsertionSort(sortedArray, 0,sortedArray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < sortedArray.size(); i ++){
            System.out.println(sortedArray.get(i));
        }
        assertEquals(sortedArray, sortedArray);
    }
    @Test
    public void insertionSort3() {
        for(int i = 0; i < reverselySortedArray.size(); i ++){
            System.out.println(reverselySortedArray.get(i));
        }
        al.InsertionSort(reverselySortedArray, 0,reverselySortedArray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < reverselySortedArray.size(); i ++){
            System.out.println(reverselySortedArray.get(i));
        }
        assertEquals(checkArrayRSorted, reverselySortedArray);
    }

    @Test
    public void insertionSort4() {
        for(int i = 0; i < completelyRandomArray.size(); i ++){
            System.out.println(completelyRandomArray.get(i));
        }
        al.InsertionSort(completelyRandomArray, 0,completelyRandomArray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < completelyRandomArray.size(); i ++){
            System.out.println(completelyRandomArray.get(i));
        }
        assertEquals(checkArrayRandom, completelyRandomArray);
    }

    @Test
    public void mergeSort() {
        for(int i = 0; i < linkedListarray.size(); i ++){
            System.out.println(linkedListarray.get(i));
        }
        al.MergeSort(linkedListarray, 0,linkedListarray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < linkedListarray.size(); i ++){
            System.out.println(linkedListarray.get(i));
        }
        assertEquals(checkArraySorted, linkedListarray);
    }

    @Test
    public void mergeSort2() {
        for(int i = 0; i < sortedArray.size(); i ++){
            System.out.println(sortedArray.get(i));
        }
        al.MergeSort(sortedArray, 0,sortedArray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < sortedArray.size(); i ++){
            System.out.println(sortedArray.get(i));
        }
        assertEquals(sortedArray, sortedArray);
    }

    @Test
    public void mergeSort3() {
        for(int i = 0; i < reverselySortedArray.size(); i ++){
            System.out.println(reverselySortedArray.get(i));
        }
        al.MergeSort(reverselySortedArray, 0,reverselySortedArray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < reverselySortedArray.size(); i ++){
            System.out.println(reverselySortedArray.get(i));
        }
        assertEquals(checkArrayRSorted, reverselySortedArray);
    }
    @Test
    public void mergeSort4() {
        for(int i = 0; i < completelyRandomArray.size(); i ++){
            System.out.println(completelyRandomArray.get(i));
        }
        al.MergeSort(completelyRandomArray, 0,completelyRandomArray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < completelyRandomArray.size(); i ++){
            System.out.println(completelyRandomArray.get(i));
        }
        assertEquals(checkArrayRandom, completelyRandomArray);
    }
    @Test
    public void quickSort() {
        System.out.println("First produced Array: ");

        for(int i = 0; i < linkedListarray.size(); i ++){
            System.out.print(linkedListarray.get(i) + " ");
        }

        System.out.println(" ");
        al.QuickSort(linkedListarray, 0,linkedListarray.size()-1);
        System.out.println(" ");
        System.out.println("Final Array: ");
        for(int i = 0; i < linkedListarray.size(); i ++){
            System.out.print(linkedListarray.get(i) + " ");
        }
        assertEquals(checkArraySorted, linkedListarray);
    }

    @Test
    public void quickSort2() {
        System.out.println("First produced Array: ");

        for(int i = 0; i < sortedArray.size(); i ++){
            System.out.print(sortedArray.get(i) + " ");
        }

        System.out.println(" ");
        al.QuickSort(sortedArray, 0,sortedArray.size() - 1);
        System.out.println(" ");
        System.out.println("Final Array: ");
        for(int i = 0; i < sortedArray.size(); i ++){
            System.out.print(sortedArray.get(i) + " ");
        }
        assertEquals(sortedArray, sortedArray);
    }

    @Test
    public void quickSort3() {
        System.out.println("First produced Array: ");

        for(int i = 0; i < reverselySortedArray.size(); i ++){
            System.out.print(reverselySortedArray.get(i) + " ");
        }

        System.out.println(" ");
        al.QuickSort(reverselySortedArray, 0,reverselySortedArray.size() - 1);
        System.out.println(" ");
        System.out.println("Final Array: ");
        for(int i = 0; i < reverselySortedArray.size(); i ++){
            System.out.print(reverselySortedArray.get(i) + " ");
        }
        assertEquals(checkArrayRSorted, reverselySortedArray);
    }

    @Test
    public void quickSort4() {
        for(int i = 0; i < completelyRandomArray.size(); i ++){
            System.out.println(completelyRandomArray.get(i));
        }
        al.QuickSort(completelyRandomArray, 0,completelyRandomArray.size()-1);
        System.out.println(" ");
        for(int i = 0; i < completelyRandomArray.size(); i ++){
            System.out.println(completelyRandomArray.get(i));
        }
        assertEquals(checkArrayRandom, completelyRandomArray);
    }
}