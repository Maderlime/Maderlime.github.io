/**
 * Name: Madeline Tjoa
 * PID: A15394053
 *
 * */
import java.util.ArrayList;

/**
 * Binary Search class that finds the index of am element in a sorted list
 *
 * */
public class BinarySearch<T extends Comparable<? super T>> {

    private static int MIDPOINT_DIVISOR = 2;
    public Integer binarySearch(ArrayList<T> sortedList, int start, int end, T toSearch) {
        // for loop
        if(start < 0 || end < 0 || toSearch == null || sortedList == null){
            return null;
        }
        if(end-start >= 1){
            int middle;
            int bottom = start;
            int top = end;

            while(bottom <= top){
                middle = bottom + (top - bottom) / MIDPOINT_DIVISOR;
                // if the middle is equal to the toSearch value
                if(sortedList.get(middle).compareTo(toSearch) == 0){
                    return middle;
                }
                else{

                    // if the middle index is less than what we want to find
                    if(sortedList.get(middle).compareTo(toSearch) < 0){
                        // made the middle index smaller
                        bottom = middle + 1;
                    }
                    else{
                        // made the middle index bigger
                       top = middle - 1;
                    }
                }
            }
        }
        return null;
    }
}
