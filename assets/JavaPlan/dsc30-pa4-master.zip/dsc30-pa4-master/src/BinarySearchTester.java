import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

import java.lang.reflect.Array;
import java.util.*;

/**
 * Name: Madeline Tjoa
 * PID: A15394053
 *
 * Tests Binary Search
 * */
public class BinarySearchTester {
    BinarySearch<Integer> al;

    ArrayList<Integer> linkedListarray;
    ArrayList<Integer> oddNumberArray;
    ArrayList<Integer> noElementArray;

    @org.junit.Before
    public void setUp() throws Exception {
        linkedListarray = new ArrayList<Integer>();
        al = new BinarySearch<>();
        for(int i = 0; i< 16; i++){
            linkedListarray.add(i);
        }
        oddNumberArray = new ArrayList<Integer>();
        for(int i = 0; i< 15; i++){
            oddNumberArray.add(i);
        }
        noElementArray = new ArrayList<Integer>();
        for(int i = 0; i< 15; i++){
            noElementArray.add(i);
        }

    }

    @org.junit.Test
    public void binarySearch( ) {
        //test for Even size sorted array
       Integer result = al.binarySearch(linkedListarray, 0,
               linkedListarray.size() - 1, 4);
       assertEquals(new Integer(4), result);
    }

    @org.junit.Test
    public void binarySearch1() {
        //Odd size sorted array
        Integer result = al.binarySearch(oddNumberArray, 0,
                oddNumberArray.size() - 1, 4);
        assertEquals(new Integer(4), result);

    }
    @org.junit.Test
    public void binarySearch2() {
        //Searching element not in the sorted array should return null
        Integer result = al.binarySearch(noElementArray, 0,
                noElementArray.size() - 1, 17);
        assertEquals(null, result);
    }
}