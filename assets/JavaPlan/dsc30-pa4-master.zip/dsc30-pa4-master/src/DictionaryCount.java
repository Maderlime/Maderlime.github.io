import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

/**
 * Name: Madeline Tjoa
 * PID: A15394053
 */

/**
 * Dictionary Count class used to read file and calculate most occurences of items
 *
 * */
public class DictionaryCount {
    private static final int TOP_PAIRS = 3;

    /**
     * This method would read all the words from the given file and store them into
     * an ArrayList of Pairs, where each of the pair contains a word and count as 0.
     *
     * @param fileName the given file to be read
     * @return an ArrayList containing pairs storing all the words from the given file
     */
    private static ArrayList<Pair> readDict(String fileName){

        try {
            ArrayList<Pair> pairs = new ArrayList<>();
            Scanner sc = new Scanner(new File(fileName));

            // read numWords or readAll from the given file
            while(sc.hasNext()){
                pairs.add(new Pair(sc.next()));
            }
            sc.close();
            return pairs;
        }
        catch (IOException e) {
            System.out.println("File not found!");
            return null;
        }
    }

    /**
     * This method would read all the words from the given file and store them into
     * an ArrayList of Strings.
     *
     * @param fileName the given file to be read
     * @return an ArrayList containing all the words from the given file
     */
    private static ArrayList<String> readWords(String fileName){

        try {
            ArrayList<String> words = new ArrayList<>();
            Scanner sc = new Scanner(new File(fileName));

            // read numWords or readAll from the given file
            while(sc.hasNext()){
                words.add(sc.next());
            }
            sc.close();
            return words;
        }
        catch (IOException e) {
            System.out.println("File not found!");
            return null;
        }
    }

    /**
     * populates the dictionary from the given ArrayList of Pairs
     *
     * @param pairs the ArrayList that is going to be copied
     * @return a separate ArrayList of the same integers that were passed in
     * */
    public static ArrayList<Pair> populateDict(ArrayList<Pair> pairs) {

        //sort so you can do a binary search quickly
        Sorts<Pair> dictionary = new Sorts<Pair>();
        dictionary.QuickSort(pairs, 0, pairs.size() - 1);
        return pairs;

    }

    /**
     * Searches the given string in the dict and if the string
     * is found in the dict, increment the count of the
     * corresponding pair. Returns true if the string is
     * found and false otherwise.
     *
     * @param dict dictionary of Words that will be iterated through
     * @param toSearch the string that we will try to find in the dictionary
     * @return boolean value of whether the value is found
     * */
    public static boolean searchDict(ArrayList<Pair> dict, String toSearch) {

        BinarySearch<Pair> binaryAlg = new BinarySearch<Pair>();

        Pair mySearch = new Pair(toSearch);

        Integer searchResult = binaryAlg.binarySearch(dict, 0, dict.size() - 1, mySearch);
        if(searchResult != null){
            dict.get(searchResult).incCount();

            return true;
        }

        return false;

    }

    /**
     * Main method that goes through the dictionary and prints out the top three most found names
     * */
    public static void main(String[] args) {

        String starksTextFile = args[0];
        String gotTextFile = args[1];

        //read the dictionary
        ArrayList<Pair> readStarks = readDict(starksTextFile);

        //after reading it, sort it.
        ArrayList<Pair> sortedStarks = populateDict(readStarks);

        //read the got book words and store in an ArrayList
        ArrayList<String> readGOT = readWords(gotTextFile);

        //pair the found last names and book words, count their occurrences
        //for(int i = 0; i< readGOT.size(); i++){
        for (String word : readGOT) {
            searchDict(sortedStarks, word);
        }

        //sort this dictionary {last name and word count} by word count.
        Collections.sort(sortedStarks, new CountComp());

        //print out the top 3 strings in the dictionary that appears most frequently
        for(int i = 0; i< TOP_PAIRS; i++){
            System.out.println("Count: " + sortedStarks.get(i).getCount() + "Who: " + sortedStarks.get(i).getWord());
        }
    }
}
