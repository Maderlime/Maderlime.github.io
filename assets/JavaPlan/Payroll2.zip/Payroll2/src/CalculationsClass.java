
public class CalculationsClass {

	//class variables
			private double dblrate, dblhours,dblpay;
	//static means hold its value over time.
			private int numberProcessedint = 0;
	
	//create our class constructor
	//The class calls this method first
	//The constructor has the same name as the class
		CalculationsClass(double theRate, double theHours){
			
			//theRate and theHours are the parameters for the method
				dblrate = theRate;
				dblhours = theHours;
				
		}

	//create our calculate pay method
		private void CalculatePay() {
			
			dblpay = dblrate * dblhours;
			numberProcessedint ++;			
		}
	
		
	//return answer from calculate pay
		public double getPay() {
			
			CalculatePay();
			return dblpay;	
		}
		
	//return back answers that is public	
		public int getEmployeeCount() {
			
			return numberProcessedint;			
		}
}
