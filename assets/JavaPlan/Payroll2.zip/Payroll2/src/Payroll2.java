
import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

public class Payroll2 extends JApplet implements ActionListener{

	//declare our components or fields(global level variable)
		JTextField txtHours = new JTextField(20);
		JTextField txtRate = new JTextField(20);
		JTextField txtName = new JTextField(5);
	
		JTextArea txaPayroll = new JTextArea(
				"Name   Rate    Pay" + "\n", 10,30);
	
		JButton btnAdd = new JButton("Calculate");
	
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		double totalPay;
	
	//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			resize(500,300);
			txtName.requestFocus();
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
			txtName.addActionListener(this);
			txtHours.addActionListener(this);
			txtRate.addActionListener(this);
			
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			String nameString;
			String outputString;
			
			double rateDouble;
			double hoursDouble;
			double payDouble;
			
			
			
		//2. information	
			nameString = txtName.getText();
			
			
			hoursDouble = Double.parseDouble(txtHours.getText());
			rateDouble = Double.parseDouble(txtRate.getText());
			
			
		//3. Calculate 
			//we are going to connect the classes
			CalculationsClass ThePayClass = new CalculationsClass(rateDouble,hoursDouble);
			payDouble = ThePayClass.getPay();
			
		//extra: connect to a format class	
			String formattedDataString;
			NumberFormat fmtCurrency = NumberFormat.getCurrencyInstance();
			
			formattedDataString = fmtCurrency.format(payDouble);
					
			
		//4. output in the text Area
			txaPayroll.append(nameString + " Earns \n" + formattedDataString);
			txtName.setText("");
			txtRate.setText("");
			txtHours.setText("");
			txtName.requestFocus();
			
		}
		
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			
			pnlInput.add(new JLabel("Name: "));
				pnlInput.add(txtName);
			pnlInput.add(new JLabel("Hours Worked: "));
				pnlInput.add(txtHours);
			pnlInput.add(new JLabel("Rate of Pay: "));
				pnlInput.add(txtRate);	
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaPayroll);
			
		}
		
	
	
}
