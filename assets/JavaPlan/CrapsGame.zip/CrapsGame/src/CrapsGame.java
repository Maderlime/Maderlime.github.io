
import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

import java.io.*;
import java.text.*;

import java.util.Random;


public class CrapsGame extends JApplet implements ActionListener{

	
	
		JTextArea txaresult = new JTextArea(
				"ROLL RESULTS" + "\n", 20,30);
	
		JButton btnAdd = new JButton("Roll Dice");
	
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		
		double diceSum = 0;
		double timesrolled;
		
		Random rand = new Random();
		
		double  dice1;
		double  dice2;	 
		
		String ooutput = "Winner!";
		double theStringerTarger;
		String tiger;
		
		
	
	//Create the init method(initialize method)
		public void init() {
			
			
		
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			resize(350,550);

			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
			
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			
			
			
			
			
		//2. information	
			
			
			
			
			
			
			
			
//3. Calculate 
			
			double  potato1 = rand.nextInt(6) + 1;
			double  potato2 = rand.nextInt(6) + 1;
			
			dice1 = potato1;
			dice2 = potato2;
			
			CrapsCalculations ThePayClass = new CrapsCalculations(dice1, dice2);		
			
			
			double FdiceSum = ThePayClass.diceSum();
			double FtimesRolled = ThePayClass.LeRolls();
			
			double WinnerLoser = ThePayClass.PlayString();
			double Target = ThePayClass.targetScoree();

			if(WinnerLoser == 1) {			
				ooutput = "Ya Win";
				theStringerTarger = 0;
			}
			if(WinnerLoser == 2) {
				ooutput = "Ya Losed";
				theStringerTarger = 0;
			}
			if(WinnerLoser ==3) {
				ooutput = "No Win, No Lose";
				 tiger = Double.toString(Target);
			}
			
			else if(theStringerTarger == 0) {
				tiger = "No Number Kappa cuz \n "
						+ "\t we startin over \n "
						+ "\t or you got a Winning or Lost.";
			}
			
		//extra: connect to a format class	
			
			//CrapsFormat Problems = new CrapsFormat(FProb2, FProb3, FProb4, FProb5, FProb6, FProb7, FProb8, FProb9, FProb10, FProb11, FProb12);
			

			
		//4. output in the text Area
			txaresult.setText("Numbers Rolled : \n " + dice1 + "," +  dice2 + 
							
								" \n \n \t Sum of these Rolls: " + FdiceSum + 
								"\n  Target Number: " + tiger +
								
								
								"\n \t \n \n: " + 
								"\n \t Your Status: "  + ooutput +
								
								" \n Number of Total Rolls: " + FtimesRolled +
			
								"\n"	
								);
			
			
		
		}
		
		//Total Charge
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));	
				
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);		
		}
		
	
	
}

