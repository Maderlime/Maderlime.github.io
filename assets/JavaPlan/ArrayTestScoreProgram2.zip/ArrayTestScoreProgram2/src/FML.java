
import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

import java.io.*;
import java.text.*;


public class FML extends JApplet implements ActionListener{

						//declare our components or fields(global level variable)
							//create text boxes
							JTextField txtSubject = new JTextField(20);
							JTextField txtScore1 = new JTextField(20);
					
							//create text areas
							JTextArea txaresult = new JTextArea(
									"Score" + "\n", 10,33);
							JTextArea txaHarpoon = new JTextArea(" ");
							
							//create text buttons
							JButton btnAdd = new JButton("Add Test");
							JButton btnAmount = new JButton("This Amount!");
							
							//create panels
							JPanel pnlMain = new JPanel();
							JPanel pnlInput = new JPanel();
							JPanel pnlOutput = new JPanel();
						
							//doubles and integers
							double AverageGrade;
							double HighestGrade;
							double averageSpent;
							
							//counts the amount of arrays inputted into the area
							int blegh=0;
							
							//Displays the letter grade for the tests
							String soloGrade;
							String everyGrade;
							
							//also displays the letter grade for the single test, basically does the same thing
							String Killitwithfire;
							
							//holder for the maximum and minimum scores
							int max= 0;
							int min = 100;
							
		//Declare Array
		DefineGrades Grades[];
	
		//Create array lists 
		ArrayList<Integer> myList = new ArrayList<Integer>();
		ArrayList<String> myString = new ArrayList<String>();
		ArrayList<String> myLetterString = new ArrayList<String>();
		
		
		//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			//put the panels and buttons and stuff on the applet
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(btnAmount);
			pnlMain.add(pnlOutput);
			
			//resize the applet
			resize(500,400);
			txtSubject.requestFocus();
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			
			//Create actionlisteners for the functions in the applet
			btnAdd.addActionListener(this);
			btnAmount.addActionListener(this);
			txtScore1.addActionListener(this);
			
			//disable some of the functions for later
			btnAdd.setEnabled(false);
			txtScore1.setEnabled(false);
			
		}		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
			//creating the variables
			double Score1Double;/*Holder for the Score the perons inputs, in double form*/
			int Score1Int;/*Holder for the Score the person inputs, in integer form*/
			double Arraytimes; /*holder for the number of test scores the person wants to input, in double form*/
			int whydontyouwork;/*Holder for the number of test score the person wants to input, in integer form*/
			
			//basically an actionlistener that looks for specific actions being done(like o the action listener was triggered lemme see what the specific action that was called is) 
			Object objSource = event.getSource();
			 //if the object source of the trigger is the button amount:
			 if(objSource == btnAmount) {
				 //Make the amount of slots for the Grades array equal to whatever number the user inputted
				 Grades = new DefineGrades[Integer.parseInt(txtSubject.getText())];
				 
				 //enable the ScoreInput button and the Adding button and disable the array button stuff
				 btnAmount.setEnabled(false);
				 btnAdd.setEnabled(true);
				 txtScore1.setEnabled(true);
				 txtSubject.setEnabled(false);
				}
		//1. get variables	
				Score1Double = Double.parseDouble(txtScore1.getText());
				Score1Int = Integer.parseInt(txtScore1.getText());
				myList.add((int) Score1Int);
				Arraytimes = Integer.parseInt(txtSubject.getText());
				whydontyouwork = (int)Arraytimes;
		//2. information	
		try {
			if(objSource == btnAdd) {		
	//Array 
			for (int i = 0; i <1; i++) {
				Grades[i] = new DefineGrades();
			}	
			for (int j = 0; j<3;j++) {
				int xpos, ypos, xspeed,yspeed,life;	
			}
			
			

			//go to the calculations class to make calculations
			FMLCalculations ThePayClass = new FMLCalculations(Score1Double);
			//retreive calculations from the calculations class
			double averageTestScore = ThePayClass.averageScore();
			double totalTestsTaken = ThePayClass.TestsTaken();
			double highestTestScore = ThePayClass.HighestScore();
			double lowestTestScore = ThePayClass.LowestScore();
			double singleGrade = ThePayClass.ElLetterGrade();
			double teamGrade = ThePayClass.CollectiveLetterGrade();
			String iwanttodie = ThePayClass.cries();
			
			//go to the format class to change formats
			FMLFormat theFormatClass = new FMLFormat(averageTestScore, totalTestsTaken, highestTestScore);
			//retreive the formatted variables and put them in new variables
			double AaverageTestScore = theFormatClass.returnAverageScore();
			double AtotalTestsTaken = theFormatClass.returnTestsTaken();
			double AhighestTestScore = theFormatClass.returnHighestScore();
			
			
			
			//Collective Grade
			if(teamGrade ==1) {
				everyGrade = "F";
			}
			else if(teamGrade ==2) {
				everyGrade = "D";
			}
			else if(teamGrade ==3) {
				everyGrade = "C";
			}
			else if(teamGrade ==4) {
				everyGrade = "B";
			}
			else if(teamGrade ==5) {
				everyGrade = "A";
			}
			//add the stuff into a string
			myString.add(soloGrade);
			
			//puts the calculated stuff into the arrays
			for(int i=0; i<1; i++) { 
				Killitwithfire = soloGrade;
				Grades[i].setGrades(Score1Int,iwanttodie);
			} 
					
			
			
			
			
		//4. output in the text Area
			txaresult.setText(
									" \n \t Tests Taken: " + AtotalTestsTaken +
									" \n \t average Test Score: " + AaverageTestScore +
									" \n \t highest Test Score: " + AhighestTestScore +
									" \n \t Your Letter Grade for this Test: " + soloGrade +
									" \n \t Your Total Letter Grade" + iwanttodie
									+"\n "
									+ "Max Score " + AhighestTestScore + "\n" 
									+ "minimum Score:" + lowestTestScore
									+ "\n" + "\n"
									+  "Scores List: " 
									);
			
			
			for (int i = 0; i < 1; i++) {
				txaHarpoon.setText("Grade:" + Grades[i].IletterGrade + " | the number:" + Grades[i].IGradeScore + "\n" + txaHarpoon.getText());
			}
			
			for (int i = 0; i < myList.size(); i++) {
				txaresult.append(myList.get(i) + ", ");
			}
			
			/*StringBuilder sb=new StringBuilder();
				for(int j=0;j< strArray.length;j++)
					{
					   sb.append(strArray[j]);
					}
					jtext.setText(sb.toString());*/
			
			//txtSubject.setText("");
			txtScore1.setText("");
			txtSubject.setEnabled(false);
			txtScore1.requestFocus();
			 blegh ++;
			 if (blegh >= whydontyouwork) {
				 txtScore1.setEnabled(false);
			 }
			 
			}
		}
		catch(NumberFormatException err){			
			showStatus("please make sure you've entered everything!");
		}
			//bracket for the if(btnAdd thing
					
		}				
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			pnlInput.add(new JLabel("Amount of Tests: "));
				pnlInput.add(txtSubject);
			pnlInput.add(new JLabel("Score 1: "));
				pnlInput.add(txtScore1);
				
		}		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);
			pnlOutput.add(txaHarpoon);
		}
	
}

