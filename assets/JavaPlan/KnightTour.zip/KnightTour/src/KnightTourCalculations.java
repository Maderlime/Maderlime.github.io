import java.util.Arrays;
import java.util.Random;

public class KnightTourCalculations {

	int boardArray[][];
	
	int Row,Column;
	
	Random rn = new Random();
	
	int Randomizer;
	
	
	
	String lineSeparator = System.lineSeparator();
	StringBuilder sb = new StringBuilder();
	
	KnightTourCalculations(int IRow, int IColumn){
		
		Row = IRow -1;
		Column = IColumn -1;
		
		boardArray = new int[8][8];
		boardArray[Row][Column] = 1;

		
		
		Calculations();
		
	}
	
		private void Calculations(){
			
			int currentRow = Row;
			int currentColumn = Column;
			int secondCounter = 1;
			int infinity = 1;
			
			for(int i=0; i < infinity; i++) {
			
				int temporaryRow = currentRow;
				int temporaryColumn = currentColumn;
				int Randomizer;
				Randomizer = rn.nextInt(7);
				//RandomOutput(Randomizer);
//				System.out.println(temporaryRow + " : " + temporaryColumn);
				int Randommakesure = -1;
				for(int j= 0; j < 1000; j++) {
									
						if(Randomizer == 0) {
							temporaryColumn -= 2;
							temporaryRow ++;
						}
						else if(Randomizer ==1) {
							temporaryColumn --;
							temporaryRow +=2;
						}
						else if(Randomizer == 2) {
							temporaryColumn ++;
							temporaryRow +=2;
						}
						else if(Randomizer ==3) {
							temporaryColumn +=2;
							temporaryRow ++;
						}
						else if(Randomizer ==4) {
							temporaryColumn +=2;
							temporaryRow --;
						}
						else if(Randomizer ==5) {
							temporaryColumn ++;
							temporaryRow -=2;
						}
						else if(Randomizer ==6) {
							temporaryColumn --;
							temporaryRow -=2;
						}
						else  {
							temporaryColumn -=2;
							temporaryRow --;
						}
						
						
						
							if(temporaryColumn >= 0 && temporaryRow >= 0 && temporaryColumn <= 7 && temporaryRow <= 7 && boardArray[temporaryRow][temporaryColumn] == 0)  {
								secondCounter ++;
								boardArray[temporaryRow][temporaryColumn] = secondCounter;
								currentRow = temporaryRow;
								currentColumn = temporaryColumn;	
								Randomizer = rn.nextInt(7);
								break;
							}
							
							if(temporaryColumn < 0 ||temporaryRow < 0 ||temporaryColumn > 7 ||temporaryRow > 7|| boardArray[temporaryRow][temporaryColumn] > 0) {
								temporaryRow = currentRow;
								temporaryColumn = currentColumn;
								Randomizer = rn.nextInt(7);
								Randommakesure ++;
								Randomizer = Randommakesure;
							}
							
						
				}//end of inner for loop
			
				if(infinity > 1000) {
					break;
				}
				System.out.println(secondCounter);
				infinity++;
				
				
	
			}//End of for loop
			
			
	
			for (int[] row : boardArray) {
			    sb.append(Arrays.toString(row))
			      .append(lineSeparator);
			}
			
			
		}
	
		
		
		public StringBuilder ReturnedArrayList() {
			return sb;
			
		}
	
	
	
	
	
	
}
