import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class KnightTour extends JApplet implements ActionListener {

	JTextArea txaresult = new JTextArea("\n", 30,30);
	JTextField txtColLetter = new JTextField(20);
	JTextField txtRowNumber = new JTextField(20);
	JButton btnSet = new JButton("Place my Knight");
	JPanel pnlMain = new JPanel();
	JPanel pnlInput = new JPanel();
	JPanel pnlOutput = new JPanel();
	
	
	//variables
	int[][] placementArray = new int[8][8];
	
	int ColumnLocation, RowLocation;
	String ColumnLetter;
	
	
	public void init() { 
		
		DesignInputPanel();
		DesignOutputPanel();

		pnlMain.add(pnlInput);	
		pnlMain.add(btnSet);
		pnlMain.add(pnlOutput);	
		txtColLetter.requestFocus();
		resize(500,400);
	
		setContentPane(pnlMain);
		txtColLetter.addActionListener(this);
		txtRowNumber.addActionListener(this);
		btnSet.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		
			try {
					Object objSource = e.getSource();		/*Find the source of the action trigger*/
					
					if(objSource == btnSet) {
						
						
						
						ColumnLetter = txtColLetter.getText();
						ColumnLocation = Integer.parseInt(ColumnLetter);
						RowLocation = Integer.parseInt(txtRowNumber.getText());
						
						StringBuilder sb = new StringBuilder();
						
						KnightTourCalculations TheKnightClass = new KnightTourCalculations(RowLocation, ColumnLocation);
						sb = TheKnightClass.ReturnedArrayList();
						
						txaresult.setText("hello freend: \n" + sb);
						
					}	
						
					
					
			}
			catch(NumberFormatException err){			
				showStatus("please make sure you've entered everything!");
			}
		
	}
	
	public void DesignInputPanel() {
		pnlInput.setLayout(new GridLayout(0,2));
	
		pnlInput.add(new JLabel("Column Letter: "));
		pnlInput.add(txtColLetter);
		pnlInput.add(new JLabel("Row Number : "));
		pnlInput.add(txtRowNumber);

		}		
		public void DesignOutputPanel() {
		pnlOutput.setLayout(new GridLayout(0,1));

		pnlOutput.add(txaresult);
		}
	
}
