import java.util.ArrayList;
import java.util.Arrays;

public class FruitBinaryCalculations {

	String TargetItem;
	Object[] TheArray;
	
	ArrayList<String> friends = new ArrayList<String>();
	
	Boolean found;
	FruitBinaryCalculations(ArrayList FruitAndVeggieArray, String Target){
		
		//TheArray = FruitAndVeggieArray;
		TargetItem = Target;
		TargetItem = TargetItem.toLowerCase();
		
		friends = FruitAndVeggieArray;
		Calculations();
		
	}
	
	private void Calculations(){
		
		int centipede = friends.size();
		TheArray = new String[centipede];
		TheArray = friends.toArray();
		int topDog = centipede;
		int underDog = 0;

		found = false;
					
			int KyloRen = (topDog + underDog)/2;
		
			for(int i = 0; i < centipede; i++) {
				
				KyloRen = (topDog + underDog)/2;
				
				if(TheArray[KyloRen].equals(TargetItem)|| ((String) TheArray[KyloRen]).compareTo(TargetItem)==0) {
					
					found = true;
					break;
					
				}
				else if(((String) TheArray[KyloRen]).compareTo(TargetItem)>=1) {
					
					topDog = KyloRen;
					
				}
				else if(((String) TheArray[KyloRen]).compareTo(TargetItem)<0) {
					
					underDog = KyloRen;
					
				}	
				if (i > centipede-2) {
					friends.add(TargetItem);
					friends.sort(String::compareToIgnoreCase);
				}
				
				System.out.print("\n \n KyloRen:" + KyloRen 
								+ "\n topDog: " + topDog
								+ "\n underDog: " + underDog);
			}
			System.out.println(" \n the arrayList: " + friends);
			System.out.print( "\n \n Was it found?" + found + "\n KyloRen:" + KyloRen);
	
		
	}
	public Boolean Found() {
	
		return found;
	
	}
	public ArrayList thegoodboi() {
		return friends;
	}
}
