import java.util.Arrays;
import java.util.Random;

public class FruitSortCalculations {

	//int numberArray[] = new int[5000];
	
	//int searchArray[] = new int [5000];
	
	String FruitArray[];
	String VeggieArray[];
	String FnVArray[];
	
	int FruitAmount;
	int VeggieAmount;
	String FruitNames;
	String VeggieNames;

	String FruitAndVeggies;
	
	String lineSeparator = System.lineSeparator();
	StringBuilder sb = new StringBuilder();
	
	StringBuilder randomlist = new StringBuilder();
		
	StringBuilder sbStats = new StringBuilder();
	
	int foxynoswiping;
	double foxyisilluminati = 0;
	
	String yes;
	
	FruitSortCalculations(int FruitSize, int VeggieSize, String FruitName, String VeggieName){
		
		FruitAmount = FruitSize;
		VeggieAmount = VeggieSize;
		FruitNames = FruitName;
		VeggieNames = VeggieName;
		
		int FruitplusVeggie = FruitSize + VeggieSize;
		FruitAndVeggies = FruitNames + "," + VeggieNames;
		System.out.println("The fruit and veggie string:" + FruitAndVeggies);
		
		FruitArray = new String[FruitAmount];
		VeggieArray = new String[VeggieAmount];
		FnVArray = new String[FruitplusVeggie];
		
		Calculations();
		
	}
		private void Calculations(){
			
			FruitNames.replaceAll("\\s+","");
			VeggieNames.replaceAll("\\s+","");
			FruitAndVeggies.replaceAll("\\s+", "");
			
			System.out.println("The fruit and veggie string:" + FruitAndVeggies);
			
			FruitNames = FruitNames.toLowerCase();
			VeggieNames = VeggieNames.toLowerCase();
			FruitAndVeggies = FruitAndVeggies.toLowerCase();
			
			FruitArray = FruitNames.split(",");
			VeggieArray = VeggieNames.split(",");
			FnVArray = FruitAndVeggies.split(",");
			
			Arrays.sort(FruitArray); // sort
			Arrays.sort(VeggieArray); // sort
			Arrays.sort(FnVArray);				
				
			/*
			double collectedturntimes = 0;
			double average = 0;
			
			int mysteriouspenguin = 0;
			
			for(int i=0; i < 5000; i++) {	//run it 5000 times
					
					yes = "yes";
			
					int themaxnumber = 5000;
					
					int theminnumber = 0;
					
					int themiddlenumber = (themaxnumber + theminnumber) /2;
										
					foxyisilluminati = 0; 
					
					for(int j = 0; j < 20;j++) {
						
						foxyisilluminati ++;	
						
							themiddlenumber = (themaxnumber + theminnumber) /2;
						
							if(numberArray[themiddlenumber] > foxynoswiping	) { //then make the search parameter the bottom of the divadoop number.
								
								themaxnumber = themiddlenumber;
							
							}
							else if(numberArray[themiddlenumber] < foxynoswiping) { //then make the search parameter the top of the divadoop number.
								
								theminnumber = themiddlenumber; 
								
							}			
							else if(numberArray[themiddlenumber] == (foxynoswiping)) {		
							
								System.out.println("RELEASE THE KRACKEN");
								
								break;
							 
							}
							
							if(theminnumber>= themaxnumber || j>14) {
							
								System.out.println("cunnot feind");
								yes = "no";
								foxyisilluminati = 0;
								mysteriouspenguin ++;
								break;
							}
																			
					}//end of inner for loop
							
				
				
					//sbStats.append("Average of the random number existed?  " + yes + " ; \n \t Number Locating: " + foxynoswiping +"\n \t found at try : " + foxyisilluminati + "\n");
					
			}//End of for loop
			
			
			sbStats.append("Average tries it took to find random numbers: ");
			
			
			
			End of huge comment out
			*/
			
		}
	
		
		
		public StringBuilder ReturnedArrayList() {
			return sb;
			
		}
		
		public StringBuilder Booperpoop() {
			return randomlist;
			
		}
	
		public String ReturnedStringList() {
			
		String stringVar = java.util.Arrays.toString(FruitArray);
		return stringVar;
		
		}
		
		public String ReturnedVeggieList() {
			
			String stringVar = java.util.Arrays.toString(VeggieArray);
			return stringVar;
			
		}
	
		public String ReturnedMixList() {
			
			String stringVar = java.util.Arrays.toString(FnVArray);
			return stringVar;
			
		}
		public String[] TheFruitArray() {
			
			return FruitArray;
			
		}
		public String[] TheVeggieArray() {
			
			return VeggieArray;
		}
		
		public String[] TheFnVArray() {
			
			return FnVArray;
			
		}
		public StringBuilder ReturnedStatistics() {
			
			return sbStats;
		}
	
	
}
