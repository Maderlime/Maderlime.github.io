import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FruitSort extends JApplet implements ActionListener {


	JTextArea txaresult = new JTextArea("\n", 30,30);
	
	JTextField txtFruitArraySize = new JTextField(20);
	
	JTextField txtVeggieArraySize = new JTextField(20);
	
	JTextField txtFruitNames = new JTextField(20);
	
	JTextField txtVeggieNames = new JTextField(20);
	
	JTextField txtSearch = new JTextField(20);
	
	JButton btnSet = new JButton("Make My List!");
	
	JButton btnSearch = new JButton("Search");
	
	JPanel pnlMain = new JPanel();
	JPanel pnlInput = new JPanel();
	JPanel pnlOutput = new JPanel();
	
	//The Arrays
	String[] FruitArray;
	String[] VeggieArray;
	String[] FnVArray;

	ArrayList<String> friends = new ArrayList<String>();
	
	
	int ColumnLocation, RowLocation;
	String ColumnLetter;
	int nada = 1;
	
	public void init() { 
		
		DesignInputPanel();
		DesignOutputPanel();

		pnlMain.add(pnlInput);	
		pnlMain.add(btnSet);
		pnlMain.add(btnSearch);
		pnlMain.add(pnlOutput);	
		btnSet.requestFocus();
		resize(500,400);
	
		btnSearch.setEnabled(false);
		setContentPane(pnlMain);
		btnSet.addActionListener(this);
		btnSearch.addActionListener(this);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
			try {
					Object objSource = e.getSource();		/*Find the source of the action trigger*/
					
					if(objSource == btnSet) {
						
						int FruitSize = Integer.parseInt(txtFruitArraySize.getText());
						int VeggieSize = Integer.parseInt(txtVeggieArraySize.getText());
						String FruitNames = txtFruitNames.getText();
						String VeggieNames = txtVeggieNames.getText();
						
						
						StringBuilder sb = new StringBuilder();
						StringBuilder sbStats = new StringBuilder();
						
						FruitSortCalculations TheKnightClass = new FruitSortCalculations(FruitSize,VeggieSize,FruitNames,VeggieNames);
						//sb = TheKnightClass.ReturnedArrayList();
						//sbStats = TheKnightClass.ReturnedStatistics();
						String boop = TheKnightClass.ReturnedStringList();
						String Veggies = TheKnightClass.ReturnedVeggieList();
						String FruitAndVeggies = TheKnightClass.ReturnedMixList();
						
						 FruitArray = TheKnightClass.TheFruitArray();
						 VeggieArray = TheKnightClass.TheVeggieArray();
						 FnVArray = TheKnightClass.TheFnVArray();
						 friends = new ArrayList<>(Arrays.asList(FnVArray));
						txaresult.setText("\n The Fruit Array : " + boop + "\n The Veggie Array : " + Veggies + "\n The Fruit AND Veggie Array: " + FruitAndVeggies);
						btnSearch.setEnabled(true);

						
						
						
					}	
					
					
					if(objSource == btnSearch) {
						String LostItem = txtSearch.getText();
						
						FruitBinaryCalculations ThePeasantClass = new FruitBinaryCalculations(friends, LostItem);
						
						Boolean ExistentialCrisis = ThePeasantClass.Found();
						ArrayList hoopa = ThePeasantClass.thegoodboi();
						
						
						txaresult.append(" \n Does " + LostItem +" exist? "+ ExistentialCrisis + "New Array List :" + hoopa);
						
					}
					
					
			}
			catch(NumberFormatException err){			
				showStatus("please make sure you've entered everything!");
			}
		
	}
	
	public void DesignInputPanel() {
			
			pnlInput.setLayout(new GridLayout(0,2));

		}		
		public void DesignOutputPanel() {
			
			pnlOutput.setLayout(new GridLayout(0,1));
	
			pnlInput.add(new JLabel("Amount of Fruits : "));
				pnlInput.add(txtFruitArraySize);
			pnlInput.add(new JLabel("Amount of Veggies : "));
				pnlInput.add(txtVeggieArraySize);
			pnlInput.add(new JLabel("Name of Fruits \n \t Ex: Bananas, apples, oranges : "));
				pnlInput.add(txtFruitNames);
			pnlInput.add(new JLabel("Name of Veggies \n \t Ex: Spinach, Celery, carrots : "));
				pnlInput.add(txtVeggieNames);
				
			pnlInput.add(new JLabel("Search For Products : "));
				pnlInput.add(txtSearch);
			
			pnlOutput.add(txaresult);
		
		}
		
}
