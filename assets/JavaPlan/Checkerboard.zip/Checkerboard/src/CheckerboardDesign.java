
import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

import java.io.*;
import java.text.*;

import java.util.Random;


public class CheckerboardDesign extends JApplet implements ActionListener{

	
			
														JTextArea txaresult = new JTextArea(
																"ROLL RESULTS" + "\n", 20,30);
				// Create the Checkerboard Submit
				JButton btnAdd = new JButton("Create CheckerBoard");
				//Create the TextFields
				JTextField txtHeight = new JTextField(20);
				JTextField txtWidth = new JTextField(20);
				
				double elHeight, elWidth;
				int intX =100,intY=60;
				int intXWhite =110,intYWhite=60;
				int xamount = 10; 
				boolean OnorOff = false;
				boolean colorGod = true;
				
				
				double cntRmderHeight;
				double cntRmderWidth;
				
				double mula;
					//JPanels
					JPanel pnlMain = new JPanel();
					JPanel pnlInput = new JPanel();
					JPanel pnlOutput = new JPanel();
	
		
		
		
		
	
	//Create the init method(initialize method)
		public void init() {
			
				//place components on the applet panel(Declaring method/functions that will be called)
				DesignInputPanel();
				DesignOutputPanel();
				
				pnlMain.add(pnlInput);
				pnlMain.add(btnAdd);
				pnlMain.add(pnlOutput);
				
				resize(500,550);
	
				//set the content to the panel (or else it wont show up)
				setContentPane(pnlMain);
				btnAdd.addActionListener(this);
				txtHeight.requestFocus();
				txtWidth.addActionListener(this);
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			elHeight = Double.parseDouble(txtHeight.getText());
			elWidth = Double.parseDouble(txtWidth.getText());
			cntRmderHeight = elHeight;
			cntRmderWidth = elWidth;
			mula = cntRmderWidth;
			Object objSource = event.getSource();	
			intX =100;
			intY=60;
			intXWhite =110;
			intYWhite=60;
			colorGod = true;
			 //TIMER
			 if(objSource == btnAdd) {
				startTheTimer();
			}
			
		//put code to move the circle
			if(OnorOff) {
				
				repaint();
			}
			
			
			//CheckerboardCalculations TheBoredClass = new CheckerboardCalculations(elHeight, elWidth);		
			
			
			
			//for outputing writing in the text Area
			txaresult.setText("");
		}
		
		public void paint(Graphics g) {
			super.paint(g);
			//paint a circle
			//black boxes
			double theGod =0;
			boolean odorlessfrog = true;
			for(int s =0; s< cntRmderHeight ;s++) {
				
				intY +=10;
				//intXWhite -= cntRmderWidth*10;
				//intX -= cntRmderWidth *10;
//				intX = 100;
//				intXWhite = 110;
				if (cntRmderWidth%2 ==0) {
				colorGod = !colorGod;}
				intX = 0;

				
				for(int i=0; i<cntRmderWidth; i++) {
					//regular
					if(colorGod == true) {
						g.setColor(Color.black);
						g.fillRect(intX, intY, 10, 10);
						intX +=10;
						colorGod = !colorGod;
					}
					else if(colorGod == false){
						g.setColor(Color.white);
						g.fillRect(intX, intY, 10, 10);
						intX +=10;
						colorGod =!colorGod;
					}
				}
				//colorGod = false;
				
				
			}
			//end

			
		}
		
		public void startTheTimer() {
			//myTimer.start();
			OnorOff = true;
		}
		public void stopTheTimer() {
			//myTimer.stop();
			OnorOff = false;		
		}
		
		
		
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));	
			pnlInput.add(new JLabel("Width: "));
			pnlInput.add(txtWidth);
			pnlInput.add(new JLabel("Height: "));
			pnlInput.add(txtHeight);
		}
		
		public void DesignOutputPanel() {
			//pnlOutput.setLayout(new GridLayout(0,1));
			//pnlOutput.add(txaresult);		
		}
		
	
	
}
