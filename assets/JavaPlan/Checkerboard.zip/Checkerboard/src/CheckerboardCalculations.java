
public class CheckerboardCalculations {
	
	//My Variables
	double dblHeight, dblWidth;
	
	
	CheckerboardCalculations(double Height, double Width){
	//grab the variables then take us to the Calculate Charge function.
		dblHeight = Height;
		dblWidth = Width;
		CalculateCharge();
	}
	
	public void CalculateCharge() {
		
		
	}

}
