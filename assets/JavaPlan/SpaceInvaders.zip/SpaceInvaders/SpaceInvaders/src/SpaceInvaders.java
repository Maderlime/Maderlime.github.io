//Name: Madeline Tjoa
//Date: 9/5/17
/*
 * 
 * This project codes concatenation and how to do buttons and text fields
 * 
 */

import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;

public class SpaceInvaders extends JApplet implements ActionListener, KeyListener{

			//design
			JPanel pnlPanel = new JPanel();
			JPanel pnlMain = new JPanel();
			
			JPanel pnlInput = new JPanel();
			JPanel pnlOutput = new JPanel();

			Image carImage;

			
			//RED timer buttons
			JButton btnStart = new JButton("Start");
			JButton btnStop = new JButton("Stop");
			
			
			//RED location variables //timer buttons
			int intX = 50;
			int intY = 50;
			int xamount = 10; 
			boolean OnorOff = false;
			Timer myTimer = new Timer(100,this);
			
			//CAR the car's corrdinates
			int xPositionInteger = 50;
			int yPositionInteger = 300;
		
			DefineInvader Circles[] = new DefineInvader[3];
		
			boolean timerSwitch = false;
			//Timer myTimer = new Timer(100, this);
		//Ship Movement Variables
			int shipPositionX = 0;
			int shipPositionY = 400;
			int shipSpeed = 10;
			Image shipImage;
			
		//bullet Movement Variables
			int bulletPositionX = shipPositionX;
			int bulletPositionY = 300;
			int bulletSpeed = -10;
			boolean bulletTrigger = false;
			boolean harry = false;
			Image bulletImage;
			
			
			
			int deathtothePuffles =3;
		
		
	
	//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			
		
			pnlMain.add(pnlOutput);
	
			//RED TIMER_PT2
			pnlMain.add(btnStart);
			pnlMain.add(btnStop);
			//end
			
			resize(500,300);
			for (int i = 0; i <3; i++) {
				Circles[i] = new DefineInvader();
			}
			for (int j = 0; j<3;j++) {
				int xpos, ypos, xspeed,yspeed,life;
				xpos = (int)(Math.random()*750);
				ypos = (int)(Math.random()*550);
				xspeed = (int)(Math.random()*2);
				life = 3;
					if(xspeed ==0) {
						   xspeed = 10;}
					else { 
						   xspeed = -10;}
				Circles[j].setCircle(xpos, ypos, xspeed, 0, "Red",life);
			}
										
			 //CAR image gather
			carImage = getImage(getDocumentBase(),"AUTO.gif");
			addKeyListener(this);
			setFocusable(true);
			
			
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			
									

			//REDTIMER ALSO
			btnStart.addActionListener(this);
			btnStop.addActionListener(this);
			
			
		}
		
		
		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			//!declare variable for which button or action is called!
			requestFocus();
			Object objSource = event.getSource();			
				
				 //TIMER
				 if(objSource == btnStart) {
					startTheTimer();
				}
				else if(objSource == btnStop) {
					stopTheTimer();
				}
				
			//put code to move the circle
				if(OnorOff) {
					if(intX>300) {
						xamount*=-1;
						intY +=20;
					}
					else if(intX<0) {
						xamount*=-1;
						intY +=20;
					}
					intX += xamount;
					repaint();
					for (int k = 0; k<3;k++) {
						Circles[k].xDist += Circles[k].velX;
						repaint();
					}
				}
				
			
		}
		
		
		 public void keyPressed(KeyEvent event)
		 {
		   int key = event.getKeyCode();
		   //nameTextField.setText(""+ key);
		   if (key == 37){
			 xPositionInteger -= 10;}

		  else if (key == 39)
			  {xPositionInteger += 10;}


			 repaint();

		}
		
		
		public void startTheTimer() {
			myTimer.start();
			OnorOff = true;
		}
		public void stopTheTimer() {
			myTimer.stop();
			OnorOff = false;		
		}
//TIMER END			
		public void Update(Graphics g) {
			paint(g);
		}
	//create the paint method to show graphics
		public void paint(Graphics g) {
			super.paint(g);
			
			//CAR
			g.drawImage(carImage,xPositionInteger, yPositionInteger,this);
			//RED paint a circle
			g.setColor(Color.red);
			g.fillOval(intX, intY, 50, 50);
			
			for(int m=0;m<3;m++) {
				g.setColor(Color.red);
				g.fillOval(Circles[m].xDist, Circles[m].yDist, 50, 50);
			}
//end
			
		}

		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			
		}
		
		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	
	
}
