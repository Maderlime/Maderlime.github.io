
public class DefineInvader {
	int xDist;
	int yDist;
	int velX;
	int velY;
	int lifespan;
	String theColor;
	
	public void setCircle(/*foreign variables: */int x, int y, int vX, int vY, String Acolor, int life) {
		//set the domestic variables equal to the foreign variables	
			xDist = x;
			yDist = y;
			velX = vX;
			velY = vY;
			theColor = Acolor;		
			lifespan = life;
	}
}
