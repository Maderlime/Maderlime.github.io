import java.text.DecimalFormat;

import javax.swing.ButtonGroup;
public class CrapsGameARFormat {

		private double dblP2, dblP3, dblP4, dblP5, dblP6, dblP7, dblP8, dblP9, dblP10, dblP11, dblP12;
	CrapsGameARFormat(double F2){
		
		//theRate and theHours are the parameters for the method
				dblP2 = F2;
				
		
				CalculateCharge();
				
				
				
		}
	
	private void CalculateCharge() {
		
		DecimalFormat decFor = new DecimalFormat("0.###");
		String pof2 = decFor.format(dblP2);
		
		
		double P2 =  Double.parseDouble(pof2); 
		
		
		dblP2 = P2;
		
		
	}
	
	public double ReturnP2() {
		return dblP2;	
	}	
	

	
	
}
