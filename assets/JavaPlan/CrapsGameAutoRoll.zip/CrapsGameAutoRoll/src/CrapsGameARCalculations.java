import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;

public class CrapsGameARCalculations {
	//class variables
	private double dbldice1, dbldice2, amountofGames;
	
//static means hold its value over time.

	
	static double timesRolled;
	static double timesRolled2;
	static double timesRolled3;
	static double timesRolled4;
	static double timesRolled5;
	static double timesRolled6;
	static double timesRolled7;
	static double timesRolled8;
	static double timesRolled9;
	static double timesRolled10;
	static double timesRolled11;
	static double timesRolled12;
	double LeSum;
	
	private double diceSUM;
	
	private static boolean WinnerWoop = false;
	private static boolean LoserWoop = false;
	private static boolean Meeeh = true;
	static double targetScore;
	static int Placing = 0;
	static int turnnumber = 0;
	
	
			

//create our class constructor
//The class calls this method first
//The constructor has the same name as the class
	CrapsGameARCalculations(double dice1, double dice2, double desiredGames){
	
	//theRate and theHours are the parameters for the method
			dbldice1 = dice1;
			dbldice2 = dice2;
			amountofGames = desiredGames;
			
			
			CalculateCharge();
			
			
			
	}

//create our calculator functions
	private void CalculateCharge() {
	
		//numberProcessedint ++;			
		double Deece1 = dbldice1;
		double Deece2 = dbldice2;
		
		LeSum = Deece1 + Deece2;
		diceSUM = LeSum;
		timesRolled ++;
		
//first turn
	if (turnnumber ==0) {
		if (LeSum ==2) {
			LoserWoop = true;
			turnnumber = 0;
			WinnerWoop = false;
			Meeeh = false;
		}
		else if (LeSum ==3) {
			LoserWoop = true;
			WinnerWoop = false;
			turnnumber = 0;
			Meeeh = false;
		}
		else if (LeSum ==4) {
			WinnerWoop = false;
			Meeeh = true;
			LoserWoop = false;
			targetScore = 4;
			turnnumber += 1;
		}
		else if (LeSum ==5) {
			WinnerWoop = false;
			Meeeh = true;
			LoserWoop = false;
			targetScore = 5;
			turnnumber += 1;
		}
		else if (LeSum ==6) {
			targetScore = 6;
			WinnerWoop = false;
			LoserWoop = false;
			Meeeh = true;
			turnnumber += 1;
		}
		else if (LeSum ==7) {
			WinnerWoop = true;
			LoserWoop = false;
			turnnumber = 0;
			Meeeh = false;
		}
		else if (LeSum ==8) {
			targetScore = 8;
			WinnerWoop = false;
			LoserWoop = false;
			Meeeh = true;
			turnnumber += 1;
		}
		else if (LeSum ==9) {
			targetScore = 9;
			WinnerWoop = false;
			LoserWoop = false;
			Meeeh = true;
			turnnumber += 1;
		}
		else if (LeSum ==10) {
			targetScore = 10;
			WinnerWoop = false;
			LoserWoop = false;
			Meeeh = true;
			turnnumber += 1;
		}
		else if (LeSum ==11) {
			//timesRolled11 ++;
			//targetScore = 11;
			WinnerWoop = true;
			LoserWoop = false;
			turnnumber = 0;
			Meeeh = false;
		}
		else if (LeSum ==12) {
			//timesRolled12 ++;
			//targetScore =12;
			turnnumber = 0;
			LoserWoop = true;
			WinnerWoop = false;
			Meeeh = false;
		}
			
		}
//any other turns
	else {
			if (LeSum ==2) {
				LoserWoop = false;
				WinnerWoop = false;
				Meeeh = true;
				turnnumber ++;
			}
			else if (LeSum ==3) {
				LoserWoop = false;
				WinnerWoop = false;
				Meeeh = true;
				turnnumber ++;
			}
			else if (LeSum ==4) {
				timesRolled4 ++;
				if(targetScore == 4) {
					WinnerWoop = true;
					LoserWoop = false;
					Meeeh = false;
					turnnumber = 0;
				}
				else{
					WinnerWoop = false;
					Meeeh = true;
					LoserWoop = false;
					turnnumber ++;
					//targetScore = 4;
				}
			}
			else if (LeSum ==5) {
				timesRolled5 ++;
				if(targetScore == 5) {
					WinnerWoop = true;
					Meeeh = false;
					LoserWoop = false;
					turnnumber = 0;
				}
				else{
					
					WinnerWoop = false;
					Meeeh = true;
					LoserWoop = false;
					turnnumber ++;
					//targetScore = 5;
				}
			}
			else if (LeSum ==6) {
				//timesRolled6 ++;
				if(targetScore == 6) {
					WinnerWoop = true;
					Meeeh = false;
					LoserWoop = false;
					turnnumber = 0;
				}
				else{
					//targetScore = 6;
					WinnerWoop = false;
					LoserWoop = false;
					Meeeh = true;
					turnnumber ++;
				}
			}
			else if (LeSum ==7) {
				
				WinnerWoop = false;
				LoserWoop = true;
				Meeeh = false;
				turnnumber = 0;
			}
			else if (LeSum ==8) {
				timesRolled8 ++;
				if(targetScore == 8) {
					WinnerWoop = true;
					LoserWoop = false;
					Meeeh = false;
					turnnumber = 0;
				}
				else{
					//targetScore = 8;
					WinnerWoop = false;
					LoserWoop = false;
					Meeeh = true;
					turnnumber ++;
				}
			}
			else if (LeSum ==9) {
				timesRolled9 ++;
				if(targetScore == 9) {
					WinnerWoop = true;
					Meeeh = false;
					LoserWoop = false;
					turnnumber = 0;
				}
				else{
					//targetScore = 9;
					WinnerWoop = false;
					LoserWoop = false;
					Meeeh = true;
					turnnumber ++;
				}
			}
			else if (LeSum ==10) {
				timesRolled10 ++;
				if(targetScore == 10) {
					WinnerWoop = true;
					LoserWoop = false;
					Meeeh = false;
					turnnumber = 0;
				}
				else{
					
					WinnerWoop = false;
					LoserWoop = false;
					Meeeh = true;
					turnnumber ++;
				}
			}
			else if (LeSum ==11) {
				//timesRolled11 ++;
				//targetScore = 11;
				WinnerWoop = false;
				LoserWoop = false;
				Meeeh = true;
				turnnumber ++;
				//turnnumber = 0;
			}
			else if (LeSum ==12) {
				//timesRolled12 ++;
				//targetScore =12;
				LoserWoop = false;
				WinnerWoop = false;
				Meeeh = true;
				turnnumber ++;
			}
			//turnnumber +=1;
		}
		DetermineClass();
		
		
		
		
		
		
	}
	
	private void DetermineClass() {
		if (WinnerWoop == true && Meeeh == false && LoserWoop == false) {
			Placing = 1;
		}
		else if(LoserWoop == true && Meeeh == false && WinnerWoop == false) {	
			Placing = 2;
		}
		else if(Meeeh == true){
			Placing = 3;
		}
	}

//return answers into the other class
	public double diceSum() {
		//CalculateMiles();
		return diceSUM;
		
	}
	public double LeRolls() {
		return timesRolled;	
		//return averageSpent;
		
	}


	public double PlayString() {
		return Placing;
	}
	public double targetScoree() {
		return targetScore;
		
	}
}