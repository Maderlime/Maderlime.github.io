
import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

import java.io.*;
import java.text.*;

import java.util.Random;


public class CrapsGameARDesignClass extends JApplet implements ActionListener{

	
	
		JTextArea txaresult = new JTextArea(
				"ROLL RESULTS" + "\n", 20,30);
	
		
		JTextField txtName = new JTextField(20);
		JButton btnAdd = new JButton("Roll Dice");
	
		
		
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		
		double diceSum = 0;
		double timesrolled;
		
		static double timeswon = 0;
		static double timeslost = 0;
		
		double elamigo = 0;
		
		Random rand = new Random();
		
		double  dice1;
		double  dice2;	 
		
		String ooutput = "Winner!";
		double theStringerTarger;
		String tiger;
		
		
	
	//Create the init method(initialize method)
		public void init() {
			
			
		
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			
			
			resize(350,550);
			txtName.requestFocus();
			
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
			txtName.addActionListener(this);
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			double desiredGames = Double.parseDouble(txtName.getText());
		//2. information			
			String nameString;
			elamigo = desiredGames;
//3. Calculate 
			while(elamigo > 0) {
			nameString = txtName.getText();
			
			double  potato1 = rand.nextInt(6) + 1;
			double  potato2 = rand.nextInt(6) + 1;
			
			dice1 = potato1;
			dice2 = potato2;
			
			CrapsGameARCalculations ThePayClass = new CrapsGameARCalculations(dice1, dice2, desiredGames);		
			
			
			double FdiceSum = ThePayClass.diceSum();
			double FtimesRolled = ThePayClass.LeRolls();
			
			double WinnerLoser = ThePayClass.PlayString();
			double Target = ThePayClass.targetScoree();
			
			if(WinnerLoser == 1) {			
				ooutput = "Ya Win";
				timeswon ++;
				elamigo--;
				theStringerTarger = 0;
			}
			if(WinnerLoser == 2) {
				ooutput = "Ya Losed";
				timeslost ++;
				elamigo--;
				theStringerTarger = 0;
			}
			if(WinnerLoser ==3) {
				ooutput = "No Win, No Lose";
				 tiger = Double.toString(Target);
			}
			
			else if(theStringerTarger == 0) {
				tiger = "No Number Kappa cuz \n "
						+ "\t we startin over \n "
						+ "\t or you got a Winning or Lost.";
			}
			
			double Probability = timeswon/desiredGames;
			CrapsGameARFormat Problems = new CrapsGameARFormat(Probability);

			double Probablility2 = Problems.ReturnP2();
			
		//extra: connect to a format class	
			
			//CrapsFormat Problems = new CrapsFormat(FProb2, FProb3, FProb4, FProb5, FProb6, FProb7, FProb8, FProb9, FProb10, FProb11, FProb12);
			
		//4. output in the text Area
			txaresult.setText("\n \t Games You played: "  + desiredGames +
								" \n Number of Total Rolls: " + FtimesRolled +
								"\n times won: " + timeswon+ 
								"\n times lost: " + timeslost+
								"\n Probability of winning: " + Probablility2+ 
								"\n"	
								);
			}
			txtName.setText("");
			txtName.requestFocus();
			
		
		}
		
		//Total Charge
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			pnlInput.add(new JLabel("Games Desired: "));
			pnlInput.add(txtName);
				
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);
		}
		
	
	
}


