//madeline tjoa BMI

import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

import java.io.*;
import java.text.*;


public class CarRental extends JApplet implements ActionListener{

	//declare our components or fields(global level variable)
		JTextField txtName = new JTextField(20);
		JTextField txtAddress = new JTextField(20);
		JTextField txtCity = new JTextField(5);
		JTextField txtState = new JTextField(20);
		JTextField txtZipCode = new JTextField(5);
		JTextField txtOdo1 = new JTextField(5);
		JTextField txtOdo2 = new JTextField(20);
		JTextField txtDays = new JTextField(5);
	
		JTextArea txaresult = new JTextArea(
				"Miles Driven | Total Charge | Customer Info" + "\n", 10,33);
	
		JButton btnAdd = new JButton("Rent A Car");
	
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		double totalRentals;
		double moneyGained;
		double averageSpent;
		
		
	
	//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			resize(500,400);
			txtName.requestFocus();
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
			txtName.addActionListener(this);
			txtAddress.addActionListener(this);
			txtCity.addActionListener(this);
			txtState.addActionListener(this);
			txtZipCode.addActionListener(this);
			txtOdo1.addActionListener(this);
			txtOdo2.addActionListener(this);
			txtDays.addActionListener(this);
			
			
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			String nameString;
			String AddressString;
			String CityString;
			String StateString;
			String ZipCodeString;
			
			
			
			
			String outputString;
			
			double Odo1Double;
			double Odo2Double;
			double DaysDouble;
			
			
			
		//2. information	
		try {
			nameString = txtName.getText();
			AddressString = txtAddress.getText();
			CityString = txtCity.getText();
			StateString = txtState.getText();
			ZipCodeString = txtZipCode.getText();
			
			
			Odo1Double = Double.parseDouble(txtOdo1.getText());
			Odo2Double = Double.parseDouble(txtOdo2.getText());
			DaysDouble = Double.parseDouble(txtDays.getText());
			
			
//3. Calculate 
				
			CarCalculations ThePayClass = new CarCalculations(Odo1Double,Odo2Double,DaysDouble);
			double payDouble = ThePayClass.getPay();
			double milesDouble = ThePayClass.getMilesDriven();
			double TotalRentals = ThePayClass.getEmployeeCount();
			double averagespent = ThePayClass.getAveragePay();
			double earned = ThePayClass.getTotalMade();
			
					
			
			
		//extra: connect to a format cclass	
			//String formattedDataString;
			NumberFormat fmtCurrency = NumberFormat.getCurrencyInstance();
			DecimalFormat decFor = new DecimalFormat("####.00");
			//formattedDataString = fmtCurrency.format(payDouble);

			//String betterNumber = decFor.format(payDouble);
			
			//payDouble = decFor.format(payDouble);
			
					
			
		//4. output in the text Area
			txaresult.setText("Name: " + nameString + 
									" \n \t Total Charge: " + fmtCurrency.format(payDouble) + 
									" \n \t Miles Driven: " + milesDouble +
									"\n \t Address: " + AddressString + "\n \t \t" + CityString +", " + StateString + " " + ZipCodeString + 
									"\n \n Company Statistics: " + " \n total rentals :" + TotalRentals + " \n money gained:" + fmtCurrency.format(earned) + "\n Average Spent: " + fmtCurrency.format(averagespent)+
									"\n \n \n ____-----end-----____");
			
			txtName.setText("");
			txtAddress.setText("");
			txtCity.setText("");
			txtState.setText("");
			txtZipCode.setText("");
			txtOdo1.setText("");
			txtOdo2.setText("");
			txtDays.setText("");
			
			txtName.requestFocus();
			}
		catch(NumberFormatException err){
			
			showStatus("please make sure you've entered everything!");
		}
		}
		
		//Total Charge
		public double calculatetotalCharge (double theOdo1, double theOdo2, double theDays) {
			double thePay = 0;
			double Odometer1 = theOdo1;
			double Odometer2 = theOdo2;
			double Days = theDays;
			
			double MilesDriven = Odometer2 - Odometer1;
			double totalCharge = 15*(Days) + .12* (MilesDriven);
			moneyGained += totalCharge;
			totalRentals +=1;
			averageSpent = totalCharge/totalRentals;
			
			return totalCharge;
			
		}
		
		//Miles Driven
		public double calculateMilesDriven (double theOdo1, double theOdo2, double theDays) {
			double thePay = 0;
			double Odometer1 = theOdo1;
			double Odometer2 = theOdo2;
			double Days = theDays;
			
			double MilesDriven = Odometer2 - Odometer1;
		
			
			
			return MilesDriven;
			
		}
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			
			pnlInput.add(new JLabel("Name: "));
				pnlInput.add(txtName);
			pnlInput.add(new JLabel("Address: "));
				pnlInput.add(txtAddress);
			pnlInput.add(new JLabel("City: "));
				pnlInput.add(txtCity);
			pnlInput.add(new JLabel("State: "));
				pnlInput.add(txtState);
			pnlInput.add(new JLabel("Zipcode: "));
				pnlInput.add(txtZipCode);
			pnlInput.add(new JLabel("Odometer1: "));
				pnlInput.add(txtOdo1);
			pnlInput.add(new JLabel("Odometer2: "));
				pnlInput.add(txtOdo2);
			pnlInput.add(new JLabel("Days: "));
				pnlInput.add(txtDays);
				
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);
			
		}
		
	
	
}
