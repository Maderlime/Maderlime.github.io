
public class CarCalculations {
	//class variables
	private double dblOdo1, dblOdo2,dblDays;
	
//static means hold its value over time.
	private int numberProcessedint;
	private double moneyGained;
	static double totalRentals;
	static double averageSpent;
	private double MilesDriven;
	static double totalCharge;

//create our class constructor
//The class calls this method first
//The constructor has the same name as the class
	CarCalculations(double theOdo1, double theOdo2, double theDays){
	
	//theRate and theHours are the parameters for the method
			dblOdo1 = theOdo1;
			dblOdo2 = theOdo2;
			dblDays = theDays;
			CalculateCharge();
	}

//create our calculator functions
	private void CalculateCharge() {
	
		
		//numberProcessedint ++;		
		
		double thePay = 0;
		double Odometer1 = dblOdo1;
		double Odometer2 = dblOdo2;
		double Days = dblDays;
		
		 MilesDriven = Odometer2 - Odometer1;
		totalCharge = 15*(Days) + .12* (MilesDriven);
		moneyGained += totalCharge;
		totalRentals +=1;
		averageSpent = totalCharge / totalRentals;
		
		
	}

	private void CalculateMiles() {
		
		double MilesDriven;
		
	}

//return answers into the other class
	public double getMilesDriven() {
		//CalculateMiles();
		return MilesDriven;
		
	}
	public double getPay() {
		
		
		
		return totalCharge;	
		//return averageSpent;
		
	}
	public double getTotalMade() {
		//CalculateCharge();
		return moneyGained;
		
	}
	
	public double getAveragePay() {
		
		
		//CalculateCharge();
		return averageSpent;	
		//return averageSpent;
		
	}
//return back answers that is public	
	public double getEmployeeCount() {
		//CalculateCharge();
		return totalRentals;			
	}
}
