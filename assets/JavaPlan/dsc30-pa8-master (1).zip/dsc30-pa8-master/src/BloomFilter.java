import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.AllPermission;
import java.text.DecimalFormat;

/**
 * Madeline Tjoa
 * A15394053
 *
 * */
/**
 *
 * Bloom filter class
 * */
public class BloomFilter {
    public static final int NUMBITS = 8;
    public static final int ALLOCATEDFRACTION = 3/2;
    public static final int PJW_HASH_SHIFT = 4; // How much to shift hash by, per char hashed
    public static final int PJW_HASH_RIGHT_SHIFT = 24; // Right-shift amount, if top 4 bits NZ
                                                        // 32-BIT
    public static final int PJW_HASH_MASK = 0xf0000000;// Mask for extracting top 4 bits
                                                         // 32-BIT
    public static final int NUM_HASHFUNCTIONS = 3;

    public static final int HASHVALUE1 = 0;
    public static final int HASHVALUE2 = 1;
    public static final int HASHVALUE3 = 2;

    public static final int HASHVALUE1_VAR = 5;
    public static final int HASHVALUE2_VAR = 27;
    public static final int HASHVALUE3_VAR = 7;

    byte[] table; // the byte array used as hash table of bits

    int numSlots; // the number of slots (bits) in the hash table

    /**
     * The constructor that creates a bloom filter of size numBytes in byte and 
     * with 8 * numBytes slots (in bits).
     *
     * @param numBytes the number of bytes allocated for the byte array
     */
    public BloomFilter(int numBytes) {
        try {
            this.table = new byte[numBytes];
            this.numSlots = numBytes * NUMBITS;
        }
        catch (Exception e){
            System.out.println("Problem in BloomFilter Constructor: ");
            System.out.println("Error: " + e);
        }

    }

    /**
     * Insert string into the hash table, adds it thrice with three different indexes.
     * @param str the string thats going to be added
     * */
    public void insert(String str) {
        try {
            int[] hashValues = hashValuesArray(str, numSlots); // to get the
            // byte index, i need to set
            for(int i = 0; i< hashValues.length; i++){
                setBit(hashValues[i]/NUMBITS, hashValues[i]%NUMBITS);
            }
        }
        catch (Exception e){
            System.out.println("Problem in BloomFilter insert: ");
            System.out.println("Error: " + e);
        }
    }

    /**
     * Helper method to set a bit in the table to 1, which is specified by the given byteIndex 
     * and bitIndex
     * @param byteIndex the index of the byte in hash table
     * @param bitIndex the index of the bit in the byte at byteIndex. Range is [0, 7]
     */
    private void setBit(int byteIndex, int bitIndex) {
        // set the bit at bitIndex of the byte at byteIndex
        table[byteIndex] = (byte) (table[byteIndex] | ((1 << (NUMBITS - 1)) >> bitIndex));
    }

    /**
     * finds if the string exists
     * @param str the string that is being looked for
     * @return boolean true if it is found false if it is not found
     * */
    public boolean find(String str) {
        try {
            int[] byteIndex = hashValuesArray(str, numSlots);

            for (int i = 0; i < byteIndex.length; i++) {
                if (getSlot(byteIndex[i] / NUMBITS, byteIndex[i] % NUMBITS) == 0) {
                return false;
                }
            }
            return true;
        }
        catch (Exception e){
            System.out.println("Problem in BloomFilter find: ");
            System.out.println("Error: " + e);
        }
        return false;
    }

    /**
     * Helper method to get the bit value at the slot,
     * which is specified by the given byteIndex
     * and bitIndex
     * @param byteIndex the index of the byte in hash table
     * @param bitIndex the index of the bit in the byte at byteIndex. Range is [0, 7]
     */
    private int getSlot(int byteIndex, int bitIndex) {
        return (table[byteIndex] >> ((NUMBITS - 1) - bitIndex)) & 1;
    }

    /**
     * hasheds all of the values at the same time
     *
     * @param str string that will be hashed
     * @param size the size of the array that the has will go into
     * @return int array of the results from hashs
     * */
    public int[] hashValuesArray(String str, int size){
        int[] values = new int[NUM_HASHFUNCTIONS];
        values[HASHVALUE1] = hashStringCRC(str, size);
        values[HASHVALUE2] = hashPJW(str, size);
        values[HASHVALUE3] = hashStringPreiss(str, size);
        return values;
    }

    /**
     * ------------------------------- Hash Method 1 --------
     * */
    /**
     * Hash function 1
     * @param string the string that will be hashed
     * @param size the size of the array we hash
     * @return int index of the hashed value to place it in   */
    public int hashStringCRC(String string, int size){

        int hashValue = 0;

        for(int i = 0; i < string.length(); i++){
            int leftShiftValue = hashValue << HASHVALUE1_VAR;
            int rightShiftValue = hashValue >>> HASHVALUE2_VAR;
            hashValue = (leftShiftValue | rightShiftValue) ^ string.charAt(i);
        }
        if(hashValue < 0){
            hashValue *= -1;
        }
        return hashValue % size;
    }
    /**
     * Hash function 2
     * @param key the string that will be hashed
     * @param tableSize the size of the array we hash
     * @return int index of the hashed value to place it in
     * */
    public int hashStringBase256(String key, int tableSize)
    // Size of hash table (hash modulus)
    {
        int hashValue = 0;
        for (int i = 0; i < key.length(); i++)
        {
            hashValue = (hashValue << NUMBITS) + key.charAt(i);
            hashValue %= tableSize;
        }
        if(hashValue < 0){
            hashValue *= -1;
        }
        return hashValue % tableSize;
    }
    /**
     * Hash function 3
     * @param key the string that will be hashed
     * @param size the size of the array we hash
     * @return int index of the hashed value to place it in
     * */
    public int hashPJW(String key, int size)		// Key to be hashed
    {
        int hashValue = 0;
        for (int i = 0; i <key.length(); i++)
        {
            hashValue = (hashValue << PJW_HASH_SHIFT) + key.charAt(i);
            int rotate_bits = hashValue & PJW_HASH_MASK;
            hashValue ^= rotate_bits | (rotate_bits >> PJW_HASH_RIGHT_SHIFT);
        }
        if(hashValue < 0){
            hashValue *= -1;
        }
        return hashValue % size;
    }

    /**
     * Hash function 4
     *
     * @param key the string that will be hashed
     * @param size the size of the array we hash
     *
     * @return int index of the hashed value to place it in
     * */
    public int hashStringPreiss(String key, int size)
    {
        int hashValue = 0;
        for (int i = 0; i < key.length(); i++) {
            int letter = key.charAt(i);
            hashValue = (hashValue * HASHVALUE3_VAR + letter);
        }
        if(hashValue < 0){
            hashValue *= -1;
        }
        return hashValue % size;

    }
}
