/**
 * Madeline Tjoa
 * A15394053
 * */
import static org.junit.Assert.*;
/**
 * Tester methods
 * */
public class HashTableTester {
    HashTable mh1 = new HashTable(10);
    @org.junit.Before
    public void setUp() throws Exception {
        mh1.insert("e");
        mh1.insert("f");
        mh1.insert("frog");
        mh1.insert("bomboozle");
    }

    @org.junit.Test
    public void testInsert(){
        assertFalse(mh1.insert("bomboozle"));
        assertTrue(mh1.insert("guh"));
        mh1.delete("guh");
        assertTrue(mh1.insert("guh"));

    }

    @org.junit.Test
    public void testLookup(){
       assertEquals(false, mh1.lookup("l"));
       mh1.insert("l");
       assertTrue(mh1.lookup("l"));
       mh1.delete("l");
       assertFalse(mh1.lookup("l"));
    }

    @org.junit.Test
    public void testDelete(){
        assertFalse(mh1.delete("hello"));
        assertTrue(mh1.delete("bomboozle"));
        assertFalse(mh1.delete("bomboozle"));
    }

    @org.junit.Test
    public void testGetSize(){
        assertEquals(4, mh1.getSize());
        mh1.insert("hhohohoho");
        assertEquals(5, mh1.getSize());
        mh1.insert("hoe");
        assertEquals(6, mh1.getSize());
    }

    @org.junit.Test
    public void testrrehasg(){
      mh1.insert("eee");
        mh1.insert("eeee");

    }



}