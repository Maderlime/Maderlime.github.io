import org.junit.After;
import org.junit.Before;

import static org.junit.Assert.*;
/**
 * Madeline Tjoa
 * A15394053
 * */
/**
 * Tester for LRU Cache
 * */
public class LRUCacheTest {

    @org.junit.Before
    public void setUp() throws Exception {
        LRUCache bro = new LRUCache(3);
        System.out.println(bro.capacity);
        bro.printStats();
        bro.set(0,3);
        bro.printStats();
        bro.set(2,2);
        bro.printStats();
        bro.set(4,1);
        bro.printStats();
        bro.set(3,0);
        bro.printStats();
        bro.set(1,7);

    }

    @org.junit.Test
    public void tearDown() throws Exception {
    }
}