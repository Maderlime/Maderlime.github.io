/**
 * Madeline Tjoa
 * A15394053
 *
 * */
import java.io.*;
import java.text.DecimalFormat;
import java.util.Scanner;  // Import the Scanner class
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.Files;


/**
 * This program takes in 3 command line arguments.
 * The first one is the malicious URL file. The second one is the
 * mixed URL file, which contains malicious URLs from the given
 * malicious URL file, and other safe URLs as well.
 * The third one is the name of the file to write your output to,
 * which contains every URL from the mixed URL file
 * that are for sure known to be safe after using bloom
 * filter (think about what that means about the
 * false positives), one URL per line.
 *
 * Note that you should only use at most 3 bytes for each
 * 2 malicious URLs in your Bloom Filter. For example, if the
 * malicious URL file contains 30000 URLs, then you should
 * use at most 45000 bytes in your bloom filter.
 */
public class Firewall {

    public static final double LOAD_FACTOR = (double)3/(double)2;
    /**
     * Main method that drives this program
     * @param args the command line argument
     */
    public static void main(String args[]) {

        //TODO

        int numSafeURL = 0;
        int numBadURL = 0;
        int numTotalURL = 0;
        // Get the size of badURL in bytes
        File badURL = new File(args[0]);
        File mixedURL = new File(args[1]);
        File writeURL = new File(args[2]);

        long inputSize = 0;
        try {
            inputSize = Files.lines(Paths.get(args[0])).count();
        } catch (IOException e) {
            e.printStackTrace();
        }
        inputSize *= LOAD_FACTOR;

        double numberBytes = LOAD_FACTOR * (double)inputSize;

        BloomFilter myBloomFilter = new BloomFilter((int)inputSize);

        int BIGBADWOLF = 0;
        try {

            Scanner myObj = new Scanner(badURL);
            //have an arraylist to read the input file that has all
            // the words and insert all the words to the hash table
            while(myObj.hasNext()){
                myBloomFilter.insert(myObj.nextLine());
                BIGBADWOLF ++;
            }

        } catch (FileNotFoundException e) {
//            System.out.println("populating badURL error");
            e.printStackTrace();
        }

//        System.out.println("completed bloomfilter insertion");

        // check the mixed url and bloom filters
        try {

            Scanner myObj = new Scanner(mixedURL);
            PrintWriter pw = new PrintWriter(new FileOutputStream(writeURL,true));
            //have an arraylist to read the input file that has all the words
            // and insert all the words to the hash table
            while(myObj.hasNextLine()){
                String myURL = myObj.nextLine();
                boolean isBad = myBloomFilter.find(myURL);
                if(!isBad){
                    numSafeURL++;
                    pw.println(myURL);

                }
                numTotalURL ++;

            }
            pw.close();
            myObj.close();


        } catch (FileNotFoundException e) {
//            System.out.println("populating badURL error");
            e.printStackTrace();
        }

        // System.out.println("number of total: " + totalLines);

//        System.out.println("number found safe URL: " + numSafeURL);
//        System.out.println("num total URL: " + numTotalURL);
//        System.out.println("BIGBAD NUMBER OF BAD LIST: " + BIGBADWOLF);


        long goodURLS = numTotalURL - BIGBADWOLF;

//        System.out.println("the good URLs: " + goodURLS);
//        // print statistics
//        System.out.println("goodURLs: " + goodURLS);
//        System.out.println("sumSafeURL: " + numSafeURL);
//        System.out.println("goodURLs: " + goodURLS);

        double falsePositiveRate = ((double)goodURLS - (double)numSafeURL) / (double)goodURLS;
        System.out.println("False positive rate: " + falsePositiveRate);


        double myInputBytes = badURL.length();
        double myBloomBytes = inputSize;
//        System.out.println(myInputBytes);
//        System.out.println(myBloomBytes);

        System.out.println("Saved memory ratio: " + (int)(myInputBytes/myBloomBytes));
    }


}
