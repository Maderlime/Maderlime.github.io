import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HashSortTest {

    @Before
    public void setUp() throws Exception {
        HashSort hello = new HashSort();
        int[] help = {1,5,7,2,8,3};

        
    }

    @Test
    public void please(){

    }
}