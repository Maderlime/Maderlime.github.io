import java.util.HashMap;
import java.util.LinkedList;
/**
 * Madeline Tjoa
 * A15394053
 * */
/**
 * The name of your class should be LRUCache.java.
 * single constructor which will take the capacity(int) of the cache as its parameter.
 * You may write private helper methods, data members and inner classes if necessary.
 * Also, you may use Java’s own classes and methods for Hashing.
 * Most importantly, try to optimize both the methods to have a time complexity of O(1).
 *
 * Hint: You may need to use a DoublyLinkedList and a HashMap for this problem
 * */
public class LRUCache {

    int capacity;

    int numberElements = 0;
    HashMap myMap;
    LinkedList<Object> myList;

    /**
     * constructor which will take the capacity(int) of the cache as its parameter
     *
     * */
    public LRUCache(int cap){

        this.capacity = cap;
        myMap = new HashMap(this.capacity);
        myList = new LinkedList<>();

    }

    /**
     * Return the value (would always be positive)
     * of the key if the key exists in the cache, otherwise return -1
     * */
    public int get(int key){
        if(myMap.containsKey(key)){
            int theKey = (int)myMap.get(key);
            if(theKey < 0){
                System.out.println("there is a problem");
                theKey *= -1;
            }
            return theKey;
        }
        return -1;
    }

    /**
     * Set the value of the key,
     * if the key does not exist in the cache.
     * When the cache reached its capacity,
     * it should invalidate the least recently used
     * item before inserting a new item
     * */
    public void set(int key, int value){

        System.out.println();
        System.out.println("linked list: " + myList.toString());
        if(key < 0 || value < 0){
            return;
        }
        this.numberElements ++;
        if(!myMap.containsKey(key)){
            myMap.put(key, value);
            myList.add(myMap.get(key));
            if (this.numberElements > this.capacity) {
                Object toRemove = myList.remove();
                System.out.println("no key removing: " + toRemove.toString());
                myMap.remove(toRemove);
            }
        }
        else {
            myList.add(myMap.get(key));
            if (this.numberElements > this.capacity) {
                Object toRemove = myList.remove();
                System.out.println("contain key removing: " + toRemove.toString());
                myMap.remove(toRemove);
            }
            myMap.put(key, value);
        }
    }

    /**
     * printing statistic for isualisatiz
     * */
    public void printStats(){
//        System.out.println("Cache size: " + myList.size() + " Capacity: "
//        + this.capacity + " myMap size: " + myMap.size());
    }

}
