import java.io.FileNotFoundException;
import java.util.Scanner;  // Import the Scanner class
import java.io.File;
/**
 * Madeline Tjoa
 * A15394053
 * */
/**
 * Testing out the hash function on filters.
 * */
public class dictionary{

    public static void main(String args[]) {
            // use a scanner that reads in
            // while has nextline()
        HashTable myHT = new HashTable(10, "./src/hello.txt");

//        try {
//            Scanner myObj = new Scanner(new File("/Users/
//            madeline/Documents/GitHub/dsc30-pa8/src/.txt"));
//            //have an arraylist to read the input file that has all
//            the words and insert all the words to the hash table
//            while(myObj.hasNext()){
//                myHT.insert(myObj.nextLine());
//            }
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }


    }
}
