/**
 * Madeline Tjoa
 * A15394053
 * */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.LinkedList;

/**
 *
 * Hash sort uses a hash function to make
 * a hash table
 *
 * */
public class HashSort {

    protected class HashTable {

        static final double LOAD_FACTOR = (double)2/(double)3;
        static final int NUMBITS = 8;
        public static final int CAPACITY_INCREASE = 2;

        //You will need a HashTable of LinkedLists.
        LinkedList[] myHashTable;

        //Number of element stored in the hash table
        private int nelems;
        //Number of times that the table has been expanded
        private int expand;
        //Number of collisions since last expansion
        private int collision;
        // FilePath for the file to write statistics upon every rehash
        private String statsFileName;

        //Boolean to decide whether to write statistics to file or not after rehashing
        private boolean printStats = false;

        private int min;
        private  int max;


        //You are allowed to add more :)

        /**
         * The constructor that creates a hash table of a given size.
         *
         * If a user uses this constructor,
         * printStats should be set to false and do not use printTable()
         * to print the stats before each resizing.
         *
         * @param size the size of the newly made HashTable
         * */
        public HashTable(int size, int min, int max) {

            this.myHashTable = new LinkedList[size];
            for(int i = 0; i < size; i++){
                myHashTable[i] = new LinkedList();
            }

            this.printStats = false;
            this.nelems = 0;
            this.expand = 0;
            this.collision = 0;
            this.min = min;
            this.max = max;

        }

        /**
         * The constructor that creates a hash table of a given size.
         *
         * If a user uses this constructor,
         * printStats should be set to true
         * and you should use printStatistics() to print the stats
         * to given file before each resizing.
         *
         * @param size the size of the hash Table
         * @param fileName the file that we will store the statistics into
         * */
        public HashTable(int size, String fileName){

            this.myHashTable = new LinkedList[size];
            for(int i = 0; i < size; i++){
                myHashTable[i] = new LinkedList();
            }

            this.printStats = true;
            this.statsFileName = fileName;
            this.nelems = 0;
            this.expand = 0;
            this.collision = 0;
            // Set printStats to true and statsFileName to fileName
        }

        /**
         * Inserts a value into the hash table.
         * Return true if value is successfully inserted,
         * false if it can’t be inserted
         * (a value can’t be inserted if it already exists in the hash table).
         *
         * Throw a NullPointerException if a null value is passed.
         *
         * @param value the value that is going to be inserted
         * @return boolean on whether the insertion was successful
         * */
        public boolean insert(int value) {

//            if(value < null){
//                throw new NullPointerException("String value in insert is a null pointer");
//            }

            int theIndex = hash(value);

            //check if the value already exists in the hash table
            if(lookup(value) == true){
                // hash table contains value
                System.out.println("value already exists");
                return false;
            }
            else{

                // if not in linkedList then add it to the LinkedList at theKey
                if(myHashTable[theIndex].size() != 0){
                    collision ++;
                }
                // System.out.println("added " + nelems);
                myHashTable[theIndex].add(value); //add value to the linkedList in theIndex
                this.nelems ++; //add the number of elements

                //make sure that it is within the load factor
                if(getLoadFactor() > LOAD_FACTOR){
                    rehash();
                }
                return true;
            }
        }

        /**
         * Use the hash table to find value and delete it from the hash table.
         * Return true if the value is successfully deleted,
         * false if it can’t be deleted
         * (a value can’t be deleted if it does not exist in the hash table).
         * Throw a NullPointerException if a null value is passed.
         *
         * @param value value that will be deleted
         * @boolean whether the delete method was succesfully removed.
         * */
        public boolean delete(int value) {

//            if(value == null){
//                throw new NullPointerException("String value in delete is a null");
//            }

            if(lookup(value) == false){
                return false;
            }

            int valueLocation = hashVal(value);

            myHashTable[valueLocation].remove(value);

            this.nelems --;

            return true;
        }

        /**
         * Use the hash table to find value in the hash table.
         * Return true if the hash table contains the value,
         * false otherwise.
         * Throw a NullPointerException if a null value is passed.
         *
         * @param value
         * @return boolean if the deletion was successful
         * */
        public boolean lookup(int value) {
//            if(value == null){
//                throw new NullPointerException( "value submitted
//                into function lookup() was null");
//            }

            for(int i = 0; i < myHashTable.length; i++){
                for(int j = 0; j< myHashTable[i].size(); j++){
                    if(myHashTable[i].get(j).equals(value)){
                        return true;
                    }
                }
            }
            return false;
        }

        /**
         * Print out the hash table using format specified below.
         *
         * The number of times you had to expand the table.
         * The load factor in the table (before resizing), trimmed to 2 decimal places.
         * The number of insertions that encountered a collision (before resizing).
         * The length of the longest known collision chain (before resizing).
         *
         * Example:
         * 1 resizes, load factor 0.67, 1 collisions, 2 longest chain
         * 2 resizes, load factor 0.67, 7 collisions, 2 longest chain
         * 3 resizes, load factor 0.75, 55 collisions, 6 longest chain
         * 4 resizes, load factor 0.68, 221 collisions, 14 longest chain
         * */
        public void printTable() {
            //for the list size you will be printing out the nodes
            for(int i = 0; i < myHashTable.length; i++){
                System.out.print(i + ": ");
                for(int j = 0; j< myHashTable[i].size(); j++){
                    System.out.print(myHashTable[i].get(j) + ", ");
                }
                System.out.println();
            }
            //TODO
        }

        /**
         * Return the number of elements currently stored in the hash table
         * @return the number of elments
         * */
        public int getSize() {

            return this.nelems;
        }

        /**
         * Return the hash value of the given string.
         * @param str
         * @return the hashed value.
         * */
        private int hashVal(int str) {

            return hash(str);

        }

        /**
         * Double the size of hash table and rehash all the entries.
         * */
        private void rehash() {
            System.out.println("rehashing");
            expand ++;
            if(printStats == true){
                printStatistics();
            }
            collision = 0;

            int newArraySize = myHashTable.length * CAPACITY_INCREASE;

            LinkedList[] newHashTable = new LinkedList[newArraySize];

            for(int i = 0; i < newHashTable.length; i++){
                newHashTable[i] = new LinkedList();
            }

            //add all the elements to my new hash table

            for(int i = 0; i < myHashTable.length; i++){ //loop through each hash index


                while(!myHashTable[i].isEmpty()){ // iterate through linked list

                    int value = (int)myHashTable[i].get(0); // grab the value
                    int newHashLocation = hash(value);

                    // add value in newHashLocationIndex
                    newHashTable[newHashLocation].add(value);

                    myHashTable[i].remove();
                }
            }

            myHashTable = newHashTable;

        }

        /**
         * Print statistics of your hash table, see details later in 2.3
         * */
        private void printStatistics() {

            //TODO
            int longestChain = 0;
            for(int i = 0; i < myHashTable.length; i++){
                if(myHashTable[i].size()> longestChain){
                    longestChain = myHashTable[i].size();
                }
            }

            try {
                DecimalFormat df = new DecimalFormat("#.##");
                PrintWriter pw = new PrintWriter
                        (new FileOutputStream(new File(statsFileName),true));
                pw.println(expand + " resizes, " +
                        "load factor " + df.format(getLoadFactor()) +
                        ", " + collision + " collisions, "
                        + longestChain + " longest chain");
                pw.close();
            }
            catch (IOException e) { // If the given file doesn’t exist
                System.out.println("File Not found!");
            }


        }

        /**
         * temporary function to calculate what my
         * key is going to be given a string
         * (determines where the key will be placed)
         * @param string string that key will be found
         * @return int index of the string
         * */
        public int calculateKey(String string){
            return string.length()%this.getSize();
        }

        /**
         * calculation for the load factor.
         *
         * @return double value of the load factor
         * */
        public double getLoadFactor(){
            return (double)this.nelems/(double)myHashTable.length;
        }

        /**
         * My hashStringCRC, also called "modified CRC"
         *
         * Hash a string using the modified CRC method.  The basic idea of
         * 	 * this function is that the hash value is rotated left by 5 bits and
         * 	 * then the next character is exclusive-or'ed in to the hash value.
         * 	 * The implementation is complicated by the lack of a rotate operation
         * 	 * in C++.
         * 	 *
         * 	 * This hash function does not work well with table sizes that are a
         * 	 * power of two.
         *
         * @param value the value thats going to be hashed
         * @param min the size of the hashtable
         *
         * @return int index returned by hash function
         * */
        public int hash(int i) {
            return (int) i/10;
        }
    }

    /**
     * sorts the stuff
     *
     * @param arr the array to sort
     * @param min smallest element in the list
     * @param max biggest element in the list
     * */
    public static int[] sort(int[] arr, int min, int max){


        int n = arr.length;
        int range = max - min + 1;
        int bucketSize = (range + n - 1) / n;

        HashTable myTable = new HashSort(). new HashTable(arr.length, min, max);

        for(int i = 0; i < n; i++){

            myTable.insert(arr[i]);

        }

        System.out.println("help");
        myTable.printTable();
        for(int i = 0; i< n; i ++){

        }
        int[] sorted = new int[n];


        return sorted;
    }




}
