/**
 * The SavingsAccount class extends Account.
 * The minimum amount a customer can keep in a savings account is $100.
 * If the customer deposits at least $5000 initially the bank gives them an additional $100 bonus
 * This account earns interest at a rate specified by the bank.
 * It allows deposits with no fees.
 * Withdrawals are charged $2 per withdrawal.
 * The balance cannot go below $100 through a withdrawal.
 *
 */
public class SavingsAccount extends Account {

    /**
     * Constructor for our banks savings accounts
     *
     * If initial deposit is at least $5000 the customer recieves a $100 bonus
     *
     * @param userid The identifier associated with this Savings Account
     * @param initialDeposit The starting balance for this new Savings Account
     * @throws InsufficientFundsException if initialDeposit is too low
     * */
    public SavingsAccount(String userid, double initialDeposit) throws InsufficientFundsException{
        // TODO

        super(userid, initialDeposit);

        double minDeposit = 5000;
        double minSavings = 100;
        double bonus = 100;
        if(initialDeposit < minSavings){
            throw new InsufficientFundsException();
        }
        if(initialDeposit >= minDeposit){
            this.deposit(bonus);
        }


    }

    /**
     * Returns a string that contains the id, the type of account (Checking or Savings), and balance.
     * For example, if the user id is "ghosh", account type is savings account, and balance is "120.30",
     * the string returned will be as follows (identical punctuation and spaces):
     * ID: ghosh, Type: Savings, Balance: 120.30
     * @return the string that represents this saving account
     */
    public String toString() {
        String id = "";
        double balance = 0.0;

        // TODO: set both local variables to proper value
        id = this.getId();
        balance = this.getBalance();

        return "ID: " + id + ", Type: Savings, Balance: " + balance;
    }

    /**
     * Implements abstract withdraw method.
     * Savings accounts at our bank charge a WITHDRAWAL_FEE.
     * Rejects withdrawal if the withdrawal would put the account bellow the minimum balance and throws an exception.
     *
     * @param amount The amount the customer wishes to redeem from the account.
     * @throws InsufficientFundsException if withdrawal would put account under MINIMUM_BALANCE with a message
     *                                      indicating the maximum amount they could withdraw.
     * @return The balance left in the account
     */
    public double withdraw(double amount) throws InsufficientFundsException {
        // TODO
        int minimumAmt = 100;
        int WITHDRAWAL_FEE = 2;
        double totalWithdrew = amount + WITHDRAWAL_FEE;
        double MAX_WITHDRAW = this.getBalance() - minimumAmt - WITHDRAWAL_FEE;

        if(MAX_WITHDRAW > amount){
            this.deposit(-totalWithdrew);
            return this.getBalance();
        }
        else{
            throw new InsufficientFundsException("THE MAXIMUM AMOUNT THE USER: " + this.getId() +
                    " CAN WITHDRAW FROM THEIR SAVINGS ACCOUNT IS " + (int)MAX_WITHDRAW);
        }
    }

    /**
     * Method that the bank will use to add an interest payment to the savings account.
     *
     * NewBalance = OldBalance + OldBalance*InterestRate
     * ie. If OldBalance was $1000.00 and InterestRate = 2%
     *        NewBalance would be $1020.00
     *
     * @param rate the interest rate in percent. For example 2% => rate is 2.0
     * @return The update balance in the account*/
    public double addInterest(double rate){
        // TODO
        double PERCENTAGE = 100;
        double INTEREST_RATE = this.getBalance() * (rate/PERCENTAGE);
        this.deposit(INTEREST_RATE);

        return this.getBalance();
    }
}
