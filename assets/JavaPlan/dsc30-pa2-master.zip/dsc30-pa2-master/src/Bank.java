import java.util.ArrayList;

/**
 * The Bank class acts as the interface between a user and their money.
 * The Bank consists of an ArrayList of accounts and a interest rate for savings accounts.
 * Through this class users can create accounts, deposit to accounts,
 * withdraw from accounts, and transfer between accounts.
 */
public class Bank {
    private ArrayList<Account> accounts; // Structure holding all accounts.
    private double savingsInterestRate; // The interest rate given to savings account holders as a percent

    /**
     * Default constructor creates an empty accounts Array List and set initial interest rate to 0%
     */
    public Bank() {
        // TODO
        this.accounts = new ArrayList<>();
        this.savingsInterestRate = 0;
    }

    /**
     * Sets the savings interest rate
     * @param rate The rate which will be the new savings interest rate
     */
    public void setSavingsInterest(double rate) {
        // TODO
        this.savingsInterestRate = rate;
    }

    /**
     * Returns the number of checking accounts this bank has
     * @return the number of checking accounts in this bank
     */
    public int getNumberOfCheckingAccounts() {
        // TODO
        int numberOfAcc = 0;
        for(Object i : accounts){
            if(i instanceof CheckingAccount){
                numberOfAcc ++;
            }
        }
        return numberOfAcc;
    }

    /**
     * Returns the number of savings accounts this bank has
     * @return the number of savings accounts in this bank
     */
    public int getNumberOfSavingsAccounts() {
        // TODO
        int numberOfAcc = 0;
        for(Object i : accounts){
            if(i instanceof SavingsAccount){
                numberOfAcc ++;
            }
        }
        return numberOfAcc;
    }

    /**
     * Helper method to get the checking account associated with accountID
     *
     * @param accountID the id of the account to obtain
     * @return If there exists an checking account with accountID return it. Otherwise return null
     */
    private Account getCheckingAccount(String accountID) {
        //
        try {
            for (Object i : accounts) {
                if (i instanceof CheckingAccount) {
                    if (((CheckingAccount) i).getId() == accountID) {
                        return (Account)i;
                    }
                }
            }
            return null;
        }
        catch(Exception e){
            System.out.println("Exception "+ e + " in getCheckingAccount");
            return null;
        }
    }

    /**
     * Helper method to get the savings account associated with accountID
     *
     * @param accountID the id of the account to obtain
     * @return If there exists an savings account with accountID return it. Otherwise return null
     */
    private Account getSavingsAccount(String accountID) {
        // TODO
        try {
            for (Object i : accounts) {
                if (i instanceof SavingsAccount) {
                    if (((SavingsAccount) i).getId() == accountID) {
                        //System.out.println("found Savings Account" + (SavingsAccount)i + "i: " + i);
                        return (Account)i;
                    }
                }
            }
            return null;
        }
        catch (Exception e){
            System.out.println("Exception " + e + " in getSavingsAccount");
            return null;
        }
    }

    /**
     * Creates a checking account with the given accountID and returns true or false depending on success.
     * You also need to print the proper message in each case, check write up for more details.
     *
     * The accountID must not already be taken and the initialDeposit must be greater than $0
     *
     * @param accountID The id the user wants associated to this new account.
     * @param initialDeposit The starting balance of the new account in dollars
     * @return True if account created successfully. False if not.
     */
    public boolean createCheckingAccount(String accountID, double initialDeposit) {
        String successMSG = "Successully created checking account for " + accountID  + "";
        String failMSG = accountID + " ALREADY HAD A CHECKING ACCOUNT!";
        String minimumMSG = "THE MINIMUM INITIAL DEPOSIT FOR A CHECKING ACCOUNT WAS NOT MET!";
        double minimumAmount = 0.01;
        // TODO
        try {
            if(initialDeposit < minimumAmount){
                System.out.println(minimumMSG);
                return false;
            }
            if(getCheckingAccount(accountID) == null) {
                CheckingAccount temp = new CheckingAccount(accountID, initialDeposit);
                System.out.println(successMSG);
                accounts.add(temp);
                return true;
            }
            else{
                System.out.println(failMSG);
            }
        }
        catch (Exception e){

        }
        return false;
    }

    /**
     * Creates a savings account with the given accountID and returns true or false depending on success.
     * You also need to print the proper message in each case, check write up for more details.
     *
     * The accountID must not already be taken and the initialDeposit must be greater than $100
     *
     * @param accountID The id the user wants associated to this new account.
     * @param initialDeposit The starting balance of the new account in dollars
     * @return True if account created successfully. False if not.
     */
    public boolean createSavingsAccount(String accountID, double initialDeposit) {
        String successMSG = "Successully created savings account for " + accountID  + "";
        String failMSG = accountID + " ALREADY HAD A SAVINGS ACCOUNT!";
        String minimumMSG = "THE MINIMUM INITIAL DEPOSIT FOR A CHECKING ACCOUNT WAS NOT MET!";

        // TODO
        int minimumAmount = 100;
        // TODO
        try {
            if(initialDeposit < minimumAmount){
                System.out.println(minimumMSG);
                return false;
            }
            if(getSavingsAccount(accountID) == null) {
                SavingsAccount temp = new SavingsAccount(accountID, initialDeposit);
                System.out.println(successMSG);
                accounts.add(temp);
                return true;
            }
            else{
                System.out.println(failMSG);
            }
        }
        catch (Exception e){

        }
        return false;
    }

    /**
     * Helper method to get the account and print proper messages if no account is found.
     *
     * @param accountID the given accountID
     * @param isChecking true if is checking account, false otherwise
     * @return the proper account
     */
    public Account getAccount(String accountID, boolean isChecking) {
        String noCheckingMSG = accountID + " DOES NOT HAVE A CHECKING ACCOUNT!";
        String noSavingsMSG = accountID + " DOES NOT HAVE A SAVINGS ACCOUNT!";

        // TODO
        if(isChecking == true && getCheckingAccount(accountID) == null){
            System.out.println(noCheckingMSG);
        }
        else if(isChecking == true && getCheckingAccount(accountID) != null){
            System.out.println("Retreiving account:" + getCheckingAccount(accountID));
            return getCheckingAccount(accountID);
        }
        if(isChecking == false && getSavingsAccount(accountID) == null){
            System.out.println(noSavingsMSG);
        }
        else if(isChecking == false){
            System.out.println("Retreiving account:" + getSavingsAccount(accountID));
            return getSavingsAccount(accountID);
        }
        return null;
    }

    /**
     * Adds money to the account associated with accountID
     *
     * @param isChecking true if deposit to checking, false if to savings
     * @param accountID the id of the account to add money too
     * @param amount the amount of dollars to add to the account
     * @return The new balance of the account after deposit. Null if no account exists with accountID
     */
    public Double deposit(boolean isChecking, String accountID, double amount)  {
        // TODO
        try {
            if (isChecking == true) {

                getCheckingAccount(accountID).deposit(amount);
                return getCheckingAccount(accountID).getBalance();

            } else {
                getSavingsAccount(accountID).deposit(amount);
                return getSavingsAccount(accountID).getBalance();
            }
        }
        catch(Exception e ){
            return null;
        }
    }

    /**
     * Removes money from the account associated with accountID
     *
     * @param isChecking true if withdraw from checking, false if from savings
     * @param accountID the id of the account to take money from
     * @param amount the amount of dollars to add to the account
     * @return The new balance of the account after withdrawal. Null if no account exists with accountID
     */
    public Double withdraw(boolean isChecking, String accountID, double amount) {

        // TODO
        try {
            if (isChecking == true) {
                getCheckingAccount(accountID).withdraw(amount);
                return getCheckingAccount(accountID).getBalance();

            } else{
                getSavingsAccount(accountID).withdraw(amount);
                return getSavingsAccount(accountID).getBalance();
            }
        }
        catch(Exception e){
            return null;
        }
    }

    /**
     * Moves money from an account to another account via "online" transfer. No check fees are charged.
     *
     * If either account does not exist the transfer will fail.
     * If the fromAccount does not have enough funds or rejects the withdrawal for any other reason the transfer fails.
     *
     * @param fromAccountID the id of the account to take money from
     * @param isFromChecking true if transfer from checking, false if from savings
     * @param toAccountID the id of the account to put money in
     * @param isToChecking true if transfer to checking, false if to savings
     * @param amount the amount of dollars to add to the account
     * @return Whether or not the transfer succeeded.
     */
    public boolean onlineTransfer(String fromAccountID, boolean isFromChecking, String toAccountID,
                                  boolean isToChecking, double amount) {
        // TODO
        try{
            if(isFromChecking == true && getCheckingAccount(fromAccountID) == null){
                System.out.println(fromAccountID + " DOES NOT HAVE A CHECKING ACCOUNT!");
                return false;
            }
            if(isFromChecking == false && getSavingsAccount(fromAccountID) == null){
                System.out.println(fromAccountID + " DOES NOT HAVE A SAVINGS ACCOUNT!");
                return false;
            }
            if(isToChecking == true && getCheckingAccount(toAccountID) == null){
                System.out.println(toAccountID + " DOES NOT HAVE A CHECKING ACCOUNT!");
                return false;
            }
            if(isToChecking == false && getSavingsAccount(toAccountID) == null){
                System.out.println(toAccountID + " DOES NOT HAVE A SAVINGS ACCOUNT!");
                return false;
            }
            System.out.println("about to withdraw " + amount + " from account with " + getAccount(fromAccountID,isFromChecking).getBalance());
            getAccount(fromAccountID, isFromChecking).withdraw(amount);
            System.out.println("about to deposit");
            deposit(isToChecking, toAccountID, amount);
            return true;
        }
        catch(Exception e){
            return false;
        }
    }

    /**
     * Moves money from an account to another account using a "check."
     *
     * If the from account is not a checking account the transfer will fail.
     * If either account does not exist the transfer will fail.
     * If the fromAccount does not have enough funds or rejects the withdrawal for any other reason the transfer fails.
     *
     * @param fromAccountID the id of the account to take money from
     * @param toAccountID the id of the account to put money in
     * @param amount the amount of dollars to add to the account
     * @return Whether or not the transfer succeeded.
     */
    public boolean checkTransfer(String fromAccountID,boolean isFromChecking, String toAccountID,
                                 boolean isToChecking, double amount) {
        String shouldUseCheckingMSG = fromAccountID + " SHOULD USE A CHECKING ACCOUNT!";
        String noCheckingAccount = fromAccountID + " DOES NOT HAVE A CHECKING ACCOUNT!";
        String doesnothaveca = toAccountID + " DOES NOT HAVE A CHECKING ACCOUNT!";
        String doesnothaveSavings = toAccountID + " DOES NOT HAVE A SAVINGS ACCOUNT!";
        // TODO
        if(getCheckingAccount(fromAccountID) == null){
            System.out.println(shouldUseCheckingMSG);
            return false;
        }
        if(isFromChecking == false){
            System.out.println(shouldUseCheckingMSG);
            return false;
        }
        if(isFromChecking== true && getCheckingAccount(fromAccountID) == null){
            System.out.println(noCheckingAccount);
            return false;
        }
        if(isToChecking == true && getCheckingAccount(toAccountID) == null){
            System.out.println(doesnothaveca);
            return false;
        }
        if(isToChecking == false && getSavingsAccount(toAccountID) == null){
            System.out.println(doesnothaveSavings);
            return false;
        }

        CheckingAccount checking = (CheckingAccount)(getAccount(fromAccountID, isFromChecking));
        try {
            checking.withdrawUsingCheck(amount);
        } catch (InsufficientFundsException e) {
            return false;
            // System.out.println("theres a problem cap");
            //e.printStackTrace();
        }
        getAccount(toAccountID, isToChecking).deposit(amount);
        return true;
    }

    /**
     * Adds interest to every savings account.
     */
    public void addInterest() {
        // TODO
        for(Object i : accounts){
            if (i instanceof SavingsAccount){
                ((SavingsAccount) i).addInterest(this.savingsInterestRate);
            }
        }
    }

    /**
     * First, if accountID has a checking account, print its information. Then, if accountID has a savings account,
     * print its information. Check write up for more details.
     *
     * @param accountID the id of the account to obtain
     */
    public void printAccount(String accountID) {
        // TODO
        if(getCheckingAccount(accountID) != null){
            System.out.println(getCheckingAccount(accountID));
        }
        if(getSavingsAccount(accountID) != null){
            System.out.println(getSavingsAccount(accountID));
        }
    }

}
