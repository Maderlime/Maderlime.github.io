/**
 *  TODO: add class header
 */
public class SunshineMarket {
    // Customer
    private static int[] customers1 = {3, 7, 20};
    private static int[] customers2 = {1, 3, 5, 4, 16, 8};
    private static int[] customers3 = {1, 1, 2, 3, 5, 7};
    
    private static QueueADT customersQueue;
    private static QueueADT[] registers;
    
    /**
     * This is the program entry where we will run our simulation
     *
     * @param args commandline arguments
     */
    public static void main(String[] args) {
        QueueADT a = new CircularArrayQueue();
        String answer = timeInfo(customers1, 3);
        System.out.println(answer);
        // TODO: test timeInfo()
    }
    
    /**
     * Returns a string that contains information about total time
     * for checking out all customers and register idle time.
     * @param customers the customer queue
     * @param numberOfRegisters number of registers opened
     * @return a string that contains information about total time
     *         for checking out all customers and register idle time.
     */
    public static String timeInfo(int[] customers, int numberOfRegisters) {
        int totalTime = 0;
        int registersIdleTime = 0;


        registers = new CircularArrayQueue[numberOfRegisters];

        for(int i = 0; i< numberOfRegisters; i++){
            registers[i] = new CircularArrayQueue();
        }

        customersQueue = new CircularArrayQueue();

        //made my little customer queue
        for(int i = 0; i<customers.length; i++){
            customersQueue.add(customers[i]);
        }


        //while market is not empty
        while(!marketIsEmpty()) {
            //start removing and counting
            while(!customersQueue.isEmpty() && findFirstEmptyRegister() != null) {
                QueueADT thisRegister = findFirstEmptyRegister();

                for (int e = 0; e < customersQueue.peek(); e++) {
                    thisRegister.add(1);
                }
                customersQueue.remove();
            }

            for (int i = 0; i < numberOfRegisters; i++) {
                //System.out.println("Queue: " + registers[i].viewQueue() + "  i: " + i);
                if (registers[i].isEmpty()) {
                    registersIdleTime++;
                }
                else {
                    registers[i].remove();
                }
            }
            totalTime++;
        }
        
        return "With " + numberOfRegisters +
        " lines, the total time for checking out all customers was "
        + totalTime + " time units, and registers were idle for a total of "
        + registersIdleTime + " time units.\n";
    }
    
    /**
     * Helper method to find the first empty register. Return null if all registers are not empty.
     * @return the first empty register
     */
    private static QueueADT findFirstEmptyRegister() {
        //ind your first empty queue in the array of queues and add customer if customer is not empty
        // TODO
        for(int i = 0; i< registers.length; i++){
            if(registers[i].isEmpty()){
                return registers[i];
            }
        }
        return null;
    }
    
    /**
     * Helper method to determine if the market is empty
     *
     * @return true if the whole market is empty
     */
    private static boolean marketIsEmpty() {
        // TODO
        if(customersQueue.isEmpty() == true){
                for(int i = 0; i< registers.length; i++){
                    if(!registers[i].isEmpty()){
                        return false;
                    }
                }
                return true;
        }
        //check if register is empty and line is empty
        return false;
    }
}
