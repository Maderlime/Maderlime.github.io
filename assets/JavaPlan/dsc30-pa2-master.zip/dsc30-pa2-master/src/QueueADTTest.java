import java.util.NoSuchElementException;

import static org.junit.Assert.*;

public class QueueADTTest {
    QueueADT a;


    @org.junit.Before
    public void setUp() throws Exception {
        a = new CircularArrayQueue();

    }

    @org.junit.Test
    public void add(){
        a.add(2);
        assertEquals(2,a.peek());
        assertEquals(1, a.size());
        a.add(3);
        a.add(4);
        a.add(5);
        assertEquals(2,a.peek());
        a.add(4);
        a.add(5);
        assertEquals(6, a.size());

    }
    @org.junit.Test(expected = NoSuchElementException.class)
    public void isEmpty(){
        QueueADT p = new CircularArrayQueue();
        p.add(1);
        p.add(1);
        p.add(1);
        p.add(1);
        p.add(1);
        p.add(1);

        assertEquals(false, p.isEmpty());
        p.remove();
        p.remove();
        p.remove();
        p.remove();
        p.remove();
        p.remove();
        assertEquals(true, p.isEmpty());

        p.remove();

        p.add(2);
        assertEquals(false, p.isEmpty());

    }

    @org.junit.Test(expected = NoSuchElementException.class)
    public void peek()throws NoSuchElementException{
        QueueADT p = new CircularArrayQueue();

        p.peek();

        p.add(1);
        p.add(2);
        p.add(3);
        p.add(4);
        assertEquals(1, p.peek());

        p.remove();
        assertEquals(2, p.peek());
    }

    @org.junit.Test(expected = NoSuchElementException.class)
    public void remove() throws NoSuchElementException{
        a.add(2);
        a.remove();
        assertTrue(a.isEmpty());
        a.add(3);
        assertEquals(3,a.remove());

        CircularArrayQueue queue = new CircularArrayQueue();
        queue.add(5);
        queue.remove();
        queue.remove();

        QueueADT p = new CircularArrayQueue();
        p.add(1);
        p.add(1);
        p.remove();
        p.remove();
        p.remove();

    }

    @org.junit.Test
    public void clear(){

        QueueADT p = new CircularArrayQueue();
        p.add(1);
        p.clear();
        assertEquals(0, p.size());

        QueueADT e = new CircularArrayQueue();
        e.add(4);
        e.add(4);
        e.add(4);
        e.add(4);
        e.clear();
        e.add(5);
        assertEquals(5, e.peek());

        QueueADT f = new CircularArrayQueue();
        f.add(4);
        f.add(4);
        f.clear();
        assertEquals(true, f.isEmpty());


    }

    @org.junit.Test
    public void size(){
        QueueADT e = new CircularArrayQueue();
        e.add(4);
        e.add(4);
        e.add(4);
        e.add(4);
        assertEquals(4, e.size());

        e.remove();
        e.remove();
        e.remove();
        e.remove();
        assertEquals(0, e.size());

        e.clear();
        assertEquals(0, e.size());



    }
}