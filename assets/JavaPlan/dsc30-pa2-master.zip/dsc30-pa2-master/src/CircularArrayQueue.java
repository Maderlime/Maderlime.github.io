import java.util.NoSuchElementException;

public class CircularArrayQueue implements QueueADT {
    private static final int DEFAULT_SIZE = 5; // Example for declaring magic numbers
    private static final int GROWTH_FACTOR = 2; // Example for declaring magic numbers

    private int[] circularArray;
    private int length;
    private int head;
    private int tail;

    private int size;


    /**
     * Creates a new queue with a default initial capacity 5
     *
     * @param
     * @return
     * @throws
     * **/
    public CircularArrayQueue() {
        circularArray = new int[DEFAULT_SIZE];
        length = DEFAULT_SIZE;
    }

    /**
     * creates new queue with specific capacity (if <1 capacity is 1)
     *
     * @param capacity: int determines size
     * */
    public CircularArrayQueue(int capacity) {
        if(capacity <= 1){
            capacity = 1;
        }
        circularArray = new int[capacity];
        length = capacity;
    }

    public static void main(String[] args) {

    }

    /**
     * add new element to back of queue
     *
     * @param elem is the element we want to implement
     * */
    public void add(int elem) {
        //System.out.println("adding " + elem + "...");
        if(!hasSpace()){
            //System.out.println("resizing...");
            resize();
        }
        circularArray[tail] = elem;
        size ++;
        tail = (tail + 1) % length;
    }

    /**
     * Resize array
     *
     * */
    private void resize() {
        // TODO
        //System.out.println("resizing...");
        int newLength = length * GROWTH_FACTOR;
        int[] resizedArray = new int[newLength];
        for(int i = 0; i < circularArray.length; i++){
            resizedArray[i] = circularArray[i];
        }
        if(head >= tail){
            int numEnd = (length - head);
            for(int i = newLength - numEnd; i < newLength; i++){
                resizedArray[i] = circularArray[newLength - length - 1];
            }
            head = newLength-numEnd;
        }
        circularArray = resizedArray;
        length = newLength;
    }

    /**
     * Determines if queue is empty
     *
     * @return boolean: true if empty false otherwise
     * */
    public boolean isEmpty() {
        //System.out.println("Checking if empty queue: " + size());
        // TODO
        try {
            if (size() == 0) {
                return true;
            }
        }
        catch(Exception e){
            //System.out.println("got exception:" + e);
            return true;
        }
        return false;
    }

    /**
     * checks if there are empty spaces in the queue
     *
     * @return boolean: true if there is space false if not
     * */
    public boolean hasSpace(){
        //System.out.println("Checking if has Space: " + size());
        // TODO
        try {
            if (size() < length) {
                return true;
            }
        }
        catch(Exception e){
            System.out.println("got exception:" + e);
            return true;
        }
        return false;
    }

    /**
     * Returns the front element of the queue
     *
     * @throws NoSuchElementException if there is no element to see
     * */
    public int peek() throws NoSuchElementException {
        // TODO
            if(isEmpty()){
                throw new NoSuchElementException("Queue is empty");
            }
            return circularArray[head];
    }

    /**
     * returns and removes the front element of the queue
     *
     * @return the removed element
     * @throws NoSuchElementException if there is no element to remove
     *
     * */
    public int remove() throws NoSuchElementException {
        // TODO
        //System.out.println("Removing...");
        if(isEmpty()){
            throw new NoSuchElementException("Queue is empty");
        }
        int removedElem = circularArray[head];
        circularArray[head] = 0;
        head = (head + 1) % length;
        size --;
        return removedElem;
    }


    /**
     * Remove all the elements from a queue
     *
     * */
    public void clear() {
        // TODO
        head = 0;
        tail = 0;
        length = DEFAULT_SIZE;
        size = 0;
    }

    /**
     * gets the size of the queue
     *
     * @return the size of the queue
     * */
    public int size() {
        // TODO
        return size;
    }

//    public String viewQueue(){
//        String arrayTrans = "";
//        for(int i = 0; i< length; i++){
//            arrayTrans = arrayTrans + Integer.toString(circularArray[i]) + ", ";
//        }
//        return arrayTrans;
//    }

}
