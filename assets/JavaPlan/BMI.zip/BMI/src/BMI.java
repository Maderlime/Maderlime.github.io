//madeline tjoa BMI

import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

import java.io.*;
import java.text.*;


public class BMI extends JApplet implements ActionListener{

	//declare our components or fields(global level variable)
		JTextField txtHeight = new JTextField(20);
		JTextField txtWeight = new JTextField(20);
		JTextField txtName = new JTextField(5);
	
		JTextArea txaresult = new JTextArea(
				"Name |  BMI  | 	Total BMI's Calculated" + "\n", 10,30);
	
		JButton btnAdd = new JButton("Calculate BMI");
	
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		double totalCalculation;
		double totalBMI;
		double averageBMI;
		
		
	
	//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			resize(500,300);
			txtName.requestFocus();
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
			txtName.addActionListener(this);
			txtHeight.addActionListener(this);
			txtWeight.addActionListener(this);
			
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			String nameString;
			String outputString;
			
			double rateDouble;
			double hoursDouble;
			double payDouble;
			
			
			
		//2. information	
			try {
			nameString = txtName.getText();
			
			
			hoursDouble = Double.parseDouble(txtHeight.getText());
			rateDouble = Double.parseDouble(txtWeight.getText());
			
			
		//3. Calculate 
			payDouble = calculatePay(hoursDouble, rateDouble);
			
			//totalCalculation = Double.parseDouble(totalCalculation);
			
		//extra: connect to a format cclass	
			//String formattedDataString;
			//NumberFormat fmtCurrency = NumberFormat.getCurrencyInstance();
			DecimalFormat decFor = new DecimalFormat("####.00");
			//formattedDataString = fmtCurrency.format(payDouble);

			String betterNumber = decFor.format(payDouble);
			
			//payDouble = decFor.format(payDouble);
			
					
			
		//4. output in the text Area
			txaresult.append(nameString + "'s BMI: "+ betterNumber + " \n \t Number BMI's calculated:" + totalCalculation + 
										"\n \t Average BMI: " + decFor.format(averageBMI) + "\n --------- \n");
			txtName.setText("");
			txtHeight.setText("");
			txtWeight.setText("");
			txtName.requestFocus();
			}
			catch(NumberFormatException err){
				
				showStatus("please make sure you've entered everything!");
			}
			
		}
		
		public double calculatePay (double theHeight, double theWeight) {
			double thePay = 0;
			double Tallness = theHeight;
			double Heavy = theWeight;
			theWeight = Heavy * .454;
			theHeight = Tallness * .0254 ;
			
			thePay = theWeight / (theHeight* theHeight);
			totalCalculation +=1;
			totalBMI += thePay;
			averageBMI = totalBMI/totalCalculation;
			
			return thePay;
			
		}
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			
			pnlInput.add(new JLabel("Name: "));
				pnlInput.add(txtName);
			pnlInput.add(new JLabel("Height(in inches): "));
				pnlInput.add(txtHeight);
			pnlInput.add(new JLabel("Weight(in pounds): "));
				pnlInput.add(txtWeight);	
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);
			
		}
		
	
	
}
