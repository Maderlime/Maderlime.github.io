import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Inventory {
	private ArrayList<Product> products;
	private int max;
	
	public Inventory() {
		
		
		
	}
	/*
	 * Write method must order which is described as follows: method must order returns an arraylist object of product items that need to be ordered
	 * due to low inventory. Ant inventory product that is below 20
	 * isn quantity needs to be ordered. If no product inventory is below 20 reutrn an empty Arraylist object.
	 * */
	
	public void addNewProduct(String name, double cost, int amount) {
		/* a new product object is constructed with name, cost, and amount
		 * the new product object is added to the Products array such that products is ordered alphabetically by item*/
		String namewa = name;
		double monee = cost;
		int total = amount;
		
		Product hardware = new Product(namewa, monee, total);
				
		products.add(hardware);
		
		System.out.println(products);
	}
	
	public ArrayList<String> mustOrder(){
		/*returns an ArrayList of String objects whose quantity is less than 20 or if no items are below
		 * 20 level returns an empty ArrayList object*/
			ArrayList<String> yelp;
		for(int i = 0; i< products.size(); i++) {
			
			if(products.get(i).getQuantity() < 20) {
				
				yelp.add();

			}
			
		}
	
		
		
	}

	public void displayProducts() {
		
		
	}
}
