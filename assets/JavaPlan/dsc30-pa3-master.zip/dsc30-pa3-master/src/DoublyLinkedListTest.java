/**
 * DoublyLinkedListTest
 *
 * Madeline Tjoa
 * */
import org.junit.Before;

import static org.junit.Assert.*;

public class DoublyLinkedListTest {

    DoublyLinkedList<Integer> myDouble;

    @Before
    public void setup(){
        myDouble = new DoublyLinkedList<Integer>();
        myDouble.add(5);
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);

    }

    @org.junit.Test
    public void add() {
        myDouble.add(9);
        myDouble.add(10);
        myDouble.add(18);
        assertEquals(7, myDouble.size());

        DoublyLinkedList<Character> myDouble3 = new DoublyLinkedList<Character>();
        myDouble3.add('w');
        myDouble3.add('e');
        myDouble3.add('f');
        assertEquals(3, myDouble3.size());

        myDouble3.remove(2);
        myDouble3.add('e');
        assertEquals(3, myDouble3.size());


    }

    @org.junit.Test (expected = IndexOutOfBoundsException.class)
    public void add1() {
        myDouble.add(4,6);
        myDouble.add(3,8);
        System.out.println(myDouble.size());
        assertEquals(6, myDouble.size());

        myDouble.add(20,8);
        assertEquals(7, myDouble.size());

        myDouble.add(-20,8);
        assertEquals(7, myDouble.size());

        myDouble.add(4,6);
        assertEquals(8, myDouble.size());

        DoublyLinkedList<Character> myDouble3 = new DoublyLinkedList<Character>();
        myDouble3.add(1, 'w');
        myDouble3.add(0, 'f');
        myDouble3.add(3, 'f');
        assertEquals(3, myDouble3.size());

    }

    @org.junit.Test (expected = NullPointerException.class)
    public void add2() {
        myDouble.add(4,6);
        assertEquals(5, myDouble.size());


        myDouble.add(3,8);
        System.out.println(myDouble.size());
        assertEquals(6, myDouble.size());


        myDouble.add(4,null);
        System.out.println(myDouble.size());
        assertEquals(7, myDouble.size());

    }

    @org.junit.Test
    public void clear() {
        myDouble.clear();
        assertEquals(0, myDouble.size());
    }

    @org.junit.Test
    public void contains() {
        assertFalse(myDouble.contains(4));
        myDouble.add(4);
       // System.out.println(myDouble.size());
        assertTrue(myDouble.contains(4));
        myDouble.add(66);
        assertFalse(myDouble.contains(15));

    }

    @org.junit.Test
    public void get() {
        System.out.println(myDouble.get(3));
        assertEquals(new Integer(8), myDouble.get(3));

        assertEquals(new Integer(7), myDouble.get(2));

        myDouble.set(2,4);

        assertEquals(new Integer(4), myDouble.get(2));


    }
    @org.junit.Test
    public void isEmpty() {
        myDouble.clear();
        assertTrue(myDouble.isEmpty());

        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);
        assertFalse(myDouble.isEmpty());
        assertEquals(3, myDouble.size());

        myDouble.remove(2);
        assertFalse(myDouble.isEmpty());
    }

    @org.junit.Test(expected = IndexOutOfBoundsException.class)
    public void remove() {
        myDouble.clear();
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);

        myDouble.remove(0);
        myDouble.remove(4);
        myDouble.remove(4);
        myDouble.remove(10);
        myDouble.remove(4);
        myDouble.remove(10);
        myDouble.remove(4);
        myDouble.remove(10);
        myDouble.remove(4);
        myDouble.remove(10);

    }

    @org.junit.Test(expected = IndexOutOfBoundsException.class)
    public void remove2() {
        myDouble.clear();

        myDouble.remove(4);
       // assertEquals(5, myDouble.size());
    }

    @org.junit.Test
    public void remove1() {
        myDouble.clear();
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);

        myDouble.remove(4);
        assertEquals(5, myDouble.size());
    }

    @org.junit.Test
    public void set() {
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);
        myDouble.set(2,5);
        assertEquals(5,myDouble.get(2).intValue());
        myDouble.set(4,6);
        assertEquals(6,myDouble.get(4).intValue());
        myDouble.set(5,0);
        assertEquals(0,myDouble.get(5).intValue());

    }

    @org.junit.Test
    public void size() {
        myDouble.clear();
        myDouble.add(8);
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);
        myDouble.add(8);
        myDouble.add(6);
        myDouble.add(7);
        myDouble.add(8);
        assertEquals(8, myDouble.size());
        myDouble.remove(4);
        myDouble.remove(4);
        myDouble.remove(4);
        myDouble.remove(4);
        assertEquals(4, myDouble.size());
        myDouble.clear();
        assertEquals(0, myDouble.size());

    }

    @org.junit.Test(expected = IndexOutOfBoundsException.class)
    public void splice() {
        myDouble.clear();
        myDouble.add(1);
        myDouble.add(2);
        myDouble.add(3);
        myDouble.add(4);
        myDouble.add(5);
        myDouble.add(6);
        myDouble.add(7);
        DoublyLinkedList<Integer> otherList = new DoublyLinkedList<>();
        otherList.add(0);
        otherList.add(0);
        otherList.add(0);
        myDouble.splice(3, otherList);
//        for(int i = 0; i < myDouble.size(); i++){
//            System.out.println(myDouble.get(i));
//        }
        myDouble.clear();
        myDouble.add(1);
        myDouble.add(2);
        myDouble.add(3);
        myDouble.add(4);
        myDouble.add(5);
        myDouble.add(6);
        myDouble.add(7);
        DoublyLinkedList<Integer> otherList3 = new DoublyLinkedList<>();
        otherList.add(0);
        otherList.add(0);
        otherList.add(0);
        myDouble.splice(7, otherList);
        for(int i = 0; i < myDouble.size(); i++){
            System.out.println(myDouble.get(i));
        }

        myDouble.clear();
        myDouble.add(6);
        myDouble.add(7);
        DoublyLinkedList<Integer> otherList2 = new DoublyLinkedList<>();
        otherList.add(0);
        otherList.add(0);
        otherList.add(0);
        myDouble.splice(3, otherList);
        for(int i = 0; i < myDouble.size(); i++){
            System.out.println(myDouble.get(i));
        }

    }

    @org.junit.Test
    public void match() {
        DoublyLinkedList<Character> genome = new DoublyLinkedList<>();
        DoublyLinkedList<Character> guideRNA = new DoublyLinkedList<>();
        genome.add('A');
        genome.add('B');
        genome.add('C');
        genome.add('D');

        guideRNA.add('S');
        guideRNA.add('W');
        guideRNA.add('A');
        guideRNA.add('B');
        guideRNA.add('C');
        guideRNA.add('D');
        guideRNA.add('I');
        guideRNA.add('X');
        assertEquals(2, guideRNA.match(genome)[0]);


        guideRNA.add('S');
        guideRNA.add('W');
        guideRNA.add('A');
        guideRNA.add('B');
        guideRNA.add('C');
        guideRNA.add('D');
        guideRNA.add('I');
        guideRNA.add('X');
        assertEquals(10, guideRNA.match(genome)[1]);

        DoublyLinkedList<Integer> genome2 = new DoublyLinkedList<>();
        DoublyLinkedList<Integer> guideRNA3 = new DoublyLinkedList<>();
        genome2.add(0);
        genome2.add(2);
        genome2.add(3);
        genome2.add(5);
        genome2.add(3);
        genome2.add(0);
        genome2.add(5);


        guideRNA3.add(3);
        guideRNA3.add(5);
        assertEquals(2, genome2.match(guideRNA3)[0]);


    }
}