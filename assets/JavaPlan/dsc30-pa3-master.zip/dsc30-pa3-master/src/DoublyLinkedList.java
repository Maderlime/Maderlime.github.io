/*
 * NAME: TODO First Last
 * PID: TODO Axxxxxxxx
 */

import java.util.AbstractList;

/**
 * Doubly-Linked List Implementation
 *
 * @author Madeline Tjoa
 * @since Spring 2019
 */
public class DoublyLinkedList<T> extends AbstractList<T> {
    private int nelems;
    private Node head;
    private Node tail;

    /**
     * Node for chaining together to create a linked list
     */
    protected class Node {
        T data;
        Node next;
        Node prev;

        /**
         * Constructor to create singleton Node
         */
        private Node(T element) {

            data = element;
            next = null;
            prev = null;
        }

        /**
         * Constructor to create singleton link it between previous and next
         *
         * @param element  Element to add, can be null
         * @param nextNode successor Node, can be null
         * @param prevNode predecessor Node, can be null
         */
        private Node(T element, Node nextNode, Node prevNode) {

            data = element;
            next = nextNode;
            prev = prevNode;
        }

        /**
         * Set the element
         *
         * @param element new element
         */
        public void setElement(T element) {

            this.data = element;
        }

        /**
         * Accessor to get the Nodes Element
         */
        public T getElement() {

            return this.data;
        }

        /**
         * Set the next node in the list
         *
         * @param n new next node
         */
        public void setNext(Node n) {

            this.next = n;
        }

        /**
         * Get the next node in the list
         *
         * @return the successor node
         */
        public Node getNext() {

            return this.next;
        }

        /**
         * Set the previous node in the list
         *
         * @param p new previous node
         */
        public void setPrev(Node p) {

            this.prev = p;
        }


        /**
         * Accessor to get the prev Node in the list
         *
         * @return predecessor node
         */
        public Node getPrev() {

            return this.prev;
        }

        /**
         * Remove this node from the list. 
         * Update previous and next nodes
         */
        public void remove() {
            //set the before node to the previous node
            Node before = this.getPrev();
            //set the after node to the next node
            Node after = this.getNext();

            //set the before and after to the nodes displayed at top.
            before.setNext(after);
            after.setPrev(before);
        }
    }

    /**
     * Creates a new, empty doubly-linked list.
     */
    public DoublyLinkedList() {

        head = new Node(null);
        tail = new Node(null);
        head.setNext(tail);
        tail.setPrev(head);
        nelems = 0;

    }

    /**
     * Add an element to the end of the list
     *
     * @param element data to be added
     * @return whether or not the element was added
     * @throws NullPointerException if data received is null
     */
    @Override
    public boolean add(T element) throws NullPointerException {
        //implementation of adding the new data
        if(element == null){
            throw new NullPointerException();
        }

        //Node that will be added
        Node toAdd = new Node(element);

        //Node that is behind the tail of the DLL
        Node behindTail = tail.getPrev();

        //set the back's previous to our added Node
        tail.setPrev(toAdd);

        //set the node that is before the tail to the added node
        behindTail.setNext(toAdd);

        //set the next and prev for our new Node
        toAdd.setPrev(behindTail);
        toAdd.setNext(tail);

        //add one to the number of elements.
        nelems ++;

        return true;
    }


    /**
     * Adds an element to a certain index in the list, shifting exist elements
     * create room. Does not accept null values.
     *
     * @param index the index that will be viewed
     * @param element the value that is going to be added
     * @throws IndexOutOfBoundsException if the index is not within range
     * @throws NullPointerException if element value is null
     *
     */
    @Override
    public void add(int index, T element)
            throws IndexOutOfBoundsException, NullPointerException {
        //check if the element from parameter is null
        if(element == null){
            throw new NullPointerException();
        }
        //make sure that index passed is within bounds
        if(index>nelems || index < 0){
            throw new IndexOutOfBoundsException();
        }

        //set Nodes that are between the area we are going to add the Node to
        Node backTarget = getNth(index);
        Node behindBack = backTarget.getPrev();

        //the Node that we are going to add
        Node toAdd = new Node(element);


        //reroute all the pointers for the 3 nodes.
        backTarget.setPrev(toAdd);
        behindBack.setNext(toAdd);
        toAdd.setPrev(behindBack);
        toAdd.setNext(backTarget);

        //add to the number of elements
        nelems ++;

    }

    /**
     * Clear the linked list
     */
    @Override
    public void clear() {
        //set the head and tail back to null
        head = new Node(null);
        tail = new Node(null);

        //set up our dummy nodes
        head.setNext(tail);
        tail.setPrev(head);

        //set the number of elements back to 0
        nelems = 0;
    }

    /**
     * Determine if the list contains the data element anywhere in the list.
     *
     * @param element the element that will be check if exists
     * @return boolean whether the element exists
     */
    @Override
    public boolean contains(Object element) {
        //the node that we want to check for
        T data = (T)element;

        //iterate through the Linked list
        Node tempIter = head.getNext();
        for(int i = 0; i< this.size(); i++){

            //if the value is found return true
            if(tempIter.getElement() == data){
                return true;
            }
            //go to the next value in the linked list
            tempIter = tempIter.getNext();
        }

        return false;
    }

    /**
     * Retrieves the element stored with a given index on the list.
     *
     * @param index int the index of the target element we want to find
     * @return element found at index
     */
    @Override
    public T get(int index) throws IndexOutOfBoundsException {
        // get the nth element with the passed index
        Node targetBoo = getNth(index);
        // return the element value
        return targetBoo.getElement();
    }

    /**
     * Helper method to get the Nth node in our list
     *
     * @param index int the index of the target element we want to find
     * @return the location that is found after iterating through a for loop.
     */
    private Node getNth(int index) {
        Node tempIter = head.getNext();
        // iterate through each next for the index amount of times
        for(int i = 0; i< index; i++){
            tempIter = tempIter.getNext();
        }
        return tempIter;
    }

    /**
     * Determine if the list empty
     *
     * @return boolean of whether the node list is empty
     */
    @Override
    public boolean isEmpty() {
        //checks number of elements to determine whether list is empty
        if(nelems == 0){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Remove the element from position index in the list
     *
     * @param index return the index of the list that we want to remove
     * @return the removed element
     * @throws IndexOutOfBoundsException throws when the index is out of bounds of the linked list
     */
    @Override
    public T remove(int index) throws IndexOutOfBoundsException {
        // checks that the index is within bounds
        if(index >= nelems || index < 0){
            throw new IndexOutOfBoundsException();
        }
        // set a node for the element we want to remove and the nodes in front and behind it
        Node removedElem = getNth(index);
        Node backNode = removedElem.getNext();
        Node frontNode = removedElem.getPrev();

        //set the front node and the back node equal to each other
        frontNode.setNext(backNode);
        backNode.setPrev(frontNode);

        //reduce the number of elements counter
        nelems --;

        return removedElem.getElement();
    }

    /**
     * Set the value of an element at a certain index in the list.
     *
     * @param index location of where we will perform the operation
     * @param element the value that we want to replace originalSet with.
     * @return the original value that was in the index
     * @throws IndexOutOfBoundsException  throws when the index is out of bounds of the linked list
     * @throws NullPointerException throws when element is null
     *
     */
    @Override
    public T set(int index, T element)
            throws IndexOutOfBoundsException, NullPointerException {
        // Checks that the index is within bounds
        if(index > nelems || index < 0){
            throw new IndexOutOfBoundsException();
        }
        // checks that the element is not null
        if(element == null){
            throw new NullPointerException();
        }
        // get the Node at the index position
        Node targetSet = getNth(index);

        // get the value of the element
        T originalSet = targetSet.getElement();

        //switch our Node to be equal to the element
        targetSet.setElement(element);

        return originalSet;
    }

    /**
     * Retrieves the amount of elements that are currently on the list.
     *
     * @return the number of elements in the linked list
     */
    @Override
    public int size() {
        return nelems;
    }

    /**
     * Inserts another linked list of the same type into this one
     *
     * @param index
     * @param otherList
     * @throws IndexOutOfBoundsException  throws when the index is out of bounds of the linked list
     */
    public void splice(int index, DoublyLinkedList<T> otherList) throws IndexOutOfBoundsException {
        // Determine if index is valid
        if(index > this.size() || index < 0){
            throw new IndexOutOfBoundsException();
        }
        // Splicing implementation. HINT: remember DoublyLinkedList's  have dummy nodes
//        Node nodeBefore = getNth(index-1);
//        Node nodeAfter = getNth(index);

        //add the other list at the index that parameter passes through
        for(int i = 0; i < otherList.size(); i++){
            // if the index is at the end use the add without parameter
            if(index + i >= this.size()){
                this.add(otherList.get(i));
            }
            //otherwise if it is within the list use add with two parameters
            else {
                this.add((index + i), otherList.get(i));
            }
        }

    }

    /**
     * Determine the starting indices that match the subSequence
     *
     * @param subsequence a doublylinkedlist of the subsequence we want to match
     * @return a list of the indexes of the matched lists.
     */
    public int[] match(DoublyLinkedList<T> subsequence) {

        // A list to hold all the starting indices found
        DoublyLinkedList<Integer> indices = new DoublyLinkedList<>();

        // Add implementation to find the starting indices
        for(int i = 0; i < this.size(); i++){
//            System.out.println("Loop " + i);
            int countMatches = subsequence.size();
            // for all the elements that are in the subsequence count the matches
            for(int j = 0; j < subsequence.size(); j++){
//                System.out.println("my letters: " + subsequence.get(j) + " " + this.get(j+i));
                if(j+i >= this.size()){
                    break;
                }
                if(subsequence.get(j).equals(this.get(j+i))){
                    countMatches --;
                }
            }
            // if the countdown of matches is 0 then found a match
            if(countMatches == 0){
                // System.out.println("found match");
                indices.add(i);
            }
        }

        // Array Conversion
        int[] startingIndices = new int[indices.size()];
        for (int i = 0; i < indices.size(); i++) {
            startingIndices[i] = indices.get(i);
        }
        return startingIndices;
    }

}



