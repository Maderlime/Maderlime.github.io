/*
 * NAME: TODO First Last
 * PID: TODO Axxxxxxxx
 */


/**
 * Gene Splicing CRISPR Simulator
 *
 * @author Madeline Tjoa
 * @since Sprint 2018
 */
public class CRISPR {

    /*Sequences to use/test your CRISPR functions on. Please add more as you test*/
    private static String simpleGenome = "ACATATA";

    private static String sequencedGenome = "AAATTCAAGCGAGGTGATTACAACAAATTTTGCTGATGGTTTAGGCGTA"
            + "CAATCCCCTAAAGAATATAATTAAGAAAATAGCATTCCTTGTCGCCTAGAATTACCTACCGGCGTCCACCATACCTTCG"
            + "ATATTCGCGCCCACTCTCCCATTAGTCGGCACAAGTGGATGTGTTGCGATTGCCCGCTAAGATATTCTAAGGCGTAACG"
            + "CAGATGAATATTCTACAGAGTTGCCGTACGCGTTGAACACTTCACGGATGATAGGAATTTGCGTATAGAGCGGGTCATT"
            + "GAAGGAGATTACACTCGTAGTTAACAACGGGCCCGGCTCTATCAGAACACGAGTGCCTTGAATAACATACTCATCACTA";

    private static String overlappingGuide = "UA";
    private static String guideRNA = "CUAAUGU";
    private static String splicedGene = "CAT";


    /**
     * Program Entry, this simply runs
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        /*Should print out ACATATA (unchanged)*/
        System.out.println(spliceDNA(simpleGenome, overlappingGuide, splicedGene));
    }

    /**
     *  Simulate gene splicing on a genome using CRISPR
     *
     * @param genomeSequence initial DNA encoding
     * @param guideSequence guideRNA encoding
     * @param splicedSequence target insertion gene encoding
     * @return modified genome
     */
    public static String spliceDNA(String genomeSequence, String guideSequence, String splicedSequence) {
        DoublyLinkedList<Character> genome = new DoublyLinkedList<>();
        DoublyLinkedList<Character> guideRNA = new DoublyLinkedList<>();
        DoublyLinkedList<Character> splicedSequenceToLL = new DoublyLinkedList<>();

        populateFromDNA(splicedSequenceToLL, splicedSequence);
        populateFromDNA(genome, genomeSequence);
        populateDNAFromRNA(guideRNA, guideSequence);

        // Splicing algorithm with will add the splicedSequence where appropriate to genome
        int[] genomeMatches = genome.match(guideRNA);

        // System.out.println("genomeMatches: " + genomeMatches.length);
        for(int i = genomeMatches.length - 1; i>= 0; i--){

            //if there is only one genome match complete splice once.
            if(genomeMatches.length == 1){
                genome.splice(genomeMatches[i] + guideSequence.length(),splicedSequenceToLL);
            }
            else if(genomeMatches.length > 1){

                //check if i-1 is within range
                if(i-1 >= 0){
                    // if not, continue
                    if(genomeMatches[i] - genomeMatches[i-1] < guideSequence.length()){
                        //System.out.println("i - 1 >= 0 failed");
                        continue;
                    }
                    // System.out.println("i-1 passed");
                }
                // check if i+1 is within range
                if(i+1 < genomeMatches.length){

                    // if not, continue
                    if(genomeMatches[i+1] - genomeMatches[i] < guideSequence.length()){
                        //System.out.println("i + 1 failed");
                        continue;
                    }
                    genome.splice(genomeMatches[i] + guideSequence.length() ,splicedSequenceToLL);
                }

                // perform regular splicing if i+1 and i-1 are passed
                else{
                    genome.splice(genomeMatches[i] + guideSequence.length(),splicedSequenceToLL);
                }
            }
        }
        return transcribeGeneticCode(genome);
    }

    /**
     * This is a direct encoding of the genetic code from the String to a LinkedList
     * @param dnaList to populate
     * @param dnaString DNA string encoding
     */
    public static void populateFromDNA(DoublyLinkedList<Character> dnaList, String dnaString) {
        // Populate dnaList with the characters in s
        for(int i = 0; i < dnaString.length(); i++){
            dnaList.add(dnaString.charAt(i));
        }
    }

    /**
     * This is an encoding of of the DNA that binds with the RNA
     * Remember that DNA pairs up A-T C-G, and RNA pairs up A-U C-G
     * Thus the guide RNA AUCG would match with the DNA TAGC
     * @param dnaList to populate
     * @param rnaString RNA string encoding
     */
    public static void populateDNAFromRNA(DoublyLinkedList<Character> dnaList, String rnaString) {
        // Populate dnaList with the DNA representation of the RNA Sequence

        // rna values matched
        String rnaPairs = "TGAC";
        String dnaPairs = "ACUG";

        // loop through rna string to translate to dna
        for (int i = 0; i<rnaString.length(); i++){

            //character i want to translate in RNA form
            char targetRNA = rnaString.charAt(i);

            // dna index for wanted character
            int currentDNAIndex = dnaPairs.indexOf(targetRNA);

            //System.out.println(" target RNA: " + targetRNA+ " currentDNAIndex: " + currentDNAIndex + " ");
            dnaList.add(rnaPairs.charAt(currentDNAIndex));

        }
    }

    /**
     * Recreate the original base sequence that was loaded into the list
     * @param geneticSequence list representation of the
     * @return base sequence of the genetic material
     */
    public static String transcribeGeneticCode(DoublyLinkedList<Character> geneticSequence) {

        String s = "";
        for (char c : geneticSequence) {
            s += c;
        }
        return s;
    }

}
