import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class BallBounce extends JApplet implements ActionListener {

	JButton btnStart = new JButton("Start");
	JButton btnStop = new JButton("Stop");
	
	boolean OnorOff = false;
	Timer myTimer = new Timer(100,this);
	
	JPanel pnlPanel = new JPanel();
	JPanel pnlMain = new JPanel();
	JPanel pnlInput = new JPanel();
	JPanel pnlOutput = new JPanel();
	
	DefineBall Circles[] = new DefineBall[3];
	
	public void init() {
		
		DesignInputPanel();
		DesignOutputPanel();
		
		pnlMain.add(pnlInput);
		
		pnlMain.add(pnlOutput);
		
		/*2*/		//TIMER PT2
					pnlMain.add(btnStart);
					pnlMain.add(btnStop);
					
					resize(550,550);
					for (int i = 0; i <3; i++) {
						Circles[i] = new DefineBall();
					}
					for (int j = 0; j<3;j++) {
						int xpos, ypos, xspeed,yspeed;
						xpos = (int)(Math.random()*550);
						ypos = (int)(Math.random()*550);
						xspeed = (int)(Math.random()*2);
						yspeed = (int)(Math.random()*3);
							if(xspeed ==0) {
								   xspeed = 10;}
							else { 
								   xspeed = -10;}
							if(yspeed == 0) {yspeed = 10;}
							else if (yspeed ==1) {yspeed = -10;}
							else {yspeed =0;}
						Circles[j].setCircle(xpos, ypos, xspeed, yspeed, "Red");
					}
			/*end*/	
					setContentPane(pnlMain);
					
					btnStart.addActionListener(this);
					btnStop.addActionListener(this);
					
		
	}
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		Object objSource = event.getSource();
		 if(objSource == btnStart) {
				startTheTimer();
			}
			else if(objSource == btnStop) {
				stopTheTimer();
			}
			
		//put code to move the circle
			if(OnorOff) {
/*3*/		//for loop to change each circle locations				
				for (int k = 0; k<3;k++) {
					Circles[k].xDist += Circles[k].velX;
					Circles[k].yDist += Circles[k].velY;
					for(int u = 0; u<3; u++) {
						if(Circles[u].xDist > pnlMain.getWidth()) {
							Circles[u].velX *=-1;
						}
						else if(Circles[u].xDist < 0) {
							Circles[u].velX *=-1;
						}
						if(Circles[u].yDist > pnlMain.getHeight()) {
							Circles[u].velY *=-1;
						}
						else if(Circles[u].yDist < 0) {
							Circles[u].velY *=-1;
						}
					}
					repaint();
				}
				/*3 end */
				
				//intX += xamount;
				//repaint();
			}
	}
	
	

	public void startTheTimer() {
		myTimer.start();
		OnorOff = true;
	}
	public void stopTheTimer() {
		myTimer.stop();
		OnorOff = false;		
	}
	
	public void paint(Graphics g) {
		super.paint(g);
/*2*/		//paint a circle
		//g.setColor(Color.red);
		//g.fillOval(intX, intY, 50, 50);
		//end
/*3*/
		for(int m=0;m<3;m++) {
			g.setColor(Color.red);
			g.fillOval(Circles[m].xDist, Circles[m].yDist, 50, 50);
		}
		/*3 end*/
		
	}
	
	public void DesignInputPanel() {
		pnlInput.setLayout(new GridLayout(0,2));
		
		
	}
	
	public void DesignOutputPanel() {
		pnlOutput.setLayout(new GridLayout(0,1));
		
		
	}
	
	

}
