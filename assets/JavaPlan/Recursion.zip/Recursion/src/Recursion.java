import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/*
 * write a method that takes a positive number as input and keeps dividing the number by 3 until the result is less than 1.
 *  output the answers as it calculates it
 * 
 * write a method that takes a positive number and outputs that many odd numbers
 * 
 * write a method that determines if one number is the greatest common factor of another.
 * 
 * use recursion for all cases:
 * 
 * */
public class Recursion extends JApplet implements ActionListener {

	JTextArea txaresult = new JTextArea("\n", 30,30);
	
	JTextField txtNumber1 = new JTextField(20);
	
	JTextField txtNumber2 = new JTextField(20);
	
	JButton btnOneNumber = new JButton("One Number");
	
	JButton btnTwoNumber = new JButton("Two Number");
	
	JPanel pnlMain = new JPanel();
	JPanel pnlInput = new JPanel();
	JPanel pnlOutput = new JPanel();
	

	double TheNumber;
	
	double theVictim;
	
	int deathCount = 0;
	
	String boop;
	
	public void init() { 
		
		DesignInputPanel();
		DesignOutputPanel();

		pnlMain.add(pnlInput);	
		pnlMain.add(btnOneNumber);
		pnlMain.add(btnTwoNumber);
		pnlMain.add(pnlOutput);	
		txtNumber1.requestFocus();
		resize(500,400);
	
		setContentPane(pnlMain);
		btnOneNumber.addActionListener(this);
		btnTwoNumber.addActionListener(this);
		
	}

	
	public void actionPerformed(ActionEvent e) {
		try {
			
			Object objSource = e.getSource();
			
			if(objSource == btnOneNumber) {
			
				double TheNumber =Double.parseDouble(txtNumber1.getText());
				
				theVictim = TheNumber;			
				Calculation2(TheNumber);
				
				theVictim = TheNumber;
				Calculation1(TheNumber);
								
				
			}
			if(objSource == btnTwoNumber) {
				
				double TheNumber1 = Double.parseDouble(txtNumber1.getText());
				double TheNumber2 = Double.parseDouble(txtNumber2.getText());
				
				double temp = 0;
				if(TheNumber1 < TheNumber2) {
					temp = TheNumber1;
					TheNumber1 = TheNumber2;
					TheNumber2 = temp;
				}
				Calculation3(TheNumber1, TheNumber2);
			
			
			}
			
		}
		catch(NumberFormatException err){			
			showStatus("please make sure you've entered everything!");
		}
		
	}
	
	public void Calculation1(double given) {
		
			System.out.println(theVictim);
		
			txaresult.append(": " + theVictim  + "\n ");
			
		theVictim /= 3;
		
		deathCount ++;
		
		if(theVictim >= 1) {	
			Calculation1(theVictim);
				System.out.println(theVictim);
			txaresult.append(": " + theVictim + "\n ");
		}
	
	}
	int oddball = 0;
	public void Calculation2(double given) {
		
		oddball = 2 * (int)theVictim - 1;
		
		System.out.println("number: " + oddball + ", The count: " + theVictim);
		txaresult.append("number: "+ oddball +", the count: " + theVictim + "\n ");
		
		theVictim --;	
		
		if(theVictim > 0) {
			Calculation2(theVictim);
		}
		
		
				
	}
	double booger = 0;
	boolean highersuccess = false;
	double highjerky = 0;
	public void Calculation3(double given, double given2) {
		
		booger = given % given2;
		boolean betterman = false;
		
		for(int i = 1; i <= given-(given2+1); i++) {
			 if(given % (given2 + i) == 0 ) 
				betterman = true;
			
			
		}
		
		if(betterman == true) {	
			
			txaresult.append("Nope not GCD. ");
			
						
		}
		else{
			
			txaresult.append("yes  GCD. ");
			
		}
		
		
	}

	int runtime = 0;

	public void Calculation4(double given, double given2) {
		
		booger = given % given2;
		if(booger == 0) {	
			
			Calculation4(given, booger);
			
		}
		if(given > given2 && runtime > 0) {
			
			txaresult.append("Nope not GCD. ");
		}
		
		
		
	}

	
	public void DesignInputPanel() {
		
		pnlInput.setLayout(new GridLayout(0,2));

	}		
	public void DesignOutputPanel() {
		
		pnlOutput.setLayout(new GridLayout(0,1));

		pnlInput.add(new JLabel("First Number : "));
			pnlInput.add(txtNumber1);
		pnlInput.add(new JLabel("Second Number : "));
			pnlInput.add(txtNumber2);
		
		pnlOutput.add(txaresult);
	
	}
	
	
}

