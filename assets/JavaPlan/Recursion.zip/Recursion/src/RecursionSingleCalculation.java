
public class RecursionSingleCalculation {

	double Number1;
	
	int oddCount;
	
	int timesDivided;
	
	int oddNumbers;
	
	RecursionSingleCalculation(double Uno){
		
		Number1 = Uno;
		
		Calculations();
	}
	public void Calculations() {
		double RollyPolly = Number1;
		double BaBaBlackSheep = Number1;
		for(int i = 0; i < Number1; i++) {
			
			
			
		}
		while(BaBaBlackSheep < 1) {
			
			BaBaBlackSheep /= 3.0; 
			timesDivided ++;
			
		}
		
		
	}
	
	public int TimesDivided() {
		
		return timesDivided;
	
	}
	
}
