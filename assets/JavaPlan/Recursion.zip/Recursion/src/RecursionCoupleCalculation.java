
public class RecursionCoupleCalculation {
	
	int Number1 , Number2;
	
	RecursionCoupleCalculation(double Uno, double Dos){
		
	}
	
}
