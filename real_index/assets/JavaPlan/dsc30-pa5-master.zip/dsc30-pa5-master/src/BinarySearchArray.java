import java.util.ArrayList;
/**
 * Name: Madeline Tjoa
 * PID: A15394053
 * */

/**
 * Uses binary search to find and insert the element so that the array remains sorted.
 * Note that our binary search array does not allow duplicates, same as our BST
 * */
public class BinarySearchArray<T extends Comparable<? super T>> {

    private ArrayList<T> sortedArray;

    public BinarySearchArray() {
        this.sortedArray = new ArrayList<>();
    }

    public BinarySearchArray(ArrayList<T> sortedArray) {
        this.sortedArray = sortedArray;
    }

    /**
     * This method will perform a binary search on the sortedArray.
     * If the element can be found in the array, this method should return the
     * index of that element. Otherwise, if the element is not in the array, this
     * method should still return the index where the given element should be inserted to.
     *
     * @param element the given element to find
     * @return the index of that element. Otherwise, if the element is not in the array, this
     *         method should still return the index where the given element should be inserted to.
     */
    private int binarySearch(T element) {
        int start = 0, end = sortedArray.size(), mid = 0;
        while (start < end) {
            mid = (end + start) / 2;
            int cmp = sortedArray.get(mid).compareTo(element);
            if (cmp == 0) {
                start = end = mid;
            }
            else if (cmp < 0) {
                start = mid + 1;
            }
            else {
                end = mid;
            }
        }
        return start;
    }

    /**
     * Use the binarySearch helper method to help you insert a given element.
     * Returns true if insertion is successful or false otherwise.
     *
     * Since our binary search array does not allow duplicates,
     * then if the given element is already present in our sortedArray,
     * this method should return false immediately.
     *
     * If the given element is not present in the sortedArray,
     * you should use the helper method to find the correct position to insert the element,
     * then return true.
     * (Hint: You should be using add(int index, T element) method of ArrayList here)
     *
     * */
    public boolean insert(T element) {
        // if the array is empty
        if(sortedArray.size() == 0){
            sortedArray.add(element);
            return true;
        }
        else if(this.find(element) == null){
            sortedArray.add(binarySearch(element), element);
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Use the binarySearch helper method to help you find a given element.
     * Returns the founded element if the element to find is present
     * in sortedArray or null otherwise.
     *
     * (Hint: use index returned by binarySearch
     * to check if the element at that index is the one you want to find)
     *
     * Note that you must return the element in your sortedArray
     * (the one with the same key value as the given element),
     * and you should not return the given element!
     * They may have the same key value but they are completely different references!     *
     * */
    public T find(T element) {
        int searchElementIndex = binarySearch(element);
        if(searchElementIndex >= sortedArray.size()){
            return null;
        }
        else if(sortedArray.get(searchElementIndex).equals(element)){
            return sortedArray.get(searchElementIndex);
        }
        return null;
    }

    public int getSize() {
        return sortedArray.size();
    }

    public void printArray() {
        System.out.println(sortedArray.toString());
    }

}

