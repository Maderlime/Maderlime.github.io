import org.junit.Test;

/**
 *
 * Name: Madeline Tjoa
 * PID: A15394053
 *
 * */
import java.util.Iterator;
import java.util.LinkedList;

import static org.junit.Assert.*;

public class BSTreeTester {

    BSTree<Integer> inOrder;
    BSTree<Integer> notOrdered;
    BSTree<Integer> emptyBST;
    BSTree<Integer> reverseOrder;

    @org.junit.Before
    public void setUp() throws Exception {
        inOrder = new BSTree<>();
        notOrdered = new BSTree<>();
        emptyBST = new BSTree<>();
        reverseOrder = new BSTree<>();

        for(int i = 0; i < 10; i++){
            inOrder.insert(i);
        }

        notOrdered.insert(9);
        notOrdered.insert(2);
        notOrdered.insert(3);
        notOrdered.insert(10);
        notOrdered.insert(8);
        notOrdered.insert(5);
        notOrdered.insert(13);
        notOrdered.insert(19);
        notOrdered.insert(4);
        notOrdered.insert(6);
        notOrdered.insert(7);
        notOrdered.insert(11);

        for(int i = 10; i > 0; i--){
            reverseOrder.insert(i);
        }
    }

    @org.junit.Test
    public void getRoot() {
        assertEquals(new Integer(0), inOrder.getRoot().getKey());
        assertEquals(new Integer(9), notOrdered.getRoot().getKey());
        assertEquals(new Integer(10), reverseOrder.getRoot().getKey());

    }

    @org.junit.Test
    public void insert() {
        assertEquals(10, inOrder.getSize());
        assertEquals(12, notOrdered.getSize());
        assertEquals(10, reverseOrder.getSize());
    }

    @org.junit.Test
    public void findKey() {

        assertTrue(inOrder.findKey(new Integer(3)));
        assertFalse(inOrder.findKey(new Integer(11)));
        assertTrue(notOrdered.findKey(new Integer(11)));
    }

    @org.junit.Test
    public void insertData() {
        for(int i = 0; i < 10; i++){
            inOrder.insertData(1, i);
            assertEquals(new LinkedList<Integer>(), inOrder.findDataList(new Integer(i)));
        }

        notOrdered.insertData(2, 1);
        LinkedList<Integer> Answer1 = notOrdered.getRoot().getDataList();
        assertEquals(Answer1, notOrdered.findDataList(2));

        reverseOrder.insertData(1, 1);
        LinkedList<Integer> Answer2 = reverseOrder.getRoot().getDataList();
        assertEquals(Answer1, reverseOrder.findDataList(1));
    }

    @org.junit.Test
    public void findDataList() {
        LinkedList<Integer> Answer1 = inOrder.getRoot().getDataList();
        assertEquals(Answer1, inOrder.findDataList(1));

        LinkedList<Integer> Answer2 = notOrdered.getRoot().getDataList();
        assertEquals(Answer2, notOrdered.findDataList(2));

        LinkedList<Integer> Answer3 = reverseOrder.getRoot().getDataList();
        assertEquals(Answer3, reverseOrder.findDataList(1));

    }

    @org.junit.Test
    public void findHeight() {
        assertEquals(9, inOrder.findHeight());
        assertEquals(6, notOrdered.findHeight());
        assertEquals(9, reverseOrder.findHeight());
    }

    @org.junit.Test
    public void leafCount() {
        assertEquals(1, inOrder.leafCount());
        assertEquals(4, notOrdered.leafCount());
        assertEquals(1, reverseOrder.leafCount());
    }

    @org.junit.Test
    public void iterator() {
        Iterator inOrderIter = inOrder.iterator();
        assertTrue(inOrderIter.hasNext());

        Integer inordersNode = inOrder.getRoot().getKey();
        assertEquals(inordersNode, inOrderIter.next());

        Iterator notOrderedIter = notOrdered.iterator();
        assertTrue(notOrderedIter.hasNext());
        assertEquals(2, notOrderedIter.next());

        Iterator reverseOrderIter = reverseOrder.iterator();
        assertTrue(reverseOrderIter.hasNext());
        Integer reverseordersNode = reverseOrder.getRoot().getKey();
        assertEquals(1, reverseOrderIter.next());


    }

    @Test
    public void intersectionTest(){
        Iterator inOrderIter = inOrder.iterator();
        assertTrue(inOrderIter.hasNext());

        Iterator notOrderedIter = notOrdered.iterator();
        assertTrue(notOrderedIter.hasNext());

        BinarySearchArray<Integer> orderedArray2 = new BinarySearchArray<>();

        System.out.println(inOrder.intersection(inOrderIter, notOrderedIter));

    }

    @Test
    public void removeMethod(){
        System.out.println(inOrder.remove(5));
        System.out.println(inOrder.findKey(5));
        System.out.println(notOrdered.remove(13));
        System.out.println(inOrder.findKey(13));
    }
}