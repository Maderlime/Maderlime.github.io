import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;
/**
 * Name: Madeline Tjoa
 * PID: A15394053
 * */

public class BinarySearchArrayTester {
    BinarySearchArray<Integer> orderedArray;



    @Before
    public void setUp() throws Exception {
        orderedArray = new BinarySearchArray<>();
    }

    /**
     * Inserting random numbers will always give you a sorted array
     * */
    @Test
    public void randomNumbers() {
        for(int i = 0; i < 15; i +=2){
            orderedArray.insert(i);
            orderedArray.printArray();
        }

        orderedArray.insert(4);
        assertEquals(new Integer(4), orderedArray.find(4));
        orderedArray.insert(2);
        assertEquals(new Integer(2), orderedArray.find(2));
        orderedArray.insert(8);
        assertEquals(new Integer(8), orderedArray.find(8));
        assertEquals(null, orderedArray.find(11));

    }

    /**
     * Finding elements presented in the array will always return the correct position,
     * and finding elements not in the array will return null
     * */
    @Test
    public void presentedArrays() {
        for(int i = 0; i < 15; i++){
            orderedArray.insert(i);
            orderedArray.printArray();
        }
        assertEquals(new Integer(2), orderedArray.find(2));
        assertEquals(new Integer(7), orderedArray.find(7));
        assertEquals(15, orderedArray.getSize());
        assertEquals(new Integer(0), orderedArray.find(new Integer(0)));

    }

    /**
     * Inserting a new element that is larger than any elements in the array
     * can be successfully performed
     * */
    @Test
    public void newElement() {

        for(int i = 0; i < 15; i++){
            orderedArray.insert(i);
            orderedArray.printArray();
        }

        assertEquals(15, orderedArray.getSize());
        assertEquals(new Integer(0), orderedArray.find(new Integer(0)));
    }

    /**
     * Finding a new element (not presented in the array)
     * that is larger than any elements in the array will return null.
     * */
    @Test
    public void largerElement() {

        for(int i = 0; i < 15; i +=2){
            orderedArray.insert(i);
            orderedArray.printArray();
        }

        assertEquals(null, orderedArray.find(101));

    }


}