import java.util.*;
/**
 * Name: Madeline Tjoa
 * PID: A15394053
 * */

/**
 * Generic binary search tree that can achieve O(logn) find and insert
 * Contains inner class BSTNode
 * an ordered map that maps the relevant infprmation of a given key to the key itself.
 * */
public class BSTree<T extends Comparable<? super T>> implements Iterable {

    private int nelems;
    private BSTNode root;

    /**
     * inner class
     * Contains a key to define the ordering of the node
     * */
    protected class BSTNode {

        T key;
        LinkedList<T> dataList;
        BSTNode left;
        BSTNode right;

        /**
         * Constructor that initializes the BST Node instance variable
         *
         * @param left the bstNode that is on the left
         * @param right the bstNode on the right
         * @param dataList the given dataList
         * @param key unique location of the Node
         * */
        public BSTNode(BSTNode left, BSTNode right, LinkedList<T> dataList, T key) {
            this.key = key;
            this.dataList = dataList;
            this.left = left;
            this.right = right;
        }

        /**
         * Constructor that initializes BSTNode variables
         *
         * is used when you want to add a key with no data.
         * must create an empty LinkedList for the node
         *
         * @param left the bstNode that is on the left
         * @param right the bstNode on the right
         * @param key unique location of the Node
         * */
        public BSTNode(BSTNode left, BSTNode right, T key) {
            this.key = key;
            dataList = new LinkedList<>();
            this.left = left;
            this.right = right;
        }
        /**
         * Returns the key
         * @return T key
         * */
        public T getKey() {
            return this.key;
        }

        /**
         * Getter for the left child of the node
         * @return left BSTNode
         * */
        public BSTNode getLeft() {
            return this.left;
        }

        /**
         * Getter for the right child of the node
         * @return right BSTNode
         * */
        public BSTNode getRight() {
            return this.right;
        }

        /**
         * Getter for the LinkedList of the node
         * @return LinkedList DataList
         * */
        public LinkedList<T> getDataList() {
            return this.dataList;
        }

        /**
         * Setter for left pointer of the node
         * @param newleft BSTNode that will be the new left pointer
         * */
        public void setleft(BSTNode newleft) {
            this.left = newleft;
        }

        /**
         * Setter for right pointer of the node
         * @param newright BSTNode that will be the new right pointer
         * */
        public void setright(BSTNode newright) {
            this.right = newright;
        }
        /**
         * Setter for the LinkedList of the node
         * @param newData LinkedList that will be new data contained
         * */
        public void setDataList(LinkedList<T> newData) {
            this.dataList = newData;
        }

        /**
         * Append data to the end of the existing LinkedList of the node
         * @param data the data that will be added to the LinkedList Node
         * */
        public void addNewInfo(T data) {
            this.dataList.add(data);
        }

        /**
         * Remove info data from the LinkedList of the node and return true.
         * If the LinkedList does not contain the element, return false
         *
         * @param data element that is going to be removed from the LinkedList
         * */
        public boolean removeInfo(T data) {
            if(this.dataList.contains(data)){
                this.dataList.remove(data);
            }
            return false;
        }
    }

    /**
     * A 0-arg constructor that initializes root to null and nelems to 0
     * */
    public BSTree() {
        this.root = null;
        this.nelems = 0;
    }

    /**
     * Returns the root of BSTree.
     * Returns null if the tree is empty
     * */
    public BSTNode getRoot() {
        if(nelems == 0){
            return null;
        }
        return this.root;
    }

    /**
     * Returns number of elements in the tree
     * */
    public int getSize() {
        return this.nelems;
    }

    /**
     * Inserts a key into the BST. Since our BST does not allow duplicates,
     * return false if the key is already presented in the BST.
     * Returns true if the insertion is successful.
     *
     * Throws NullPointerException if key is null.
     *
     * Note:
     * This method would insert a node with the key and an empty LinkedList into the tree.
     *
     * @param key the key that will be inserted
     * */
    public boolean insert(T key) {
        if(key == null){ //if key is null throw exception
            throw new NullPointerException("key is null");
        }
        if(this.findKey(key)){ // if the key is found return false
            return false;
        }
        // if the root is empty then add key at beginning
        if(this.getRoot() == null){
            this.root = new BSTNode(null, null, key);
            this.nelems ++;
            return true;
        }
        else{
            BSTNode iter = this.getRoot(); // iterator to go through the roots

            //while the iterator isn't at the very end
            while(iter != null){

                //if the key is less than the iteratorLocation
                if(key.compareTo(iter.getKey())<0){

                    if(iter.getLeft() == null){
                        //if left part is empty, insert a new node with specific key there
                        iter.setleft(new BSTNode(null, null, key));
                        this.nelems ++;
                        return true;
                    }
                    else{
                        //if not empty then go to the left again
                        iter = iter.getLeft();
                    }
                }
                //if the key is greater than the iteratorLocation
                else{
                    if(iter.getRight() == null){
                        //if right part is empty, insert a new node with specific key there
                        iter.setright(new BSTNode(null, null, key));
                        this.nelems ++;
                        return true;
                    }
                    else{
                        //if not empty then go to the right again
                        iter = iter.getRight();
                    }
                }
            }// end of while loop
        }
        return false;
    }

    /**
     * Return true if the ‘key’ is found in the tree, false otherwise.
     * Throw NullPointerException if key is null
     *
     * @param key the key that we are checking whether it exists
     * @return boolean true if it exists false if it does not
     * */
    public boolean findKey(T key) {
        if(key == null){
            throw new NullPointerException("findKey() key input is null");
        }
        BSTNode iter = this.getRoot(); //iterator to go through the tree
        while(iter != null){
            if(key.compareTo(iter.getKey()) == 0){ //if the key is equal to the key of the iter
                return true;
            }
            else if(key.compareTo(iter.getKey()) < 0){ //if key value is less than target value
                iter = iter.getLeft();
            }
            else{
                iter = iter.getRight();
            }
        }
        return false;
    }

    /**
     * Inserts data into the LinkedList of the node whose key is key.
     * Throw NullPointerException if key or ‘data’ is null
     * Throw IllegalArgumentException if ‘key’ is not found in the BST
     *
     * @param key the key location that the data will be inserted in
     * @param data data value that is going to be inserted into the key
     * */
    public void insertData(T key, T data) {
        //make sure both parameters are not null
        if(key == null || data == null){
            throw new NullPointerException("Key or data inputted is null");
        }
        //make sure the key exists
        if(this.findKey(key) == false){
            throw new IllegalArgumentException(key + "is not found in the BST");
        }

        if(this.getRoot() == null){
            this.root = new BSTNode(null, null, key);
        }
        else {
            BSTNode iter = this.getRoot();
            //while we can still go through iterations
            while (iter != null) {
                // if the key is at the position we are looking for append it
                if (key.equals(iter.getKey())) {
                    iter.addNewInfo(data);
                    break;
                } else if (key.compareTo(iter.getKey()) < 0) {
                    iter = iter.getLeft();
                } else {
                    iter = iter.getRight();
                }

            }
        }
    }

    /**
     * Return the LinkedList of the node with key value key
     * Throw NullPointerException if key is null
     * Throw IllegalArgumentException if ‘key’ is not found in the BST
     *
     * @param key the key of the dataList we want to get to
     * @return LinkedList of the node with key value key
     * */
    public LinkedList<T> findDataList(T key) {
        if(key == null){
            throw new NullPointerException("findDataList() Key is null");
        }
        if(!this.findKey(key)){
            throw new IllegalArgumentException("findDataList() key does not exist");
        }

        BSTNode iter = this.getRoot();

        // while loop to go go through the keys
        while(iter != null){
            // when key is found return DataList associated to Key
            if(key.compareTo(iter.getKey()) == 0){
                return iter.getDataList();
            }
            else if(key.compareTo(iter.getKey())< 0){
                iter = iter.getLeft();
            }
            else{
                iter = iter.getRight();
            }

        }
        return null;
    }

    /**
     * Returns the height of the tree, which is defined to be the number of
     * "edges" on the longest downward path from the root to any leaf.
     *
     * By convention, height of an empty tree is -1 and the height of a tree
     * with only one node is 0
     * @return height of the Binary tree.
     * */
    public int findHeight() {
        return findHeightHelper(this.root);
    }

    private int findHeightHelper(BSTNode node){
        if(node == null){
            return -1;
        }

        //recursive function to find height
        int leftHeight = findHeightHelper(node.getLeft());
        int rightHeight = findHeightHelper(node.getRight());

        int returnNumber = 0;
        if(leftHeight > rightHeight){
            returnNumber = leftHeight;
        }
        else{
            returnNumber = rightHeight;
        }
        return 1 + returnNumber;
    }

    /**
     * Returns the number of leaf nodes in the tree.
     * Leaves are nodes with no children.
     * @return amount of leaves in the Tree.
     *
     * */
    public int leafCount() {
        return leafCountHelper(this.getRoot());
    }

    /**
     * Helper method for leafCount
     *
     * @param node the beginning of the node
     * @return recursively add left and right nodes.
     * */
    public int leafCountHelper(BSTNode node){
        if(node == null){
            return 0;
        }
        else if(node.getLeft() == null && node.getRight() == null){
            return 1;
        }
        else{
            return leafCountHelper(node.getLeft()) + leafCountHelper(node.getRight());
        }
    }

    /**
     * BSTree Iterator can be used to get the keys and iterate through stacks
     * The iterator will be helpful when we want to traverse the tree in strict order.
     * */
    //******************ITERATOR STARTS HERE!!!********************************
    public class BSTree_Iterator implements Iterator<T> {
        Stack<BSTNode> myStack;
        /**
         * Constructor initializes the stack with the leftPath of the root
         * */
        public BSTree_Iterator() {
            myStack = new Stack<>();
            BSTNode curr = root;
            while(curr != null){
                myStack.push(curr);
                curr = curr.getLeft();
            }
        }

        /**
         * Returns false if the Stack is empty
         * ie no more nodes left to iterate, true otherwise
         * */
        public boolean hasNext() {
            return !myStack.empty();
        }

        /**
         * Returns the next item in the BST
         * Throws NoSuchElementException if there is no next item.
         * */
        public T next() {
            if(myStack.peek() == null){
                throw new NoSuchElementException("myStack.peek() return null");
            }
            //check if there is a right
            BSTNode poppedElement = myStack.pop();
            BSTNode rightElem = poppedElement.getRight();
            if(rightElem != null){
                //if there is a right, go down all the left side of the right
                while(rightElem != null){
                    myStack.push(rightElem);
                    rightElem = rightElem.getLeft();
                }
            }
            return poppedElement.getKey();
            //at the very end return the key that we popped.
        }
    }

    /**
     * You can now create an iterate over your BSTree
     * by calling the iterator( ) method on it as
     * follows in the tester:
     *
     * Iterator<String> iter = myTree.iterator();
     * */
    public Iterator<T> iterator() {
        return new BSTree_Iterator();
    }

    /**
     * returns the intersection of two BSTrees
     * (Elements that can be found in both BSTs).
     * The method takes two iterators as parameter
     * and returns an ArrayList containing the intersection
     * data of the two trees
     * */
    public ArrayList<T> intersection(Iterator<T> iter1, Iterator<T> iter2){
        ArrayList<T> myMatches = new ArrayList<>();

        Iterator iterator1 = iter1;
        Iterator iterator2 = iter2;

        T myKey1 = (T)iterator1.next();
        T myKey2 = (T)iterator2.next();
        // While iterator that has
        while(iterator1.hasNext() && iterator2.hasNext()) {

            if(myKey1.equals(myKey2)){
                myMatches.add(myKey1);
                myKey1 = (T)iterator1.next();
                myKey2 = (T)iterator2.next();

            }
            else if(myKey1.compareTo(myKey2) < 0){
                myKey1 = (T)iterator1.next();
            }
            else{
                myKey2 = (T)iterator2.next();
            }

        }


        return myMatches;
    }

    /**
     *  counts the number of nodes at a given level.
     *  The method takes a level as a parameter
     *  and returns the count of nodes at that level
     * */
    public int levelCount(int level){
        int numberOfNodes = 0;

        return numberOfNodes;
    }

    /**
     * Remove a node
     */
    public boolean remove(T data){

        BSTNode par = null;
        BSTNode cur = this.getRoot();
        while (cur != null) { // Search for node
            if (cur.getKey().equals(data)) { // Node found
                if (cur.getLeft() == null && cur.getRight() == null) {        // Remove leaf
                    if (par.getKey() == null) // Node is root
                        this.root = null;
                    else if (par.getLeft() == cur)
                        par.setleft(null);
                    else
                        par.setright(null);
                }
                else if (cur.getLeft() != null && cur.getRight() == null) {    // Remove node with only left child
                    if (par == null) // Node is root
                        this.root = cur.getLeft();
                    else if (par.getLeft() == cur)
                        par.setleft(cur.getLeft());
                    else
                        par.setright(cur.getLeft());
                }
                else if (cur.getLeft() == null && cur.getRight() != null) {    // Remove node with only right child
                    if (par.getKey() == null) // Node is root
                        this.root = cur.getRight();
                    else if (par.getLeft() == cur)
                        par.setleft(cur.getRight());
                    else
                        par.setright(cur.getRight());
                }
                else {                                  // Remove node with two children
                    // Find successor (leftmost child of right subtree)
                    BSTNode suc = cur.getRight();
                    while (suc.getLeft() != null){
                        suc = suc.getLeft();
                        LinkedList<T> successorData = findDataList(suc.getKey());
                        remove(suc.getKey());     // Remove successor
                        cur.setDataList(successorData);
                    }
                    // Assign cur's data with successorData
                }
                return true; // Node found and removed
            }
            else if (cur.getKey().compareTo(data) < 0) { // Search right
                par = cur;
                cur = cur.getRight();
            }
            else {                     // Search left
                par = cur;
                cur = cur.getLeft();
            }
        }
        return false; // Node not found

    }


    /* A recursive function to insert a new key in BST */


}
