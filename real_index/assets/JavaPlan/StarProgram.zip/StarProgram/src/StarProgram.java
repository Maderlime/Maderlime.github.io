import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class StarProgram extends JApplet implements ActionListener{

	//declare our components or fields(global level variable)
		JTextArea txaresult = new JTextArea(
				"Score" + "\n", 10,33);
	
		JButton btnAdd = new JButton("Add Type");
	
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		double First;
		double Second;
		double Third;
		
		String elApple;
		String elBapo;
		String elChapo;
		
		String officialThug;
		double officialFakeThug;
		
		//radio buttons
		JRadioButton addRadioButton = new JRadioButton("Fitst");
		JRadioButton oddRadioButton = new JRadioButton("Secind");
		JRadioButton factorialRadioButton = new JRadioButton("Third");
		
		ButtonGroup PayButtonGroup = new ButtonGroup();
		
	//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			resize(500,400);
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			String testString;
			String outputString;
			double Score1Double;
			
			
		//2. information	
		try {
//3. Calculate 
				
	//		TestCalculations ThePayClass = new TestCalculations(Score1Double);
	//		double totalTestsTakener = ThePayClass.TestsTaken();
	//		String theaddlist = ThePayClass.returnlist();

			if(addRadioButton.isSelected()) {
				double amount;
				String ihavenoidea = "";
				for (int i =0; i<10; i++ ) {
					ihavenoidea +="*";
					elApple += ("\n" + ihavenoidea +" \n");		
				}
				
				officialThug = elApple;
				}
			else if(oddRadioButton.isSelected()) {
				String ihavenoidea = "************";
					for (int i =0; i<10; i++ ) {
						StringBuilder sb = new StringBuilder(ihavenoidea);
						sb.deleteCharAt(1);
						ihavenoidea = sb.toString();
			
						elBapo += ("\n" + ihavenoidea +" \n");		
					}
					officialThug = elBapo;
				}
			else if(factorialRadioButton.isSelected()) {
				String ihavenoidea = "***********s";
				String goo ="";
					for (int i =0; i<10; i++ ) {
						StringBuilder sb = new StringBuilder(ihavenoidea);
						int number = sb.length()-1;
						ihavenoidea = sb.substring(0, sb.length() - 1);
						sb.deleteCharAt(number);
						ihavenoidea = sb.toString();
						sb.insert(0, " ");
						ihavenoidea = sb.toString();
						
						
						
			
						elChapo += ("\n" + ihavenoidea +" \n");		
					}
					officialThug = elChapo;
				}
			
			
//5. output in the text Area
			txaresult.setText( "Number you Chose: " +  officialThug
									);
			
			
			}
		catch(NumberFormatException err){
			
			showStatus("please make sure you've entered everything!");
		}
		}
		
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			

		
				
				pnlInput.add(addRadioButton);
				pnlInput.add(oddRadioButton);	
				pnlInput.add(factorialRadioButton);	
			

				
				PayButtonGroup.add(addRadioButton);
				PayButtonGroup.add(oddRadioButton);
				PayButtonGroup.add(factorialRadioButton);
				
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);
			
		}
		
	
	
}
