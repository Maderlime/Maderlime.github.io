
public class StarCalculations {
	//class variables
	private double dblScore1;

	double sumofn;	

	String Doesit;
//create our class constructor
//The class calls this method first
//The constructor has the same name as the class
	StarCalculations(){
			
			CalculateCharge();
	}

//create our calculator functions
	private void CalculateCharge() {
	
		double Life1 = dblScore1;
		 double pleasefam = 0;
		 double theadder = 0;

		//previousHighScore = currentHighScore;
		//sumofn += Life1;
		//totalTests ++;
		
		for (int i =0; i<(double)10; i++ ) {
			
			//simple sum
				pleasefam += 1;
				theadder += pleasefam;
				sumofn = theadder;
			
				Doesit += ("*");
			
			
		}
		//averageTestScore = sumofn/totalTests;
		
	}

//return answers into the other class

	public double TestsTaken() {

		return sumofn;
	}
	public String returnlist() {
		
		return Doesit;
	}
	
}
