import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;

public class TestCalculations {
	//class variables
	private double dblScore1, dblScore2, dblScore3, dblScore4, dblScore5;
	
//static means hold its value over time.

	
	static double totalTests;
	static double sumOfTests;
	double averageTestScore;
	static double letterGrade;
	static double collectiveGrade;
	
	static double currentHighScore;
	static double previousHighScore;
	
	
	
			

//create our class constructor
//The class calls this method first
//The constructor has the same name as the class
	TestCalculations(double Score1){
	
	//theRate and theHours are the parameters for the method
			dblScore1 = Score1;

	
			CalculateCharge();
			
			
			
	}

//create our calculator functions
	private void CalculateCharge() {
	
		double Life1 = dblScore1;
		
		//previousHighScore = currentHighScore;
		sumOfTests += Life1;
		totalTests ++;
		
		averageTestScore = sumOfTests/totalTests;
		if(totalTests <=1) {
			currentHighScore = Life1;
		}
		else {
			if(currentHighScore < Life1) {
				currentHighScore = Life1;
			}
		}
		//For the Single Score
		if(Life1 >50) {
				if(Life1> 60) {
					if(Life1>70) {
						if(Life1>80) {
							if(Life1>90) {
								letterGrade = 5;
							}
						}
						else {letterGrade = 4;}
					}
					else {letterGrade = 3;}
				}
				else {letterGrade = 2;}
		}
		else {letterGrade = 1;}
		
		//For The Average Score
		if(averageTestScore >=50) {
			if(averageTestScore>= 60) {
				if(averageTestScore>=70) {
					if(averageTestScore>=80) {
						if(averageTestScore>=90) {
							collectiveGrade = 5;
						}
					}
					else {collectiveGrade = 4;}
				}
				else {collectiveGrade = 3;}
			}
			else {collectiveGrade = 2;}
	}
	else {collectiveGrade = 1;}
	}

//return answers into the other class
	public double averageScore() {

		return averageTestScore;
		
	}
	public double TestsTaken() {

		return totalTests;
	}
	public double HighestScore() {

		return currentHighScore;
		
	}
	public double ElLetterGrade() {
		return letterGrade;
	}
	public double CollectiveLetterGrade() {
		return collectiveGrade;
	}
	
	
}
