//madeline tjoa BMI

import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

import java.io.*;
import java.text.*;


public class TestScoreProgram extends JApplet implements ActionListener{

	//declare our components or fields(global level variable)
		JTextField txtSubject = new JTextField(20);
		JTextField txtScore1 = new JTextField(20);

		
	
		JTextArea txaresult = new JTextArea(
				"Score" + "\n", 10,33);
	
		JButton btnAdd = new JButton("Add Test");
	
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		double AverageGrade;
		double HighestGrade;
		double averageSpent;
		
		String soloGrade;
		String everyGrade;
		
	
	//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			resize(500,400);
			txtSubject.requestFocus();
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
			txtScore1.addActionListener(this);


			
			
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			String testString;
		
		
			
			
			
			String outputString;
			
			double Score1Double;

			
			
		//2. information	
		try {
			testString = txtSubject.getText();

			
			Score1Double = Double.parseDouble(txtScore1.getText());

			
			
//3. Calculate 
				
			TestCalculations ThePayClass = new TestCalculations(Score1Double);
			double averageTestScore = ThePayClass.averageScore();
			double totalTestsTaken = ThePayClass.TestsTaken();
			double highestTestScore = ThePayClass.HighestScore();
			double singleGrade = ThePayClass.ElLetterGrade();
			double teamGrade = ThePayClass.CollectiveLetterGrade();
			
			TestFormat theFormatClass = new TestFormat(averageTestScore, totalTestsTaken, highestTestScore);
			double AaverageTestScore = theFormatClass.returnAverageScore();
			double AtotalTestsTaken = theFormatClass.returnTestsTaken();
			double AhighestTestScore = theFormatClass.returnHighestScore();
			
			
		//extra: connect to a format cclass	
			//String formattedDataString;
			
			//formattedDataString = fmtCurrency.format(payDouble);

			//String betterNumber = decFor.format(payDouble);
			
			//S
			if(singleGrade ==1) {
				soloGrade = "F";
			}
			else if(singleGrade ==2) {
				soloGrade = "D";
			}
			else if(singleGrade ==3) {
				soloGrade = "C";
			}
			else if(singleGrade ==4) {
				soloGrade = "B";
			}
			else if(singleGrade ==5) {
				soloGrade = "A";
			}
			//Collective Grade
			if(teamGrade ==1) {
				everyGrade = "F";
			}
			else if(teamGrade ==2) {
				everyGrade = "D";
			}
			else if(teamGrade ==3) {
				everyGrade = "C";
			}
			else if(teamGrade ==4) {
				everyGrade = "B";
			}
			else if(teamGrade ==5) {
				everyGrade = "A";
			}
			
					
			
		//4. output in the text Area
			txaresult.setText("Name: " + testString + 
									" \n \t Tests Taken: " + AtotalTestsTaken +
									" \n \t average Test Score: " + AaverageTestScore +
									" \n \t highest Test Score: " + AhighestTestScore +
									" \n \t Your Letter Grade for this Test: " + soloGrade +
									" \n \t Your Total Letter Grade" + everyGrade);
			
			txtSubject.setText("");
			txtScore1.setText("");

			
			
			txtScore1.requestFocus();
			}
		catch(NumberFormatException err){
			
			showStatus("please make sure you've entered everything!");
		}
		}
		
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			
			pnlInput.add(new JLabel("Name of Subject: "));
				pnlInput.add(txtSubject);
			pnlInput.add(new JLabel("Score 1: "));
				pnlInput.add(txtScore1);
				
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);
			
		}
		
	
	
}
