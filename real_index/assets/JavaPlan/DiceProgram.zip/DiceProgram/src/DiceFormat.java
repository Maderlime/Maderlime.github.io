import java.text.DecimalFormat;

import javax.swing.ButtonGroup;
public class DiceFormat {

		private double dblP2, dblP3, dblP4, dblP5, dblP6, dblP7, dblP8, dblP9, dblP10, dblP11, dblP12;
	DiceFormat(double F2, double F3, double F4, double F5 , double F6, double F7,  double F8, double F9, double F10, double F11, double F12){
		
		//theRate and theHours are the parameters for the method
				dblP2 = F2;
				dblP3 = F3;
				dblP4 = F4;
				dblP5 = F5;
				dblP6 = F6;
				dblP7 = F7;
				dblP8 = F8;
				dblP9 = F9;
				dblP10 = F10;
				dblP11 = F11;
				dblP12 = F12;
		
				CalculateCharge();
				
				
				
		}
	
	private void CalculateCharge() {
		
		DecimalFormat decFor = new DecimalFormat("##.##");
		String pof2 = decFor.format(dblP2);
		String pof3 = decFor.format(dblP3);
		String pof4 = decFor.format(dblP4);
		String pof5 = decFor.format(dblP5);
		String pof6 = decFor.format(dblP6);
		String pof7 = decFor.format(dblP7);
		String pof8 = decFor.format(dblP8);
		String pof9 = decFor.format(dblP9);
		String pof10 = decFor.format(dblP10);
		String pof11 = decFor.format(dblP11);
		String pof12 = decFor.format(dblP12);
		
		double P2 =  Double.parseDouble(pof2); 
		double P3 =  Double.parseDouble(pof3);
		double P4 =  Double.parseDouble(pof4);
		double P5 =  Double.parseDouble(pof5);
		double P6 =  Double.parseDouble(pof6);
		double P7 =  Double.parseDouble(pof7);
		double P8 =  Double.parseDouble(pof8);
		double P9 =  Double.parseDouble(pof9);
		double P10 =  Double.parseDouble(pof10);
		double P11 =  Double.parseDouble(pof11);
		double P12 =  Double.parseDouble(pof12);
		
		dblP2 = P2;
		dblP3 = P3;
		dblP4 = P4;
		dblP5 = P5;
		dblP6 = P6;
		dblP7 = P7;
		dblP8 = P8;
		dblP9 = P9;
		dblP10 = P10;
		dblP11 = P11;
		dblP12 = P12;
		
	}
	
	public double ReturnP2() {
		return dblP2;	
	}	
	public double ReturnP3() {
			return dblP3;	
	}
	public double ReturnP4() {
		return dblP4;	
}
	public double ReturnP5() {
		return dblP5;	
}
	public double ReturnP6() {
		return dblP6;	
}
	public double ReturnP7() {
		return dblP7;	
}
	public double ReturnP8() {
		return dblP8;	
}
	public double ReturnP9() {
		return dblP9;	
}
	public double ReturnP10() {
		return dblP10;	
}
	public double ReturnP11() {
		return dblP11;	
}
	public double ReturnP12() {
		return dblP12;	
}

	
	
}
