
import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

import java.io.*;
import java.text.*;

import java.util.Random;


public class DiceInterface extends JApplet implements ActionListener{

	
	
		JTextArea txaresult = new JTextArea(
				"ROLL RESULTS" + "\n", 20,30);
	
		JButton btnAdd = new JButton("Roll Dice");
	
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		
		double diceSum = 0;
		double timesrolled;
		
		Random rand = new Random();
		
		double  dice1;
		double  dice2;	 
		
	
	//Create the init method(initialize method)
		public void init() {
			
			
		
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			resize(350,550);

			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
			
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			
			
			
			
			
		//2. information	
			
			
			
			
			
			
			
			
//3. Calculate 
			
			double  potato1 = rand.nextInt(6) + 1;
			double  potato2 = rand.nextInt(6) + 1;
			
			dice1 = potato1;
			dice2 = potato2;
			
			DiceCalculations ThePayClass = new DiceCalculations(dice1, dice2);		
			
			
			double FdiceSum = ThePayClass.diceSum();
			double FtimesRolled = ThePayClass.LeRolls();
			
			double FRoll2 = ThePayClass.statistics2();
			double FRoll3 = ThePayClass.statistics3();
			double FRoll4 = ThePayClass.statistics4();
			double FRoll5 = ThePayClass.statistics5();
			double FRoll6 = ThePayClass.statistics6();
			double FRoll7 = ThePayClass.statistics7();
			double FRoll8 = ThePayClass.statistics8();
			double FRoll9 = ThePayClass.statistics9();
			double FRoll10 = ThePayClass.statistics10();
			double FRoll11 = ThePayClass.statistics11();
			double FRoll12 = ThePayClass.statistics12();
			
			
			double FProb2 = ThePayClass.probability2();
			double FProb3 = ThePayClass.probability3();
			double FProb4 = ThePayClass.probability4();
			double FProb5 = ThePayClass.probability5();
			double FProb6 = ThePayClass.probability6();
			double FProb7 = ThePayClass.probability7();
			double FProb8 = ThePayClass.probability8();
			double FProb9 = ThePayClass.probability9();
			double FProb10 = ThePayClass.probability10();
			double FProb11 = ThePayClass.probability11();
			double FProb12 = ThePayClass.probability12();
			
			
			
		//extra: connect to a format class	
			
			DiceFormat Problems = new DiceFormat(FProb2, FProb3, FProb4, FProb5, FProb6, FProb7, FProb8, FProb9, FProb10, FProb11, FProb12);
			
			double Probablility2 = Problems.ReturnP2();
			double Probablility3 = Problems.ReturnP3();
			double Probablility4 = Problems.ReturnP4();
			double Probablility5 = Problems.ReturnP5();
			double Probablility6 = Problems.ReturnP6();
			double Probablility7 = Problems.ReturnP7();
			double Probablility8 = Problems.ReturnP8();
			double Probablility9 = Problems.ReturnP9();
			double Probablility10 = Problems.ReturnP10();
			double Probablility11 = Problems.ReturnP11();
			double Probablility12 = Problems.ReturnP12();
			
		//4. output in the text Area
			txaresult.setText("Numbers Rolled : \n " + dice1 + "," +  dice2 + 
							
								" \n \n \t Sum of these Rolls: " + FdiceSum + 
								"\n Statistics:" +
								"\n \t  2: " + FRoll2 +
								"\n \t  3: " + FRoll3 +
								"\n \t 4: " + FRoll4 +
								"\n \t 5: " + FRoll5 +
								"\n \t 6: " + FRoll6 +
								"\n \t 7: " + FRoll7 +
								"\n \t 8: " + FRoll8 +
								"\n \t 9: " + FRoll9 +
								"\n \t 10: " + FRoll10 +
								"\n \t 11: " + FRoll11 +
								"\n \t 12: " + FRoll12 + 
								" \n Number of Total Rolls: " + FtimesRolled +
								"\n \t Probabilities: " + 
								"\n \t Chances for a 2: " + Probablility2 +
								"\n \t Chances for a 3: " + Probablility3 +
								"\n \t Chances for a 4: " + Probablility4 +
								"\n \t Chances for a 5: " + Probablility5 +
								"\n \t Chances for a 6: " + Probablility6+
								"\n \t Chances for a 7: " + Probablility7+
								"\n \t Chances for a 8: " + Probablility8 +
								"\n \t Chances for a 9: " + Probablility9 +
								"\n \t Chances for a 10: " + Probablility10 +
								"\n \t Chances for a 11: " + Probablility11 +
								"\n \t Chances for a 12: " + Probablility12 +
			
								"\n"	
								);
			
			
		
		}
		
		//Total Charge
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));	
				
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);		
		}
		
	
	
}

