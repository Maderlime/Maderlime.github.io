import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;

public class DiceCalculations {
	//class variables
	private double dbldice1, dbldice2;
	
//static means hold its value over time.

	
	static double timesRolled;
	static double timesRolled2;
	static double timesRolled3;
	static double timesRolled4;
	static double timesRolled5;
	static double timesRolled6;
	static double timesRolled7;
	static double timesRolled8;
	static double timesRolled9;
	static double timesRolled10;
	static double timesRolled11;
	static double timesRolled12;
	double LeSum;
	
	private double diceSUM;
	
	
	
	
			

//create our class constructor
//The class calls this method first
//The constructor has the same name as the class
	DiceCalculations(double dice1, double dice2){
	
	//theRate and theHours are the parameters for the method
			dbldice1 = dice1;
			dbldice2 = dice2;
	
			CalculateCharge();
			
			
			
	}

//create our calculator functions
	private void CalculateCharge() {
	
		
		//numberProcessedint ++;		
		
		
		double Deece1 = dbldice1;
		double Deece2 = dbldice2;
		
		
		
		
		
		LeSum = Deece1 + Deece2;
		diceSUM = LeSum;
		timesRolled ++;
		
		if (LeSum ==2) {
			timesRolled2 ++;
		}
		if (LeSum ==3) {
			timesRolled3 ++;
		}
		if (LeSum ==4) {
			timesRolled4 ++;
		}
		if (LeSum ==5) {
			timesRolled5 ++;
		}
		if (LeSum ==6) {
			timesRolled6 ++;
		}
		if (LeSum ==7) {
			timesRolled7 ++;
		}
		if (LeSum ==8) {
			timesRolled8 ++;
		}
		if (LeSum ==9) {
			timesRolled9 ++;
		}
		if (LeSum ==10) {
			timesRolled10 ++;
		}
		if (LeSum ==11) {
			timesRolled11 ++;
		}
		if (LeSum ==12) {
			timesRolled12 ++;
		}
		
		
		
		
		
		
		
		
		
	}

//return answers into the other class
	public double diceSum() {
		//CalculateMiles();
		return diceSUM;
		
	}
	public double LeRolls() {
		return timesRolled;	
		//return averageSpent;
		
	}


	public double statistics2() {
		return timesRolled2;
	}
	public double statistics3() {
		return timesRolled3;
	}
	public double statistics4() {
		return timesRolled4;
	}
	public double statistics5() {
		return timesRolled5;
	}
	public double statistics6() {
		return timesRolled6;
	}
	public double statistics7() {
		return timesRolled7;
	}
	public double statistics8() {
		return timesRolled8;
	}
	public double statistics9() {
		return timesRolled9;
	}
	public double statistics10() {
		return timesRolled10;
	}
	public double statistics11() {
		return timesRolled11;
	}
	public double statistics12() {
		return timesRolled12;
	}
	
//Probabilities
	public double probability2() {
		double P2 = timesRolled2/timesRolled;
		return P2;
	}
	public double probability3() {
		double P3 = timesRolled3/timesRolled;
		return P3;
	}
	public double probability4() {
		double P4 = timesRolled4/timesRolled;
		return P4;
	}
	public double probability5() {
		double P5 = timesRolled5/timesRolled;
		return P5;
	}
	public double probability6() {
		double P6 = timesRolled6/timesRolled;
		return P6;
	}
	public double probability7() {
		double P7 = timesRolled7/timesRolled;
		return P7;
	}
	public double probability8() {
		double P8 = timesRolled8/timesRolled;
		return P8;
	}
	public double probability9() {
		double P9 = timesRolled9/timesRolled;
		return P9;
	}
	public double probability10() {
		double P10 = timesRolled10/timesRolled;
		return P10;
	}
	public double probability11() {
		double P11 = timesRolled11/timesRolled;
		return P11;
	}
	public double probability12() {
		double P12 = timesRolled12/timesRolled;
		return P12;
	}
	
}
