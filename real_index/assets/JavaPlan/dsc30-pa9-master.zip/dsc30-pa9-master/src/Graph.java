//

import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.sql.SQLOutput;
import java.util.*;
/**
 * Madeline Tjoa
 * A15394053 *
 * */

/**
 * Graph class that contains all of the algorithms
 * DFS, BFS, A*, Dijkstra
 * */
public class Graph {

    private static final int EUCLIDIAN_FACTOR = 2;
    // TODO: define a data structure to store all the
    //  vertices with fast access
    int numVertices;
    Map<String, Vertex> myVertices; // vertices map <string, Vertex> <cityname, orderAdded>

    /**
     * Constructor for Graph
     */
    public Graph() {
        // TODO DONE
        numVertices = 0;
        myVertices = new HashMap<String,Vertex>();
    }

    /**
     * Adds a vertex to the graph. Throws IllegalArgumentException if given vertex
     * already exist in the graph.
     *
     * @param v vertex to be added to the graph
     * @throws IllegalArgumentException if two vertices with the same name are added.
     */
    public void addVertex(Vertex v) throws IllegalArgumentException {
        // TODO DONE
        if(v == null){
            return;
        }
        if(myVertices.containsKey(v.getName())){
            throw new IllegalArgumentException("key already exists");
        }
        myVertices.put(v.getName(), v);
        numVertices ++;
    }

    /**
     * Gets a collection of all the vertices in the graph
     *
     * @return collection of all the vertices in the graph
     */
    public Collection<Vertex> getVertices() {
        // TODO DONE
        return myVertices.values();
    }

    /**
     * Gets the vertex object with the given name
     *
     * @param name name of the vertex object requested
     * @return vertex object associated with the name
     */
    public Vertex getVertex(String name) {
        //TODO DONE
        return myVertices.get(name);
    }

    /**
     * Adds a directed edge from vertex u to vertex v,
     * Throws IllegalArgumentException if one of
     * the vertex does not exist
     *
     * @param nameU name of vertex u
     * @param nameV name of vertex v
     * @param weight weight of the edge between vertex u and v
     * @throws IllegalArgumentException if one of the vertex does not exist
     */
    public void addEdge(String nameU, String nameV, Double weight)
            throws IllegalArgumentException {
        // TODO DONE
        Vertex firstV = myVertices.get(nameU);
        Vertex secondV = myVertices.get(nameV);
        if(firstV == null || secondV == null){
            throw new IllegalArgumentException("addEdge one of names DNE");
        }
        Edge addedEd = new Edge(firstV, secondV, weight);
        secondV.addincomingVertex(addedEd);
        firstV.addConnection(addedEd);
    }

    /**
     * Adds an undirected edge between vertex u and vertex v by adding a directed
     * edge from u to v, then a directed edge from v to u
     *
     * @param nameU name of vertex u
     * @param nameV name of vertex v
     * @param weight  weight of the edge between vertex u and v
     */
    public void addUndirectedEdge(String nameU, String nameV, double weight) {
        // TODO DONE
        addEdge(nameU, nameV, weight);
        addEdge(nameV, nameU, weight);
    }

    /**
     * Computes the euclidean distance between two points as described by their
     * coordinates
     *
     * @param ux (double) x coordinate of point u
     * @param uy (double) y coordinate of point u
     * @param vx (double) x coordinate of point v
     * @param vy (double) y coordinate of point v
     * @return (double) distance between the two points
     */
    public double computeEuclideanDistance(double ux,
                                           double uy, double vx, double vy) {

        // TODO DONE
        double tempx = vx - ux;
        double tempy = vy - uy;
        tempx = Math.pow(tempx, EUCLIDIAN_FACTOR);
        tempy = Math.pow(tempy, EUCLIDIAN_FACTOR);
        double distance = Math.sqrt(tempx + tempy);
        return distance;
    }

    /**
     * Calculates the euclidean distance for all edges in the map using the
     * computeEuclideanCost method.
     */
    public void computeAllEuclideanDistances() {
        // TODO

        LinkedList<Vertex> myVertLL = new LinkedList<>();
        Collection<Vertex> myVertCollection = getVertices();
        myVertLL.addAll(myVertCollection);

        for(int i = 0; i< myVertLL.size(); i++){

            LinkedList vEdges = myVertLL.get(i).getMyEdges();
            for(int j = 0; j < vEdges.size(); j++){

                Edge littleEd = (Edge) vEdges.get(j);

                Vertex lilSource = littleEd.getSource();
                Vertex lilTarget = littleEd.getTarget();

                double ux = lilSource.getX();
                double uy = lilSource.getY();
                double vx = lilTarget.getX();
                double vy = lilTarget.getY();

                littleEd.setDistance(
                        computeEuclideanDistance(ux, uy, vx, vy));
            }
        }
    }

    /**
     * Helper method to reset all the vertices before doing graph traversal algorithms
     */
    private void resetAllVertices() {

        // TODO DONE
        LinkedList<Vertex> myVertLL = new LinkedList<>();
        Collection<Vertex> myVertCollection = getVertices();
        myVertLL.addAll(myVertCollection);

        for(int i = 0; i< myVertLL.size(); i++){
            Vertex targetV = myVertLL.get(i);
            targetV.unVisit();
            targetV.prevVertex = null;
        }
    }

    /**
     * Find the path from vertex with name s to vertex with name t, using DFS
     *
     * @param s the name of the starting vertex
     * @param t the name of the targeting vertex
     */
    public void DFS(String s, String t) {

        // TODO
        Stack<Vertex> myStack = new Stack();

        resetAllVertices();
        Vertex startVertex = myVertices.get(s);
        Vertex targetVertex = myVertices.get(t);
        startVertex.setPrevVertex(null);
        startVertex.setPrevEdge(null);

        myStack.push(startVertex);

        while(!myStack.empty()){

            Vertex focusVert = myStack.pop();
            focusVert.visitLocation();
            if(focusVert.equals(targetVertex)){
                // targetVertex.setPrevVertex(focusVert);
                break;
            }
            LinkedList<Edge> myEd = focusVert.getMyEdges();

            for (int i = 0; i < myEd.size(); i++) {
                if(!myEd.get(i).getTarget().beenVisited()) {

                    Edge myEdge = myEd.get(i);
                    Vertex tVertex = myEdge.getTarget();

                    tVertex.setPrevVertex(myEdge.getSource());
                    tVertex.setPrevEdge(myEdge);

                    myStack.push(tVertex);

                }
            }
        }
    }

    /**
     * Find the path from vertex with name s to vertex with name t, using BFS
     *
     * @param s the name of the starting vertex
     * @param t the name of the targeting vertex
     */
    public void BFS(String s, String t) {
    // TODO

    LinkedList<Vertex> myQueue = new LinkedList();
    resetAllVertices();

    Vertex startVertex = myVertices.get(s);
    Vertex endVertex = myVertices.get(t);

    startVertex.setPrevVertex(null);
    startVertex.setPrevEdge(null);

    myQueue.add(startVertex);

    while(!myQueue.isEmpty()){
        Vertex v = myQueue.remove();

        v.visitLocation();
        LinkedList<Edge> myEdges = v.getMyEdges();

        if(v.equals(endVertex)){
            break;
        }
        for(int i = 0; i< myEdges.size(); i++){
            if(!myEdges.get(i).getTarget().beenVisited()){

                Edge myEdge = myEdges.get(i);
                Vertex tVertex = myEdge.getTarget();

                // leave bread crumbs
                tVertex.setPrevVertex(v);
                tVertex.setPrevEdge(myEdge);

                //push into queue
                myQueue.add(tVertex);
                tVertex.visitLocation();
            }
        }
    }


    }

    /**
     * Helper class for Dijkstra and A*, used in priority queue
     */
    private class CostVertex implements Comparable<CostVertex> {
        double cost;
        Vertex vertex;

        public CostVertex(double cost, Vertex vertex) {
            this.cost = cost;
            this.vertex = vertex;
        }

        public int compareTo(CostVertex o) {
            return Double.compare(cost, o.cost);
        }
    }

    /**
     * Find the shortest path from vertex with name s to vertex with name t, using Dijkstra
     *
     * @param s the name of starting vertex
     * @param t the name of targeting vertex
     */
    public void Dijkstra(String s, String t) {
        //keep track of the distance, where it came from
        PriorityQueue<CostVertex> queue = new PriorityQueue<>();
        HashMap<Vertex, CostVertex> availableVertex = new HashMap<>();

        resetAllVertices();

        Vertex startVertex = myVertices.get(s);
        Vertex endVertex = myVertices.get(t);

        startVertex.setPrevVertex(null);
        startVertex.setPrevEdge(null);

        CostVertex startCV = new CostVertex(0, startVertex);

        //start vertex in the queue has a cost of 0
        queue.add(startCV);
        availableVertex.put(startVertex, startCV);

        while(!queue.isEmpty()) {

            // remove the shortest cost from priority queue
            CostVertex myCentral = queue.poll();

            // if this element is my vertex i exit.
            if(myCentral.vertex.equals(endVertex)){
                break;
            }

            // get the edges that the vertex points towards
            LinkedList<Edge> myEd = myCentral.vertex.getMyEdges();

            // for each of the edges i calculate the distance
            // cost to the other node
            for (int i = 0; i < myEd.size(); i++) {

                Edge focusEd = myEd.get(i);

                Vertex sVertex = focusEd.getSource();
                Vertex tVertex = focusEd.getTarget();

                sVertex.visitLocation();

                if(!tVertex.beenVisited()) {
                    double polledCost = myCentral.cost;
                    double edgeCost = focusEd.getDistance();

                    //if the new cost is less than the target distance
                    // then you want to update it.
                    double newCost = polledCost + edgeCost;

                    // new calculated cost
                    CostVertex newCalculatedVertex = new CostVertex(newCost, tVertex);

                    // if there is already this vertex in the queue
                    if(availableVertex.containsKey(tVertex)){
                        CostVertex oldV = availableVertex.get(tVertex);
                        double oldVCost = oldV.cost;

                        // if the new cost is less than the old cost
                        if(newCalculatedVertex.cost < oldVCost){
                            tVertex.setPrevEdge(focusEd);
                            tVertex.setPrevVertex(myCentral.vertex);

                            queue.add(newCalculatedVertex);

                            availableVertex.remove(tVertex);
                            availableVertex.put(tVertex, newCalculatedVertex);
                        }
                    }
                    // if this is the first time this vertex is being entered
                    else{
                        tVertex.setPrevEdge(focusEd);
                        tVertex.setPrevVertex(myCentral.vertex);

                        availableVertex.put(tVertex, newCalculatedVertex);

                        queue.remove(tVertex);
                        queue.add(newCalculatedVertex);
                    }
                }
            }
        }
    }

    /**
     * Helper method to calculate the h value in A*
     *
     * @param cur the current vertex being explored
     * @param goal the goal vertex to reach
     * @return the h value of cur and goal vertices
     */
    private double hValue(String cur, String goal) {

        // TODO
        Vertex startVertex = myVertices.get(cur);
        Vertex endVertex = myVertices.get(goal);

        double ux = startVertex.getX();
        double uy = startVertex.getY();
        double vx = endVertex.getX();
        double vy = endVertex.getY();

        return computeEuclideanDistance(ux, uy, vx, vy);
    }

    /**
     * Find the path from vertex with name s to vertex with name t, using A*
     *
     * @param s the name of starting vertex
     * @param t the name of targeting vertex
     */
    public void AStar(String s, String t) {
        //keep track of heuristic costs as well
        // TODO
        PriorityQueue<CostVertex> queue = new PriorityQueue<>();
        HashMap<Vertex, CostVertex> availableVertex = new HashMap<>();

        resetAllVertices();

        Vertex startVertex = myVertices.get(s);
        Vertex endVertex = myVertices.get(t);

        startVertex.setPrevVertex(null);
        startVertex.setPrevEdge(null);

        startVertex.currentCost = 0;
        startVertex.currentHCost = hValue(s,t);
        startVertex.f = hValue(s,t);

        CostVertex startCV = new CostVertex(0, startVertex);

        //start vertex in the queue has a cost of 0
        queue.add(startCV);
        availableVertex.put(startVertex, startCV);

        while(!queue.isEmpty()) {

            // remove the shortest cost from priority queue
            CostVertex myCentral = queue.poll();

            // if this element is my vertex i exit.
            if(myCentral.vertex.equals(endVertex)){
                break;
            }

            // get the edges that the vertex points towards
            LinkedList<Edge> myEd = myCentral.vertex.getMyEdges();

            // for each of the edges i calculate the distance cost to the other node
            for (int i = 0; i < myEd.size(); i++) {

                // MAKE SURE TO REMEMBER TO CHECK IF VISITED???

                Edge focusEd = myEd.get(i);

                Vertex sVertex = focusEd.getSource();
                Vertex tVertex = focusEd.getTarget();

                sVertex.visitLocation();

                if(!tVertex.beenVisited()) {
                    double vectorHvalue = hValue(focusEd.getTarget().getName(), t);
                    double edgeCost = focusEd.getDistance();

                    focusEd.getTarget().f = vectorHvalue + edgeCost;

                    //if the new cost is less than the target
                    // distance then you want to update it.
                    double newCost = myCentral.vertex.currentCost + edgeCost;
                    double hValue = newCost + vectorHvalue;

                    // new calculated cost

                    // if there is already this vertex in the queue
                    if(availableVertex.containsKey(tVertex)){

                        // if the new cost is less than the old cost
                        if(newCost < tVertex.currentCost){
                            tVertex.setPrevEdge(focusEd);
                            tVertex.setPrevVertex(myCentral.vertex);

                            tVertex.currentCost = newCost;

                            tVertex.currentHCost = hValue;

                            tVertex.f = newCost;

                            CostVertex newCalculatedVertex = new CostVertex(hValue, tVertex);

                            queue.add(newCalculatedVertex);

                            availableVertex.remove(tVertex);
                            availableVertex.put(tVertex, newCalculatedVertex);
                        }
                    }
                    // if this is the first time this vertex is being entered
                    else{
                        tVertex.setPrevEdge(focusEd);
                        tVertex.setPrevVertex(myCentral.vertex);

                        tVertex.currentCost = newCost;

                        tVertex.currentHCost = hValue;

                        CostVertex newCalculatedVertex = new CostVertex(hValue, tVertex);

                        availableVertex.put(tVertex, newCalculatedVertex);

                        queue.remove(tVertex);
                        queue.add(newCalculatedVertex);
                    }

                }
            }
        }
    }

    /**
     * Returns a list of edges for a path from city s to city t.
     *
     * @param s starting city name
     * @param t ending city name
     * @return list of edges from s to t
     */
    public List<Edge> getPath(String s, String t) {

        // TODO
        Stack<Vertex> myPathReverse = new Stack<>();
        Stack<Edge> myEdgeReverse = new Stack<>();

        Vertex iteratorVertex = myVertices.get(t);

        while(iteratorVertex.getPrevVertex() != null){
            Vertex currentVertex = iteratorVertex;
            Vertex previousVertex = iteratorVertex.getPrevVertex();
            Edge connection =
                    new Edge(previousVertex,currentVertex, 0);

            myPathReverse.add(previousVertex);
            myEdgeReverse.add(connection);
            iteratorVertex = iteratorVertex.getPrevVertex();
        }

        //System.out.println("length: " + myPathReverse.size());
        LinkedList<Vertex> myPathVertex = new LinkedList<>();
        LinkedList<Edge> myPathEdge = new LinkedList<>();

        while(!myPathReverse.isEmpty()){
            myPathVertex.add(myPathReverse.pop());
            myPathEdge.add(myEdgeReverse.pop());
        }
        return myPathEdge;
    }

}
