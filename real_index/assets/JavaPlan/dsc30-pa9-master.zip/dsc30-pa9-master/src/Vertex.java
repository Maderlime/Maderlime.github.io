/**
 * Madeline Tjoa
 * A15394053
 * */

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Vertex class for the specific locations
 * */
public class Vertex {

    private final String name; // the name of this vertex
    private final int x; // the x coordinates of this vertex on map
    private final int y; // the y coordinates of this vertex on map

    // TODO: add additional instance variables to work with different graph traversal algorithm
    private boolean hasVisited;
    LinkedList<Edge> myEdges; //get whole linked list of edges
    LinkedList<Edge> incomingVertex;
    LinkedList<Edge> getNeighborVertex;

    Edge prevEdge;
    Vertex prevVertex;


    double currentCost;
    double currentHCost;
    double f;

    public Vertex(String name, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.hasVisited = false;
        this.myEdges = new LinkedList<Edge>();
        this.incomingVertex = new LinkedList<>();
        this.getNeighborVertex = new LinkedList<>();

        this.prevEdge = null;
        this.prevVertex = null;

        this.currentCost = 0;
        this.currentHCost = 0;
        this.f = 0;

    }

    public String getName() {
        return name;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }


    /**
     * true if its been visited, false if not
     * */
    public boolean beenVisited(){
        return hasVisited;
    }

    /**
     * return Edges LinkedList
     * */
    public LinkedList getMyEdges(){
        return this.myEdges;
    }
    public LinkedList getincomingVertex(){return  this.incomingVertex;}
    public Edge getPrevEdge(){ return this.prevEdge;}
    public Vertex getPrevVertex(){return this.prevVertex;}

    // TODO: add necessary getters and setters for ALL your instance variable

    public void visitLocation(){
        this.hasVisited = true;
    }
    public void unVisit(){this.hasVisited = false;}
    public void addConnection(Edge thisEd){
        this.myEdges.add(thisEd);
    }
    public void addincomingVertex(Edge from){this.incomingVertex.add(from);}

    public void setPrevEdge(Edge thisEd){this.prevEdge = thisEd;}
    public void setPrevVertex(Vertex thisVer){this.prevVertex = thisVer; }

    @Override
    public int hashCode() {
        // we assume that each vertex has a unique name
        return name.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (!(o instanceof Vertex)) {
            return false;
        }
        Vertex oVertex = (Vertex) o;

        return name.equals(oVertex.name) && x == oVertex.x && y == oVertex.y;
    }

    public String toString() {
        return name + " (" + x + ", " + y + ")";
    }

}