
import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.Arrays;
import java.awt.event.ActionEvent;

import java.io.*;
import java.sql.Array;
import java.text.*;


public class FML extends JApplet implements ActionListener{

	//declare our components or fields(global level variable)
		JTextField txtSubject = new JTextField(20);
		JTextField txtScoreAmt = new JTextField(20);

//Arrays
		DefineGrades Grades[] = new DefineGrades[3];
	
		JTextArea txaresult = new JTextArea(
				"Score" + "\n", 10,33);
	
		JButton btnAdd = new JButton("Add Test");
	
		//JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		double AverageGrade;
		double HighestGrade;
		double averageSpent;
		
		String soloGrade;
		String everyGrade;
		
		
	
	//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnAdd);
			pnlMain.add(pnlOutput);
			
			resize(500,400);
			txtSubject.requestFocus();
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnAdd.addActionListener(this);
			txtScoreAmt.addActionListener(this);
			
			
			
		}
		
		

		
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
		//1. get variables	
			String testString;
			String outputString;			
			String Score1Double;
		//2. information	
		try {
			testString = txtSubject.getText();	
			Score1Double = txtScoreAmt.getText();
			
			for (int i = 0; i <3; i++) {
				Grades[i] = new DefineGrades();
			}
			for (int j = 0; j<3;j++) {
				int xpos, ypos, xspeed,yspeed,life;
				String[] myArray = "Score1Double".split(" ");
				for(int i=0; i<Score1Double.length(); i++) { 
					Grades[i].IletterGrade = myArray[i]; 
					} 
				Grades[j].setGrades(0,"Apple");
				txaresult.setText("Name: " + myArray.toString());
			}
			
			
				
//3. Calculate 
			
			FMLCalculations ThePayClass = new FMLCalculations(Score1Double);
			String SingleString = ThePayClass.averageScore();
			
			/*
			double totalTestsTaken = ThePayClass.TestsTaken();
			double highestTestScore = ThePayClass.HighestScore();
			double singleGrade = ThePayClass.ElLetterGrade();
			double teamGrade = ThePayClass.CollectiveLetterGrade();
			
			FMLFormat theFormatClass = new FMLFormat(averageTestScore, totalTestsTaken, highestTestScore);
			double AaverageTestScore = theFormatClass.returnAverageScore();
			double AtotalTestsTaken = theFormatClass.returnTestsTaken();
			double AhighestTestScore = theFormatClass.returnHighestScore();
		
			
		//extra: connect to a format cclass	
			//String formattedDataString;
			
			//formattedDataString = fmtCurrency.format(payDouble);

			//String betterNumber = decFor.format(payDouble);
			
			//S
			if(singleGrade ==1) {
				soloGrade = "F";
			}
			else if(singleGrade ==2) {
				soloGrade = "D";
			}
			else if(singleGrade ==3) {
				soloGrade = "C";
			}
			else if(singleGrade ==4) {
				soloGrade = "B";
			}
			else if(singleGrade ==5) {
				soloGrade = "A";
			}
			//Collective Grade
			if(teamGrade ==1) {
				everyGrade = "F";
			}
			else if(teamGrade ==2) {
				everyGrade = "D";
			}
			else if(teamGrade ==3) {
				everyGrade = "C";
			}
			else if(teamGrade ==4) {
				everyGrade = "B";
			}
			else if(teamGrade ==5) {
				everyGrade = "A";
			}
			
					
			*/
		//4. output in the text Area
			for (int j = 0; j<3;j++) {
			//txaresult.setText("");
			}
			txtSubject.setText("");
			txtScoreAmt.setText("");

			
			
			txtScoreAmt.requestFocus();

			}
		catch(NumberFormatException err){
			
			showStatus("please make sure you've entered everything!");
		}
		}
		
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			
			pnlInput.add(new JLabel("Name of Subject: "));
				pnlInput.add(txtSubject);
			pnlInput.add(new JLabel("Score 1: "));
				pnlInput.add(txtScoreAmt);
				
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaresult);
			
		}
		
	
	
}

