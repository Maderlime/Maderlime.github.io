import java.text.DecimalFormat;

import javax.swing.ButtonGroup;
public class FMLFormat {

		private double averagee, totaltee, maxtee;
	FMLFormat(double avg, double tt, double mt){
		
		//theRate and theHours are the parameters for the method
				averagee = avg;
				totaltee = tt;
				maxtee = mt;
				
		
				CalculateCharge();
				
				
				
		}
	
	private void CalculateCharge() {
		
		DecimalFormat decFor = new DecimalFormat("0.###");
		String pof2 = decFor.format(averagee);
		String pof3 = decFor.format(totaltee);
		String pof4 = decFor.format(maxtee);

		
		double P2 =  Double.parseDouble(pof2); 
		double P3 =  Double.parseDouble(pof3);
		double P4 =  Double.parseDouble(pof4);

		
		averagee = P2;
		totaltee = P3;
		maxtee = P4;

		
	}
	
	public double returnAverageScore() {
		return averagee;	
	}	
	public double returnTestsTaken() {
			return totaltee;	
	}
	public double returnHighestScore() {
		return maxtee;	
}


	
	
}