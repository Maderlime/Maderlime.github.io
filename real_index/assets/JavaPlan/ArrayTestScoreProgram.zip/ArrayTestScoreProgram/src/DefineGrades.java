
public class DefineGrades {
	int IGradeScore;
	String IletterGrade;
	public void setGrades(/*foreign variables: */int x, String Acolor) {
		//set the domestic variables equal to the foreign variables	
		IGradeScore = x;
		IletterGrade = Acolor;		
	}
}
