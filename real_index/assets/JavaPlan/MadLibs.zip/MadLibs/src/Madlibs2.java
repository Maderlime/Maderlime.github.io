
public class Madlibs2 {

}
