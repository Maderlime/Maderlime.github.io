//Name: Madeline Tjoa
//Date: 9/5/17
/*
 * 
 * MadLibs
 * 
 */

import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MadLibs extends JApplet implements ActionListener{

	// name, place, animal, verb, verb + ed, adjective +ly, verb, time, animal, verb+ed
	
	//declare our components or fields(global level variable)
		JTextField txtName = new JTextField(20);
		JTextField txtPlace = new JTextField(20);
		JTextField txtAnimal = new JTextField(5);
		JTextField txtVerb = new JTextField(20);
		JTextField txtVerb2 = new JTextField(20);
		JTextField txtAdjective = new JTextField(5);
		JTextField txtVerb3 = new JTextField(20);
		JTextField txtTime = new JTextField(20);
		JTextField txtAnimal2 = new JTextField(5);
		JTextField txtVerb4 = new JTextField(20);
		
	
		JTextArea txaExplanation = new JTextArea(
				"Story Appears here" + "\n", 10,40);
	
		JButton btnSubmit = new JButton("Make My Story!");
	
		JPanel pnlPanel = new JPanel();
		JPanel pnlMain = new JPanel();
		JPanel pnlInput = new JPanel();
		JPanel pnlOutput = new JPanel();
	
		//declare string variables
			String placeString;
			String nameString;
			String animalString;
			String verbString;
			String verb2String;
			String adjectiveString;
			String verb3String;
			String timeString;
			String animal2String;
			String verb4String;
			
	
	//Create the init method(initialize method)
		public void init() {
			
			//place components on the applet panel(Declaring method/functions that will be called)
			DesignInputPanel();
			DesignOutputPanel();
			
			pnlMain.add(pnlInput);
			pnlMain.add(btnSubmit);
			pnlMain.add(pnlOutput);
			
			resize(700,600);
			txtName.requestFocus();
			//set the content to the panel (or else it wont show up)
			setContentPane(pnlMain);
			btnSubmit.addActionListener(this);
			txtName.addActionListener(this);
			txtPlace.addActionListener(this);
			txtAnimal.addActionListener(this);
			txtVerb.addActionListener(this);
			txtVerb2.addActionListener(this);
			txtAdjective.addActionListener(this);
			txtVerb3.addActionListener(this);
			txtTime.addActionListener(this);
			txtAnimal2.addActionListener(this);
			txtVerb4.addActionListener(this);
			
			
		}
	//when you put the button it comes to this function
		public void actionPerformed(ActionEvent event) {
			
			
			
			String outputString;
			nameString = txtName.getText();
			placeString =txtPlace.getText();
			animalString = txtAnimal.getText();
			verbString = txtVerb.getText();
			verb2String =txtVerb2.getText();
			adjectiveString = txtAdjective.getText();
			verb3String = txtVerb3.getText();
			timeString =txtTime.getText();
			animal2String = txtAnimal2.getText();
			verb4String = txtVerb4.getText();
			
			
			outputString = "Once there was a guy named " + nameString + ", and he loved to go to \n" 
							+ placeString + ". \n One Day, while  " + nameString+ " was at " + placeString
							+ ", he saw a weird \n  " + animalString + " ghost floating out from under him. \n He tried to "
							+ verbString + " it, however it " + verb2String+ " away " + adjectiveString + ".\n "
							+ nameString + " decided to " + verb3String + " home and come back the next day. \n the next day, "
									+ " at " + timeString + ", " + nameString + " came back to " + placeString + " and sure enough, \n he "
									+ " saw the " + animalString+ "! This time, the " + animalString + "brought a \n" + animal2String
									+ " with it, \n and then they both " + verb4String + " him and then floated away. \n " + nameString + " never saw the ghosts again.";
			
			//new output String
			//Once there was a guy named (Insert name), and he loved to go to (insert place). One Day while (name) was at (same place)
			//he saw a weird (insert animal) ghost floating out from under him.
			//He tried to (insert action) it, however it (insert different action + ed) away (adjective + ly).
			//(insert name) decided to (verb) home and come back the next day.
			// The next day, at (insert time), (name) came back to (place) and sure enough, he saw the (animal)!
			//this time, the (animal) brought a (different animal) with it, and then they both (verb + ed) him and then floated away.
			//(name) never saw the ghosts again.
			
			
			// name, place, animal, verb, verb + ed, adjective +ly, verb, time, animal, verb+ed
			
			//output in the text Area
			txaExplanation.append(outputString + "\n");
			txtName.setText("");
			txtPlace.setText("");
			txtAnimal.setText("");
			txtVerb.setText("");
			txtVerb2.setText("");
			txtAdjective.setText("");
			txtVerb3.setText("");
			txtTime.setText("");
			txtAnimal2.setText("");
			txtVerb4.setText("");
			txtName.requestFocus();
			
		}
		
		
	//Create DesignnputPanel()
		public void DesignInputPanel() {
			pnlInput.setLayout(new GridLayout(0,2));
			
			
			
			pnlInput.add(new JLabel("Name: "));
				pnlInput.add(txtName);
			pnlInput.add(new JLabel("Place: "));
				pnlInput.add(txtPlace);
			pnlInput.add(new JLabel("Animal: "));
				pnlInput.add(txtAnimal);	
			pnlInput.add(new JLabel("Verb: "));
				pnlInput.add(txtVerb);
			pnlInput.add(new JLabel("Verb + ed: "));
				pnlInput.add(txtVerb2);
			pnlInput.add(new JLabel("Adjective + ly: "));
				pnlInput.add(txtAdjective);	
			pnlInput.add(new JLabel("Verb: "));
				pnlInput.add(txtVerb3);
			pnlInput.add(new JLabel("Time: "));
				pnlInput.add(txtTime);
			pnlInput.add(new JLabel("Animal: "));
				pnlInput.add(txtAnimal2);	
			pnlInput.add(new JLabel("Verb + ed: "));
				pnlInput.add(txtVerb4);
				
		}
		
		public void DesignOutputPanel() {
			pnlOutput.setLayout(new GridLayout(0,1));
			pnlOutput.add(txaExplanation);
			
		}
		
	
	
}
