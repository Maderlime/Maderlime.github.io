
public class DefineDimensions {
	char IStringLength;
	//String IStringText;
	public void setDimensions(char x) {
		//set the domestic variables equal to the foreign variables	
		IStringLength = x;
		//IStringText = SText;		
	}
}
