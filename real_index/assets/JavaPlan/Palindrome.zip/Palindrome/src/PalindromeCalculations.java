
public class PalindromeCalculations {
	String text;
	String theChosenOne;
	char[] cArray;
	
	int yes,no;
	int highestArraySize;
	
	
	PalindromeCalculations(String importedtext){
		text = importedtext;
		
		Calculations();
		
	}
	
	private void Calculations(){
		int palStringLength = text.length();
		int arrayRunTime = palStringLength/2;
		int highestArraySize = palStringLength -1;
		
		cArray = text.toCharArray();
		
		
		for (int i = 0; i < arrayRunTime ; i++) {
			try {
				
			if(cArray[i] == cArray[highestArraySize-i]) {
				yes ++;
			}
			else {
				no++;
				}	
			}
			catch(Exception e){
				theChosenOne = "uh";
			}	
		}	
		
		if(no>0) {
			theChosenOne = "no";
		}
		else {
			theChosenOne = "yes";
		}
	
		
		
		
	}
	
	public String TheReturner(){
		return theChosenOne;
		
	}
}
