import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.util.Arrays;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class palindrome extends JApplet implements ActionListener{

	//Application Designs
			//create text boxes
			JTextField txtInputString = new JTextField(20);
			
			JTextField txtScore1 = new JTextField(20);
			//create text areas
			JTextArea txaresult = new JTextArea("\n", 30,30);
			
			
			JScrollPane scrolly = new JScrollPane(txaresult, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			
			//create text buttons
			JButton btnSetRow = new JButton("Set Row Array");
			//create panels
			JPanel pnlMain = new JPanel();
			JPanel pnlInput = new JPanel();
			JPanel pnlOutput = new JPanel();	
		//end of application designs	
			
		
		DefineDimensions cArray[]; // Create an array for DefineDimensions

		char[] secondArray;
		
		int palStringLength;
		
		int yes,no;
		
		String text;
		
		String rank = "";
		String averageTestScore;

	//Create the init method(initialize method)
	public void init() {

			//Applet Design Initialization: 
					//place components on the applet panel(Declaring method/functions that will be called)
						DesignInputPanel();
						DesignOutputPanel();
					//put the panels and buttons and stuff on the applet
						pnlMain.add(pnlInput);	
						pnlMain.add(btnSetRow);
						pnlMain.add(pnlOutput);	
					//resize the applet
						resize(500,400);
					txtInputString.requestFocus();
					//set the content to the panel (or else it wont show up)
						setContentPane(pnlMain);
			//Action listeners
					
					btnSetRow.addActionListener(this);
					txtInputString.addActionListener(this);
					

	}		
	//when you put the button it comes to this function
	public void actionPerformed(ActionEvent event) {
		
			//2. information	
			try {
			
			//Code so that the buttons will work: 
				Object objSource = event.getSource();		/*Find the source of the action trigger*/
				
				if(objSource == btnSetRow) {
					
					txaresult.setText("");
					no = 0;
					yes = 0;
					
					String text = txtInputString.getText();
					
							/*Grab the string the user inputed and place into arrayNumber*/
					
					//btnSetRow.setEnabled(false); /*disable btnSetRow so user cannot reset the array size*/
					
					//Strings = new DefineDimensions[palStringLength]; 	/*Set arrayNumber as the amt of slots for String Array*/
					   
					text = text.replaceAll("\\s","");
					text = text.toLowerCase();
					palStringLength = text.length();
					char[] cArray = text.toCharArray();
					//secondArray = text.toCharArray();
					
					StringBuilder sb=new StringBuilder();
					for(int j=0;j< cArray.length;j++)
					{
					   sb.append(cArray[j]);	  
					}
				
					int arrayRunTime = palStringLength/2;
					int highestArraySize = palStringLength -1;
					//fill up one slot
							PalindromeCalculations ThePayClass = new PalindromeCalculations(text);
							//retreive calculations from the calculations class
							 averageTestScore = ThePayClass.TheReturner();
					
					txaresult.append("the word: " + sb + " is it? " + averageTestScore + "\n");
					
					//txaresult.append("boop" + sb + " is it? " + rank);
					
				}	
						
			}
			catch(NumberFormatException err){			
			showStatus("please make sure you've entered everything!");
			}

	}				
	//Create DesignnputPanel()
	public void DesignInputPanel() {
	pnlInput.setLayout(new GridLayout(0,2));
	pnlInput.add(new JLabel("Row : "));
	pnlInput.add(txtInputString);
	

	}		
	public void DesignOutputPanel() {
	pnlOutput.setLayout(new GridLayout(0,1));
	pnlOutput.add(scrolly);
	//pnlOutput.add(txaHarpoon);
	}
}
