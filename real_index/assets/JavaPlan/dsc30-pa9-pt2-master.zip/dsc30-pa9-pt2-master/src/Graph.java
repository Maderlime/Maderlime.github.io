import java.util.*;

/*
 * Madeline Tjoa
 * A15394053
 */
/**
 * Graph class for part 2 of the pa
 * */
public class Graph {

    private static final int EUCLIDIAN_FACTOR = 2;

    // TODO: define a data structure to store all the vertices with fast access

    public HashMap<String, Vertex> myGraphHashMap;
    public HashMap<Vertex, Edge> myVertices;

    private ArrayList<Edge> allUndirectedEdges;
    private ArrayList<Edge> resultMST;
    private boolean edgesGiven;

    /**
     * Constructor for Graph
     * @param edgesGiven determines what methods will be enabled
     */
    public Graph(boolean edgesGiven) {
        
        // TODO
        this.allUndirectedEdges = new ArrayList<>();
        this.resultMST = new ArrayList<>();
        this.edgesGiven = edgesGiven;
        this.myGraphHashMap = new HashMap();

    }

    /**
     * Adds a vertex to the graph. Throws IllegalArgumentException if given vertex
     * already exist in the graph.
     *
     * @param v vertex to be added to the graph
     * @throws IllegalArgumentException if two vertices with the same name are added.
     */
    public void addVertex(Vertex v) throws IllegalArgumentException {
        
        // TODO
        if(myGraphHashMap.containsKey(v)){
            throw new IllegalArgumentException("myGraphHashMap already contains v");
        }
        myGraphHashMap.put(v.getName(), v);

    }

    /**
     * Gets a collection of all the vertices in the graph
     *
     * @return collection of all the vertices in the graph
     */
    public Collection<Vertex> getVertices() {
        // TODO
        return myGraphHashMap.values();
    }

    /**
     * Adds a directed edge from vertex u to vertex v, Throws IllegalArgumentException if one of
     * the vertex does not exist. If edgesGiven is false, directly return at first.
     *
     * @param nameU name of vertex u
     * @param nameV name of vertex v
     * @param weight weight of the edge between vertex u and v
     * @throws IllegalArgumentException if one of the vertex does not exist
     */
    public void addEdge(String nameU, String nameV, Double weight)
            throws IllegalArgumentException {
        
        // TODO
        if(!edgesGiven){
            return;
        }
        if(!myGraphHashMap.containsKey(nameU)
                || !myGraphHashMap.containsKey(nameV)){
            throw new IllegalArgumentException("error in addEdge " +
                    "does not contain one of these values");
        }
        Edge newEdge = new Edge(myGraphHashMap.get(nameU),
                myGraphHashMap.get(nameV), weight);
        (myGraphHashMap.get(nameU)).addTargetEdge(newEdge);
    }

    /**
     * Adds an undirected edge between vertex u and vertex v by adding a directed
     * edge from u to v, then a directed edge from v to u. Then updates the allUndirectedEdges.
     * If edgesGiven is false, directly return at first.
     *
     * @param nameU name of vertex u
     * @param nameV name of vertex v
     * @param weight  weight of the edge between vertex u and v
     */
    public void addUndirectedEdge(String nameU, String nameV, double weight) {
        
        // TODO
        if(!edgesGiven){
            return;
        }
        addEdge(nameU, nameV, weight);
        addEdge(nameV, nameU, weight);
        allUndirectedEdges.add(
                new Edge(myGraphHashMap.get(nameU), myGraphHashMap.get(nameV), weight));

    }

    /**
     * Computes the euclidean distance between two points as described by their
     * coordinates
     *
     * @param ux (double) x coordinate of point u
     * @param uy (double) y coordinate of point u
     * @param vx (double) x coordinate of point v
     * @param vy (double) y coordinate of point v
     * @return (double) distance between the two points
     */
    public double computeEuclideanDistance(double ux, double uy, double vx, double vy) {

        // TODO DONE
        double tempx = vx - ux;
        double tempy = vy - uy;
        tempx = Math.pow(tempx, EUCLIDIAN_FACTOR);
        tempy = Math.pow(tempy, EUCLIDIAN_FACTOR);
        double distance = Math.sqrt(tempx + tempy);
        return distance;
    }

    /**
     * Calculates the euclidean distance for all edges in the graph and all edges in 
     * allUndirectedEdges. If edgesGiven is false, directly return at first.
     */
    public void computeAllEuclideanDistances() {
        
        // TODO
        if(!edgesGiven){
            return;
        }
        Collection<Vertex> vCollection = getVertices();
        Vertex[] myVerticesLL = vCollection.toArray(new Vertex[vCollection.size()]);

        for(int i = 0; i< myVerticesLL.length; i++){
            LinkedList<Edge> vEdges = myVerticesLL[i].getMyTargetEdges();
            for(int j = 0; j< vEdges.size(); j++){

                Edge littleEd = vEdges.get(j);

                Vertex lilSource = littleEd.getSource();
                Vertex lilTarget = littleEd.getTarget();

                double ux = lilSource.getX();
                double uy = lilSource.getY();
                double vx = lilTarget.getX();
                double vy = lilTarget.getY();

                double euclidead = computeEuclideanDistance(ux, uy, vx, vy);
                littleEd.setDistance(euclidead);
            }
        }

        for(int i = 0; i< allUndirectedEdges.size(); i++){
            Edge myEd = allUndirectedEdges.get(i);
            Vertex lilSource = myEd.getSource();
            Vertex lilTarget = myEd.getTarget();
            double ux = lilSource.getX();
            double uy = lilSource.getY();
            double vx = lilTarget.getX();
            double vy = lilTarget.getY();

            double euclidead = computeEuclideanDistance(ux, uy, vx, vy);
            myEd.setDistance(euclidead);
        }

    }

    /**
     * Populate all possible edges from all vertices in the graph. Only works when edgesGiven 
     * is false. If edgesGiven is true, directly return at first.
     *
     * In populateAllEdges(), you should add all the possible n(n -1) / 2 undirected edges
     * with weight as Euclidean Distance to allUndirectedEdges in a graph with n vertices.
     * (You don’t need to add these edges to the adjacent list of any vertex here.)
     *
     * You need to think about how to add exactly n(n -1) / 2 undirected
     * edges without adding any duplicate undirected edges.
     * (i.e if undirected edge from u to v was added,
     * then undirected edge from v to u should not be added)
     *
     * Hint: Consider using the following code to convert your vertices
     * collection to an array of vertex, which provides easier access
     * to each vertex in your graph.
     *
     */
    public void populateAllEdges() {
        Collection<Vertex> vCollection = getVertices();
        Vertex[] vertices = vCollection.toArray(new Vertex[vCollection.size()]);

        // TODO
        if(edgesGiven){
            return;
        }
        for(int i = 0; i< vertices.length; i++){

            LinkedList<Edge> Edges = vertices[i].getMyTargetEdges();
            for(int j = i+1; j< vertices.length; j++){
                Vertex mySource = vertices[i];
                Vertex myEdge = vertices[j];

                double euclideanDeistan =computeEuclideanDistance(
                        mySource.getX(), mySource.getY(), myEdge.getX(), myEdge.getY());
                Edge createdEdge = new Edge(mySource, myEdge, euclideanDeistan);
                allUndirectedEdges.add(createdEdge);
            }
        }
    }

    /**
     * To save us from recomputing the same result,
     * if the result was already computed before, directly return the result at first.
     * Use the code below to sort allUndirectedEdges in increasing order of weight:
     * Collections.sort(allUndirectedEdges, Comparator.comparingDouble(e -> e.getDistance()));
     * Assume that there are v vertices in your graph and all the vertices are in the
     * same connected component, notice that when your result contains v - 1 edges,
     * the MST of this graph should already be defined by these edges.
     * The reason is knowing that the graph is connected and there is no cycle in the MST
     * (since MST is a tree) implies that there are  v - 1 edges in the MST. Using this property,
     * think about how you can slightly improve the runtime of Kruskal’s Algorithm.
     *
     * @return completed mstTree
     */
    public ArrayList<Edge> runKruskalsAlg() {
        // TODO
        // sort allUndirectedEdges in increasing order of weight
        Collections.sort(allUndirectedEdges, Comparator.comparingDouble(e -> e.getDistance()));

        DisjointSet ds = new DisjointSet();

        //loop thought the allundirectededges size-1
        for(int i = 0; i< allUndirectedEdges.size() - 1; i++){

            // get the edges in the arraylist,
            Edge focusEdge = allUndirectedEdges.get(i);

            // find the vertex for each one, perform find on each edge
            Vertex find1 = ds.find(focusEdge.getSource());
            Vertex find2 = ds.find(focusEdge.getTarget());

            //if the find produces different results, untion the two verteices
            if(!find1.equals(find2)){
                ds.union(find1, find2);

                //add the edge to the result mst
                resultMST.add(focusEdge);
            }

            //if resultmst is equal to mapsize -1 break;
            if(resultMST.size() == myGraphHashMap.size() - 1){
                break;
            }
        }
        return resultMST;
    }
}
