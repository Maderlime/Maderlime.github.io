/**
 * Madeline Tjoa
 * A15394053
 *
 */

/**
 *
 * class for disjointset that contains methods find and union
 *
 * */
public class DisjointSet {

    /**
     * Returns the “sentinel node” representing the set that this vertex belongs to.
     * You must apply path compression here to optimize the runtime.
     *
     * @param v the vertex that is being looked
     * */
    public Vertex find(Vertex v) {
        
        // TODO
        while(v.getParentVertex() != null){
                v = v.getParentVertex();
        }
        return v;
    }

    /**
     * Merges the two sets that two given vertices belongs to.
     * If two given vertices belongs to the same set, return.
     * Otherwise, apply union by size: make the “sentinel node”
     * of smaller set as child of “sentinel node” of larger set.
     *
     * (The union operation here can be done using either union
     * by height or union by size.
     * The choice here is up to you, but we suggest using union by
     * size here as it is slightly easier to implement. )
     * */
    public void union(Vertex v1, Vertex v2) {

        // TODO
        Vertex xRoot = find(v1);
        Vertex yRoot = find(v2);

        //if x and y are already in the same set
        if(xRoot.equals(yRoot)){
            return;
        }
        // compare the ranks of the nodes
        if(xRoot.getRank() < yRoot.getRank()){
            xRoot.setParentVertex(yRoot);
            xRoot.setRank(xRoot.getRank() + yRoot.getRank());
        }
        else if(yRoot.getRank() < xRoot.getRank()){
            yRoot.setParentVertex(xRoot);
            yRoot.setRank(yRoot.getRank() + xRoot.getRank());
        }
        else{
            xRoot.setParentVertex(yRoot);
            yRoot.setRank(yRoot.getRank() + xRoot.getRank());
        }
    }
}
