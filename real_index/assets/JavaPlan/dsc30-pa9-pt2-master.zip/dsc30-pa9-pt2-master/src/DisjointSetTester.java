import static org.junit.Assert.*;
/**
 * Madeline Tjoa
 * A15394053
 */
/**
 * Testing class for DisjointSet testing union and find
 * */
public class DisjointSetTester {

    DisjointSet myDS;
    Vertex v1;
    Vertex v2;
    Vertex v3;
    Vertex v4;
    Vertex v5;
    Vertex v6;
    Vertex v7;

    @org.junit.Before
    public void setUp() throws Exception {

        myDS = new DisjointSet();
        v1 = new Vertex("g",4,5);
        v2 = new Vertex("q",3,3);
        v3 = new Vertex("w",5,6);
        v4 = new Vertex("e",8,3);
        v5 = new Vertex("r",9,11);
        v6 = new Vertex("t",14,23);
        v7 = new Vertex("y",44,13);

    }

    @org.junit.Test
    public void find() {
        //1. After you union a set of vertices, calling
        // find on each of them should return the same sentinel node.
        assertEquals(v2, myDS.find(v2));

        myDS.union(v1, v2);
        assertEquals(v2, myDS.find(v2));
        assertEquals(v2, myDS.find(v1));

        myDS.union(v1, v4);
        assertEquals(v2, myDS.find(v2));
        assertEquals(v2, myDS.find(v4));
    }

    @org.junit.Test
    public void union() {

        myDS.union(v1, v5);
        myDS.union(v1, v4);
        myDS.union(v1, v3);

        myDS.union(v2, v6);
        assertNotEquals(myDS.find(v2), myDS.find(v1));
        assertEquals(myDS.find(v2), myDS.find(v6));
        assertEquals(myDS.find(v1), myDS.find(v5));

    }
}