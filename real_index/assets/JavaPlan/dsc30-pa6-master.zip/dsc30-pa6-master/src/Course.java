import java.util.ArrayList;
import java.util.List;
/**
 * Madeline Tjoa
 * A15394053
 * */

/**
 * holds all the information about a course.
 * */
public class Course implements Course_Interface {

	private String courseName;
	private String courseCode;
	private MyPriorityQueue<Registration> waitlistQueue;
	private List<Student> roster;
	private int maxCapacity;

	public Course(String name, String code, int capacity) {
		this.courseName = name;
		this.courseCode = code;
		this.maxCapacity = capacity;
		this.waitlistQueue = new MyPriorityQueue<>(this.maxCapacity);
		this.roster = new ArrayList<>();

	}

	@Override
	public String toString() {
		return courseCode;
	}

	/**
	 * Accessor for course name
	 *
	 * @return course name
	 */
	@Override
	public String getCourseName() {
		return this.courseName;
	}

	/**
	 * Accessor for course code
	 *
	 * @return course code
	 */
	@Override
	public String getCourseCode() {
		return this.courseCode;
	}

	/**
	 * Accessor for course capacity
	 *
	 * @return course capacity
	 */
	@Override
	public int getCourseCapacity() {
		return this.maxCapacity;
	}

	/**
	 * Accessor for Course Roster
	 *
	 * @return course roster
	 */
	@Override
	public List<Student> getCourseRoster() {
		return this.roster;
	}

	/**
	 * Checks whether the course enrollment has reached its capacity
	 *
	 * @return Returns true if the number of enrolled students is equal to
	 * capacity, false otherwise
	 */
	@Override
	public boolean isFull() {
		if(this.getCourseRoster().size() == this.getCourseCapacity()){
			return true;
		}
		return false;
	}

	/**
	 * Enqueues the student to the waitlist for this course
	 *
	 * @param r Registration to be waitlisted
	 */
	@Override
	public void addToWaitlist(Registration r) {

		r.setTimestamp();
		//populate this student's waitlist classes
		r.getStudent().waitlistCourse(this);
									//time stamp?
		waitlistQueue.offer(r);
	}

	/**
	 * Enrolls the next student in the waitlist to the course. Does nothing if
	 * the waitlist is empty
	 *
	 * @return Registration Request that was processed
	 */
	@Override
	public Registration processWaitlist() {
		if(waitlistQueue.peek() != null){
			//make sure there is room in the roster
			if(isFull()){
				return null;
			}

			Registration nextInLine = waitlistQueue.poll();

			//remove their wait list and add it
			nextInLine.getStudent().getmyWaitlist().remove(this);
			nextInLine.getStudent().getmyEnrolledCourses().add(this);

			this.roster.add(nextInLine.getStudent());

			return nextInLine;
		}

		return null;
	}
}
