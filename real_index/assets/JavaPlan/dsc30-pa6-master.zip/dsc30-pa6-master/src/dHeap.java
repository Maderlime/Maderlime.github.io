import java.util.*;
/**
 * Name: Madeline Tjoa
 * PID: A15394053
 * */

/**
 *
 * a d-ary heap that will be used to represent a priority queue.
 *
 * d-ary heap is a heap with branching factor d
 *
 * */
public class dHeap<T extends Comparable<? super T>>
        implements dHeapInterface<T> {

    private T[] heap; //heap array
    private int d; //branching factor
    private int nelems;
    private boolean isMaxHeap; //boolean to indicate whether heap is max or min

    // magic numbors
    private static final int DEFAULT_SIZE = 5;
    private static final int DEFAULT_D = 2;
    private static final int CAPACITY_INCREASER = 2;

    /**
     * Initializes a binary max heap with capacity = 5
     */
    public dHeap() {
        this.heap = (T[]) new Comparable[DEFAULT_SIZE];
        this.nelems = 0;
        this.isMaxHeap = true;
        this.d = DEFAULT_D;
    }

    /**
     * Initializes a binary max heap with a given initial capacity.
     *
     * @param heapSize The initial capacity of the heap.
     */
    public dHeap(int heapSize) {
        this.heap = (T[]) new Comparable[heapSize];
        this.nelems = 0;
        this.isMaxHeap = true;
        this.d = DEFAULT_D;
    }

    /**
     * Initializes a d-ary heap (with a given value for d), with a given initial
     * capacity.
     *
     * @param d The number of child nodes each node in the heap should have.
     * @param heapSize The initial capacity of the heap.
     * @param isMaxHeap indicates whether the heap should be max or min
     * @throws IllegalArgumentException if d is less than one.
     */
    @SuppressWarnings("unchecked")
    public dHeap(int d, int heapSize, boolean isMaxHeap)
            throws IllegalArgumentException {
        if(d < 1){
            throw new IllegalArgumentException("d cannot be less than 1");
        }
        if(heapSize < 0){
            throw new IllegalArgumentException("heapSize cannot be negative!");
        }
        this.heap = (T[]) new Comparable[heapSize];
        this.nelems = 0;
        this.isMaxHeap = isMaxHeap;
        this.d = d;
    }

    /**
     * Returns the number of elements stored in the heap.
     *
     * @return The number of elements stored in the heap.
     */
    @Override
    public int size() {
        return this.nelems;
    }

    /**
     * Adds the specified element to the heap;
     * data cannot be null.
     * Resizes the storage if full.
     *
     * @param data The element to add.
     * @throws NullPointerException if o is null.
     */
    @Override
    public void add(T data) throws NullPointerException {
        // first make sure that the data is not null
        if(data == null){
            throw new NullPointerException("data added to add() is null!");
        }
        // check that there is enough space to add an element,
        // if not then increase the capacity
        if(this.size() >= this.heap.length){
            resize();
        }

        //insert the node into the tree's last level
        // ( make sure it is left to right and filled before adding another level)
        int lastLevelIndex = this.size();

        this.heap[lastLevelIndex] = data;

        //swap the node with its parent until no max-heap property violation occurs (going from the bottom of the tree to the top
        bubbleUp(lastLevelIndex);
        nelems ++;
    }

    /**
     * Removes and returns the element at the root. If the heap is empty, then
     * this method throws a NoSuchElementException.
     *
     * @return The element at the root stored in the heap.
     * @throws NoSuchElementException if the heap is empty
     */
    @Override
    public T remove() throws NoSuchElementException {
        // make sure that there is something to remove
        if(this.size() < 1){
            throw new NoSuchElementException("There is no element to remove!");
        }

        //replace the root with the last level's last node
        int lastLevelIndex = this.size() - 1;

        T removedNode = this.element(); // value of the removed node

        // removing node and replacing it with the smallest element
        this.heap[0] = this.heap[lastLevelIndex];
        this.heap[lastLevelIndex] = null;
        this.nelems --;

        // and swap the node with its greater child until no max heap property violation occurs.
        trickleDown(0);
        //bubbleUp(lastLevelIndex - 1);

        return removedNode;
    }

    /**
     * Clears all the items in the heap Heap will be empty after this call
     * returns
     */
    @Override
    public void clear() {
        for(int i = 0; i < this.heap.length; i++){
            this.heap[i] = null;
        }
        this.nelems = 0;
    }

    /**
     * Retrieves, but does not remove, the element at the root.
     *
     * @return item at the root of the heap
     * @throws NoSuchElementException - if this heap is empty
     */
    @Override
    public T element() {
        if(this.heap[0] == null){
            throw new NoSuchElementException("error in retrieving this.heap[0] is null!");
        }
        return this.heap[0];
    }

    /**
     * ----------------- Helper Methods -------------------------------
     * */

    /**
     * sorts from index (0) downwards
     * @param index where the trickleDown will start
     * */
    private void trickleDown(int index){

        int indexIter = index;
        int childIndex = d * index + 1;
        T value = this.heap[index];

        while(childIndex < this.size()){

            //find the extreme value among the node and all the node's children
            T extremeValue = value;
            int extremeIndex = -1;

            // all children are checked before a child key gets moved into parent.
            for(int i = 0; i < d && i + childIndex < this.size(); i++){

                if(assertDominance(this.isMaxHeap,
                        extremeValue.compareTo(this.heap[i + childIndex]) > 0)){
                    extremeValue = this.heap[i + childIndex];
                    extremeIndex = i + childIndex;
                }
            }
            // this indicates that there were no extremeValue in the tree
            if(value.equals(extremeValue)){
                return;
            }
            else{
                //swap the heap array node index and extreme index
                T tempVarIndex = this.heap[indexIter];
                this.heap[indexIter] = this.heap[extremeIndex];
                this.heap[extremeIndex] = tempVarIndex;

                indexIter = extremeIndex;
                childIndex = d * indexIter + 1;
                value = this.heap[indexIter];
            }
        }

    }

    /**
     * starts at index node and sorts it up
     *
     * @param index index of where bubbleUp will start
     * */
    private void bubbleUp(int index){
        if(this.size() < 1){
            return;
        }
        int indexIter = index;

        while(indexIter > 0){

            int parentIndex = parentIndex(indexIter);
            // if true then enact swap
            if(assertDominance(this.isMaxHeap,
                    this.heap[indexIter].compareTo(this.heap[parentIndex]) <= 0)){

                //swap the two elements and make the index equal to the parent index.
                T tempVarIndex = this.heap[indexIter];
                this.heap[indexIter] = this.heap[parentIndex];
                this.heap[parentIndex] = tempVarIndex;
                indexIter = parentIndex;
            }
            else{
                //do nothing
                break;
            }
        }
    }

    /**
     * Doubles the capacity of this.heap
     * */
    private void resize(){

        T[] biggerHeap = (T[]) new Comparable[this.heap.length * CAPACITY_INCREASER];

        // populate the new heap
        for(int i = 0; i < this.heap.length; i++){
            biggerHeap[i] = this.heap[i];
        }
        this.heap = biggerHeap;
    }

    /**
     * return the parent index for a node at index
     * @return parent index
     * */
    private int parentIndex(int index){
        int parentIndex = (index - 1)/d;
        return parentIndex;
    }

    /**
     * Returns a boolean that tells whether a swap should occur, depending on whether
     * the heap is a max heap and if the index is less than or equal to the parent index
     *
     * @param isMaxHeap true if is a max heap
     *                  false if a min heap
     * @param idxLessThanEqlParenttIdx true if the index is less than or equal to parent index
     *                                 false if index is greater than parent index
     * @return boolean on whether to assertDominance or do nothing
     * */
    private boolean assertDominance(boolean isMaxHeap, boolean idxLessThanEqlParenttIdx){
        //if it is a max heap and less than or equal to the parent index
        // then we should NOT assert our dominance and just return and dare not swap
        if((isMaxHeap && idxLessThanEqlParenttIdx) || (!isMaxHeap && !idxLessThanEqlParenttIdx)){
            //ABORT MISSION
            return false;
        }
        //if it is actually a min heap and less than or equal to the parent
        // index then we SHOULD assert our dominance and swap
        else if( (isMaxHeap && !idxLessThanEqlParenttIdx) || (!isMaxHeap && idxLessThanEqlParenttIdx)){
            return true;
        }
        return false;
    }

    /**
     *
     * Extra credit
     *
     * */

    /**
     *
     * Write a method that returns all the occurrences of the values
     * greater than a parameter 'k' in a max-heap. You can use
     * built-in Java’s Linked List. You must use heap methods and
     * not simply scan the array.
     *
     * */
    public LinkedList findGreaterThanK(T k){
        LinkedList<T> greaterK = new LinkedList<>();
        dHeap<T> myTempHeap = new dHeap<>();
        for(int i = 0; i< this.size(); i++){
            myTempHeap.add(this.heap[i]);
        }
        //while you aren't at the end
        while(myTempHeap.element()!=null){
            //if the top element is greater than K
            if(myTempHeap.element().compareTo(k) > 0){
                greaterK.add(myTempHeap.element());
                myTempHeap.remove();
            }
            else{
                System.out.println();
                for(int i = 0; i < greaterK.size(); i++){
                    System.out.print(" " + greaterK.get(i) + " ");
                }
                return greaterK;
            }
        }
        return greaterK;
    }


    /**
     * Write a method that takes an array of integers and two numbers num1 and num2, and
     * finds the sum of all elements between given two num1 (inclusive) and num2(inclusive)
     * smallest elements of array. It may be assumed that 1<=num1<=num2 <= n and all
     * elements of array are distinct.
     * */
    public int findSum(int[] a, int num1, int num2){
        dHeap<Integer> myIntegers = new dHeap<>(DEFAULT_D, DEFAULT_SIZE, false );
        //populate a new heap with array elements
        for(int i = 0; i< a.length; i++){
            myIntegers.add(a[i]);
        }
        int minSum = 0;

        int numToAdd = num2 - num1 + 1;
        for(int i = 1; i < num1; i++){
            myIntegers.remove();
        }
        for(int i = 0; i <numToAdd; i++){
            minSum += myIntegers.element();
            myIntegers.remove();
        }
        return minSum;
    }

}
