/**
 * Madeline Tjoa
 * PID: A15394053
 *
 *
 * */

/**
 * Class that has FindKLargest that gets the
 * top k largest elements in the array
 * */
import java.util.ArrayList;

public class FindKLargest {
    public static void main(String[] args) {
        ArrayList<Integer> hello = new ArrayList<>();
        for(int i = 0; i < 10; i++){
            hello.add(i);
        }
        ArrayList<Integer> bigBoys = findKLargest(3, hello);

        for(int i = 0; i < bigBoys.size(); i++){
            System.out.print(bigBoys.get(i));
        }

    }

    /**
     * Returns the k largest elements in an int array of
     * size n (you may assume k is much smaller than n)
     *  * the results in the returned Arraylist should be in
     *  descending order, which are the k largest elements in the array
     *
     * @param k number of elements we will take
     * @param arr array of numbers
     * @return ArrayList Integer that has the top values in descending order
     * */
    public static ArrayList<Integer> findKLargest(int k, ArrayList<Integer> arr) {
        ArrayList<Integer> bigBoys = new ArrayList<>();
        dHeap<Integer> myHeap = new dHeap<>();
        //populate myHeap with contents of array
        for(int i = 0; i < arr.size(); i++){
            myHeap.add(arr.get(i));
        }
        //populate the top k elements
        for(int i = 0; i < k; i++){
            bigBoys.add(myHeap.element());
            myHeap.remove();
        }
        return bigBoys;
    }
}
