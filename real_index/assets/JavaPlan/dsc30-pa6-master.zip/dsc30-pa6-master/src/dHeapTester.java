import java.util.NoSuchElementException;

import static org.junit.Assert.*;
/**
 * Madeline Tjoa
 * A15394053
 *
 * Testing
 *
 * */
public class dHeapTester {

    dHeap<Integer> myHeap1;
    dHeap<Integer> myHeap2;
    dHeap<Integer> myHeap3;

    dHeap<Integer> myHeap4;
    dHeap<Integer> myHeap5;
    dHeap<Integer> myHeap6;

    dHeap<Integer> myHeap7;
    dHeap<Integer> myHeap8;
    dHeap<Integer> myHeap9;


    @org.junit.Before
    public void setUp() throws Exception {
        myHeap1 = new dHeap<>();
        myHeap1.add(1);
        myHeap1.add(2);
        myHeap1.add(5);
        myHeap1.add(3);
        myHeap2 = new dHeap<>();
        for(int i = 0; i < 10; i++){
            myHeap2.add(i);
        }
        myHeap3 = new dHeap<>();

        for(int i = 10; i> 0; i--){
            myHeap3.add(i);
        }

        myHeap4 = new dHeap<>(8);
        for(int i = 0; i < 10; i++){
            myHeap4.add(i);
        }
        myHeap5 = new dHeap<>(10);
        myHeap6 = new dHeap<>(6);

        myHeap7 = new dHeap<>(6, 7, false);
        for(int i = 0; i < 10; i++){
            myHeap7.add(i);
        }
        myHeap8 = new dHeap<>(3, 6, false);
        for(int i = 0; i < 10; i++){
            myHeap8.add(i);
        }
        myHeap9 = new dHeap<>(5, 7, false);
        for(int i = 0; i < 10; i++){
            myHeap9.add(i);
        }



    }

    /**
     * Test for null data,
     *
     * removing from an empty heap,
     *
     * adding a large number of elements,
     *
     * alternating add and remove
     *
     * test that our exceptions are throwing errors
     *
     *
     *
     * Note that a min dHeap will return all numbers in ascending order while a max-dHeap will return them in descending order.
     *
     * make sure that the heap will work for different values of d
     * */
    @org.junit.Test
    public void size() {
        assertEquals(4, myHeap1.size());
        assertEquals(new Integer(5), myHeap1.element());
    }

    @org.junit.Test
    public void remove() {
        myHeap2.remove();
        assertEquals(new Integer(8), myHeap2.element());
        myHeap2.remove();
        assertEquals(new Integer(7), myHeap2.element());
        myHeap2.remove();
        assertEquals(new Integer(6), myHeap2.element());
        myHeap2.remove();
        assertEquals(new Integer(5), myHeap2.element());
        myHeap2.remove();
        assertEquals(new Integer(4), myHeap2.element());
        myHeap2.remove();
        assertEquals(new Integer(3), myHeap2.element());
        myHeap2.remove();
        assertEquals(new Integer(2), myHeap2.element());
        myHeap2.remove();
        assertEquals(new Integer(1), myHeap2.element());
        myHeap2.remove();
        assertEquals(new Integer(0), myHeap2.element());

        myHeap9.remove();
        assertEquals(new Integer(1), myHeap9.element());
        myHeap9.remove();
        assertEquals(new Integer(2), myHeap9.element());
        myHeap9.remove();
        assertEquals(new Integer(3), myHeap9.element());
        myHeap9.remove();


        myHeap8.remove();
        assertEquals(new Integer(1), myHeap8.element());
        myHeap8.remove();
        assertEquals(new Integer(2), myHeap8.element());
        myHeap8.remove();
        assertEquals(new Integer(3), myHeap8.element());
        myHeap8.remove();

    }

    @org.junit.Test
    public void addRemove() {
        myHeap2.remove();
        myHeap2.add(11);
        assertEquals(new Integer(11), myHeap2.element());

    }

    @org.junit.Test
    public void clear() {
        myHeap1.clear();
        assertEquals(0, myHeap1.size());
        myHeap9.clear();
        myHeap9.add(3);
        assertEquals(new Integer(3), myHeap9.element());
    }

    @org.junit.Test
    public void ec() {
       myHeap9.findGreaterThanK(new Integer(4));
       assertEquals(10, myHeap9.size());

       int[] aaa = new int[]{60, 5, 27, 3, 12, 9, 14};
       System.out.println(myHeap9.findSum(aaa, 4, 5));
    }

    @org.junit.Test(expected = IllegalArgumentException.class)
    public void testIllegalArgument() {
        dHeap<Integer> badHeap = new dHeap<>(0,0,true);
    }

    @org.junit.Test(expected = NullPointerException.class)
    public void testNullPointer() {
        myHeap9.add(null);
    }

    @org.junit.Test(expected = NoSuchElementException.class)
    public void testNoSuchElement() {
        for(int i = 0; i< 15; i++){
            myHeap9.remove();
        }
        myHeap9.element();
    }




}