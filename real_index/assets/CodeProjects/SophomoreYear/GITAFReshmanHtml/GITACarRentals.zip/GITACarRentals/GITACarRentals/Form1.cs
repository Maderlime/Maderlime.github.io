﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Madeline Tjoa
//Period 0
//GITA CarRental project
//10/3/2014



namespace GITACarRentals
{
    public partial class Form1 : Form
    {
        //make the containers

        private decimal totalPeopleDecimal;

        private decimal totalPriceDecimal;


        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {

            //Program Close

            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            //Calculates Everything

            //Declare Variables

            decimal BeginningOdometer;
            decimal EndingOdometer;
            decimal DaysOfUse;
            decimal TotalPrice;
            decimal MilesDriven;
            decimal AverageSales;
          
            
            

            
            //Get info from user with the text Box

            try
            {

                BeginningOdometer = Decimal.Parse(txtBeginningOdometerReading.Text);
                EndingOdometer = Decimal.Parse(txtEndingOdometerReading.Text);
                DaysOfUse = Decimal.Parse(txtDays.Text);

                //Calculations

                MilesDriven = BeginningOdometer - EndingOdometer;

                TotalPrice = 15 * DaysOfUse + (Decimal)0.12 * MilesDriven;
                totalPeopleDecimal += 1;
                totalPriceDecimal += TotalPrice;
                AverageSales = totalPriceDecimal / totalPeopleDecimal;


                //Input to User

                lblMilesDriven.Text = MilesDriven.ToString();
                lblTotalPrice.Text = TotalPrice.ToString("C");
                lblTotalPeople.Text = totalPeopleDecimal.ToString();
                lblAmountMade.Text = totalPriceDecimal.ToString("C");
                lblAverageSales.Text = AverageSales.ToString("C");

                lblInput.Text = lblInput.Text = txtName.Text + " " + txtLastName.Text +
                                "\n" + txtAddress.Text + "\n" + txtCity.Text +
                                ", " + txtState.Text + " " + txtZipcode.Text;

            }
            catch
            {

                MessageBox.Show("You need to enter data", "data error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            

        }

        private void lblTotalPeople_Click(object sender, EventArgs e)
        {

        }

        private void lblAverageSales_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void lblMilesDriven_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {

            //Clear Button
            lblInput.Text = "";
            txtZipcode.Text = "";
            txtAddress.Text = "";
            txtState.Text = "";
            txtLastName.Text = "";
            txtCity.Text = "";
            txtName.Text = "";
            lblMilesDriven.Text = "";
            lblTotalPrice.Text = "";
            txtBeginningOdometerReading.Text = "";
            txtEndingOdometerReading.Text = "";
            

        }
    }
}
