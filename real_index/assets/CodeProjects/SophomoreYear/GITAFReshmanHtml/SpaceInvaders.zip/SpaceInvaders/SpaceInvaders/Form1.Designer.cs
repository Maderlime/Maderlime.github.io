﻿namespace SpaceInvaders
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.Invader1 = new System.Windows.Forms.PictureBox();
            this.Invader3 = new System.Windows.Forms.PictureBox();
            this.Invader2 = new System.Windows.Forms.PictureBox();
            this.Player = new System.Windows.Forms.PictureBox();
            this.lblBullet = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SpaceInvaderTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Invader1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Invader3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Invader2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBullet)).BeginInit();
            this.SuspendLayout();
            // 
            // Invader1
            // 
            this.Invader1.Image = ((System.Drawing.Image)(resources.GetObject("Invader1.Image")));
            this.Invader1.Location = new System.Drawing.Point(174, 43);
            this.Invader1.Name = "Invader1";
            this.Invader1.Size = new System.Drawing.Size(111, 94);
            this.Invader1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Invader1.TabIndex = 0;
            this.Invader1.TabStop = false;
            this.Invader1.Click += new System.EventHandler(this.Invader1_Click);
            // 
            // Invader3
            // 
            this.Invader3.Image = ((System.Drawing.Image)(resources.GetObject("Invader3.Image")));
            this.Invader3.Location = new System.Drawing.Point(434, 43);
            this.Invader3.Name = "Invader3";
            this.Invader3.Size = new System.Drawing.Size(111, 94);
            this.Invader3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Invader3.TabIndex = 1;
            this.Invader3.TabStop = false;
            this.Invader3.Click += new System.EventHandler(this.Invader3_Click);
            // 
            // Invader2
            // 
            this.Invader2.Image = ((System.Drawing.Image)(resources.GetObject("Invader2.Image")));
            this.Invader2.Location = new System.Drawing.Point(306, 43);
            this.Invader2.Name = "Invader2";
            this.Invader2.Size = new System.Drawing.Size(111, 94);
            this.Invader2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Invader2.TabIndex = 2;
            this.Invader2.TabStop = false;
            this.Invader2.Click += new System.EventHandler(this.Invader2_Click);
            // 
            // Player
            // 
            this.Player.Image = ((System.Drawing.Image)(resources.GetObject("Player.Image")));
            this.Player.Location = new System.Drawing.Point(305, 264);
            this.Player.Name = "Player";
            this.Player.Size = new System.Drawing.Size(111, 94);
            this.Player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Player.TabIndex = 3;
            this.Player.TabStop = false;
            // 
            // lblBullet
            // 
            this.lblBullet.BackColor = System.Drawing.Color.GhostWhite;
            this.lblBullet.Image = ((System.Drawing.Image)(resources.GetObject("lblBullet.Image")));
            this.lblBullet.Location = new System.Drawing.Point(350, 264);
            this.lblBullet.Name = "lblBullet";
            this.lblBullet.Size = new System.Drawing.Size(14, 27);
            this.lblBullet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lblBullet.TabIndex = 5;
            this.lblBullet.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // SpaceInvaderTimer
            // 
            this.SpaceInvaderTimer.Enabled = true;
            this.SpaceInvaderTimer.Tick += new System.EventHandler(this.SpaceInvaderTimer_Tick);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(723, 397);
            this.Controls.Add(this.lblBullet);
            this.Controls.Add(this.Player);
            this.Controls.Add(this.Invader2);
            this.Controls.Add(this.Invader3);
            this.Controls.Add(this.Invader1);
            this.Name = "FrmMain";
            this.Text = "Main Form";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmMain_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.Invader1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Invader3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Invader2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBullet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Invader1;
        private System.Windows.Forms.PictureBox Invader3;
        private System.Windows.Forms.PictureBox Invader2;
        private System.Windows.Forms.PictureBox Player;
        private System.Windows.Forms.PictureBox lblBullet;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer SpaceInvaderTimer;
    }
}

