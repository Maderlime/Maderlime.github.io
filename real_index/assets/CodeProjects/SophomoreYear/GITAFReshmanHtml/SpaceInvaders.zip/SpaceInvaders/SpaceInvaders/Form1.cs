﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Madeline Tjoa
//Space Invaders
//Period 0
//3/5/2015

namespace SpaceInvaders
{
    public partial class FrmMain : Form
    {


        PictureBox[] Invaders = new PictureBox[3];

        



       int xSpeed = 10;
       int ySpeed = 0;
       int HitCount = 0;

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_KeyDown(object sender, KeyEventArgs e)
        {

            int Keypressed = e.KeyValue;

            int xcord = Player.Left;
            int ycord = Player.Top;

            //determine whichKey key is pressed
            if (Keypressed == 37)
            {
                //move ship to the left
                xcord -= 10;
            }
            else if (Keypressed == 39)
            {
                //SHip goes right
                xcord += 10;
            }

            Player.Left = xcord;

            if (Keypressed == 32)
            {
                lblBullet.Visible = true;
                timer1.Enabled = true;
            }

            if (timer1.Enabled == false)
            {
                lblBullet.Left = Player.Left;
                lblBullet.Top = Player.Top;
            }





        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //When Timer 1 Ticks this happens

             //Move the bullet
            int bulletY = lblBullet.Top;
            bulletY -= 10;

            lblBullet.Top = bulletY;
            //When the bullet gets to the top a new bullet spawns for the Player
            if (lblBullet.Top < -20)
            {
                timer1.Enabled = false;
                lblBullet.Visible = false;
                lblBullet.Left = Player.Left;
                lblBullet.Top = Player.Top;
            }

            if (lblBullet.Left > Invader1.Left && lblBullet.Right < Invader1.Right &&
               lblBullet.Top < Invader1.Bottom)
            {

                Invader1.Image = null;
                Invader1.Width = 0;
                Invader1.Height = 0;
                Invader1.Enabled = false;
                HitCount += 1;
                timer1.Enabled = false;
                lblBullet.Visible = false;
                lblBullet.Left = Player.Left;
                lblBullet.Top = Player.Top;
            }
            if (lblBullet.Left > Invader2.Left && lblBullet.Right < Invader2.Right &&
               lblBullet.Top < Invader2.Bottom)
            {
                Invader2.Image = null;
                
                Invader2.Width = 0;
                Invader2.Height = 0;
                HitCount += 1;
                timer1.Enabled = false;
                lblBullet.Visible = false;
                lblBullet.Left = Player.Left;
                lblBullet.Top = Player.Top;
            }
            if (lblBullet.Left > Invader3.Left && lblBullet.Right < Invader3.Right &&
               lblBullet.Top < Invader3.Bottom)
            {
                Invader3.Image = null;
                Invader3.Width = 0;
                Invader3.Height = 0;
                
                HitCount += 1;
                timer1.Enabled = false;
                lblBullet.Visible = false;
                lblBullet.Left = Player.Left;
                lblBullet.Top = Player.Top;
            }




            if (HitCount == 3)
            {
                DialogResult resultAnswer = DialogResult;

                string messageString = null;
                messageString = "You won! Play again?";
                resultAnswer = MessageBox.Show(messageString, "Play again?",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                //This runs the code if they sellect the yes buttton
                if (resultAnswer == DialogResult.Yes)
                {

                    Application.Restart();

                }

                if (Invader1.Bottom > Player.Top)
                {
                    MessageBox.Show("You lOse");
                }

                if (resultAnswer == DialogResult.No)
                {
                    MessageBox.Show("Who cares? restarting!");
                    Application.Restart();
                }

            }
        }

        private void SpaceInvaderTimer_Tick(object sender, EventArgs e)
        {
            //left and right

            for (int n = 0; n < 3; n++)
            {

                int xcordInvaders = Invaders[n].Left;
                int ycordInvaders = Invaders[n].Top;

                if (Invaders[n].Right > this.Width)
                {
                    xSpeed *= -1;
                    
                }
                if (Invaders[n].Left < 0)
                {
                    xSpeed *= -1;
                    
                }

                

            }
            for (int i = 0; i < 3; i++ )
            {
                int xcordInvaders = Invaders[i].Left;
                int ycordInvaders = Invaders[i].Top;
                xcordInvaders += xSpeed;

                Invaders[i].Left = xcordInvaders;
            }


            for(int d = 0;d<3;d++)
            {
             int xcordInvaders = Invaders[d].Left;
             int ycordInvaders = Invaders[d].Top;

             if (Invaders[d].Right > this.Width)
             {
                 ySpeed += 10;
             }
             if (Invaders[d].Left < 0)
             {
                 ySpeed += 10;
             }

                

            }

            for (int s = 0; s < 3; s++)
            {
                int xcordInvaders = Invaders[s].Left;
                int ycordInvaders = Invaders[s].Top;

                ycordInvaders = ySpeed;



                Invaders[s].Top = ycordInvaders;
            }



        }

       


        private void Invader3_Click(object sender, EventArgs e)
        {

        }

        private void Invader2_Click(object sender, EventArgs e)
        {

        }

        private void Invader1_Click(object sender, EventArgs e)
        {

        }

        private void FrmMain_Load(object sender, EventArgs e)
        {

            Invaders[0] = Invader1;
            Invaders[1] = Invader2;
            Invaders[2] = Invader3;


        }

        




    }
}
